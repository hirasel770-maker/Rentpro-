
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.n2r.NeonRent', // Updated package name from new google-services.json
  appName: 'NeonRent AI Manager',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    Permissions: {
        display: "prompt"
    }
  }
};

export default config;
