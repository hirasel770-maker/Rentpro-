import React, { useState, useEffect, useRef, Suspense, ReactNode, ErrorInfo, Component } from 'react';
import { loadData, saveData } from './pages/services/storageService';
import { requestNotificationPermission, startContinuousAlarm, stopContinuousAlarm, initAudio, refreshAllSchedules } from './pages/services/notificationService';
import { initAnalytics, auth } from './pages/services/firebaseConfig';
import { syncDataToCloud, fetchDataFromCloud } from './pages/services/cloudService';
import { onAuthStateChanged } from 'firebase/auth';
import { AppData, Page, Tenant } from './types';
import BottomNav from './components/BottomNav';
import SettingsModal from './components/SettingsModal';
import { Lock, Unlock, Volume2, Square, Loader2, AlertTriangle, Siren, User, XCircle, CheckCircle } from 'lucide-react';
import { App as CapacitorApp } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';

// --- LAZY LOADING COMPONENTS ---
const Dashboard = React.lazy(() => import('./pages/Dashboard'));
const Tenants = React.lazy(() => import('./pages/Tenants'));
const RentForm = React.lazy(() => import('./pages/Form'));
const Units = React.lazy(() => import('./pages/Units'));
const SearchPage = React.lazy(() => import('./pages/Search'));
const Todos = React.lazy(() => import('./pages/Todos'));
const ServiceBook = React.lazy(() => import('./pages/HealthTracker'));
const Expenses = React.lazy(() => import('./pages/Expenses')); 
const Tools = React.lazy(() => import('./pages/Tools')); 

// --- ERROR BOUNDARY (CRASH PROTECTION) ---
interface ErrorBoundaryProps { children?: ReactNode; }
interface ErrorBoundaryState { hasError: boolean; error?: Error; }

// Robust Class Component for Error Boundary
class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState { 
    return { hasError: true, error }; 
  }
  
  componentDidCatch(error: Error, info: ErrorInfo) { 
    console.error("Crash:", error, info); 
  }
  
  handleRestart = () => { 
    this.setState({ hasError: false, error: undefined }); 
    window.location.reload(); 
  }
  
  render() {
    if (this.state.hasError) {
      return (
        <div className="h-screen flex flex-col items-center justify-center bg-[#14161F] text-white p-6 text-center">
          <AlertTriangle size={64} className="text-red-500 mb-6 animate-pulse" />
          <h2 className="text-2xl font-black mb-2">Something went wrong</h2>
          <button onClick={this.handleRestart} className="mt-6 px-8 py-3 bg-app-accent text-black font-bold rounded-xl">RESTART</button>
        </div>
      );
    }
    return this.props.children;
  }
}

// --- SWIPE NAVIGATION ORDER ---
const PAGE_ORDER: Page[] = ['dashboard', 'tenants', 'units', 'services', 'tools', 'expenses', 'todos', 'search'];

const App: React.FC = () => {
  const [page, setPage] = useState<Page>('dashboard');
  const [data, setData] = useState<AppData | null>(null); 
  const [navVisible, setNavVisible] = useState(true); 
  const [showSettings, setShowSettings] = useState(false);
  
  // NEW: State to track if virtual keyboard is likely open
  const [isKeyboardOpen, setIsKeyboardOpen] = useState(false);

  const [editingTenantId, setEditingTenantId] = useState<string | null>(null);
  const [focusField, setFocusField] = useState<string | null>(null); // NEW: Track which field to focus on form

  const [isLocked, setIsLocked] = useState(false);
  const [unlockPin, setUnlockPin] = useState('');
  const lastActivity = useRef<number>(Date.now());
  
  const [alertMsg, setAlertMsg] = useState<{title: string, body: string} | null>(null);
  const [defaulterList, setDefaulterList] = useState<Tenant[] | null>(null);
  
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'done'>('idle');
  
  const lastAlertMinute = useRef<string | null>(null);
  const isRingingRef = useRef<boolean>(false);

  const touchStartRef = useRef<{x: number, y: number} | null>(null);
  const touchEndRef = useRef<{x: number, y: number} | null>(null);
  
  const isLight = data?.settings?.theme === 'light';
  const themeClass = isLight ? 'bg-[#F2F4F7] text-gray-800' : 'bg-[#0F1014] text-gray-200';

  // NEW: Global Event Listener to detect input focus (Virtual Keyboard)
  useEffect(() => {
      const handleFocusIn = (e: FocusEvent) => {
          const target = e.target as HTMLElement;
          const tagName = target.tagName;
          if (tagName === 'INPUT' || tagName === 'TEXTAREA') {
              const type = (target as HTMLInputElement).type;
              // Ignore non-text inputs like checkboxes, radio, file, etc.
              if (type !== 'checkbox' && type !== 'radio' && type !== 'file' && type !== 'range' && type !== 'button' && type !== 'submit' && type !== 'reset' && type !== 'color') {
                  setIsKeyboardOpen(true);
              }
          }
      };

      const handleFocusOut = () => {
          // Delay to check if focus simply moved to another input
          setTimeout(() => {
              const active = document.activeElement as HTMLElement;
              if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA')) {
                  // Focus moved to another input, keep keyboard state open
                  return;
              }
              setIsKeyboardOpen(false);
          }, 100);
      };

      window.addEventListener('focusin', handleFocusIn);
      window.addEventListener('focusout', handleFocusOut);

      return () => {
          window.removeEventListener('focusin', handleFocusIn);
          window.removeEventListener('focusout', handleFocusOut);
      };
  }, []);

  useEffect(() => {
    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
        console.warn("Prevented Crash:", event.reason);
        event.preventDefault(); 
    };
    window.addEventListener('unhandledrejection', handleUnhandledRejection);

    const init = async () => {
        try {
            const loadedData = await loadData();
            if (loadedData.settings.security.isEnabled) {
                setIsLocked(true);
            }
            setData(loadedData);
            
            if (Capacitor.isNativePlatform()) {
                await requestNotificationPermission();
                await refreshAllSchedules(loadedData);
                await LocalNotifications.addListener('localNotificationActionPerformed', () => {
                    stopContinuousAlarm();
                    setAlertMsg(null);
                });
                await LocalNotifications.addListener('localNotificationReceived', (notification) => {
                    triggerAlarm(notification.title || "Alert", notification.body || "");
                });
            }

            await initAnalytics();
            const warmUpAudio = () => {
                initAudio(); 
                window.removeEventListener('click', warmUpAudio);
                window.removeEventListener('touchstart', warmUpAudio);
            };
            window.addEventListener('click', warmUpAudio);
            window.addEventListener('touchstart', warmUpAudio);

            onAuthStateChanged(auth, async (user) => {
                if (user) {
                    setSyncStatus('syncing');
                    const cloudData = await fetchDataFromCloud(user.uid);
                    if (cloudData) {
                        setData(prev => ({ 
                            ...cloudData, 
                            ...prev, 
                            settings: { 
                                ...cloudData.settings, 
                                owner: { 
                                    ...cloudData.settings.owner, 
                                    isLoggedIn: true, 
                                    uid: user.uid,
                                    name: user.displayName || cloudData.settings.owner.name,
                                    photo: user.photoURL || cloudData.settings.owner.photo,
                                    email: user.email || cloudData.settings.owner.email
                                } 
                            } 
                        }));
                    } else {
                        if (loadedData) await syncDataToCloud(user.uid, loadedData);
                    }
                    setSyncStatus('done');
                    setTimeout(() => setSyncStatus('idle'), 2000);
                }
            });
        } catch (e) {
            console.error("Initialization Error:", e);
        }
    };
    init();
    return () => window.removeEventListener('unhandledrejection', handleUnhandledRejection);
  }, []);

  useEffect(() => {
      if (Capacitor.isNativePlatform()) {
          const handleBack = async () => {
              if (defaulterList || alertMsg) {
                  stopAlarm();
              } else if (showSettings) {
                  setShowSettings(false);
              } else if (page !== 'dashboard') {
                  setPage('dashboard');
                  setEditingTenantId(null);
              } else {
                  await CapacitorApp.exitApp();
              }
          };
          const backListener = CapacitorApp.addListener('backButton', handleBack);
          return () => { backListener.then(l => l.remove()); };
      }
  }, [page, showSettings, defaulterList, alertMsg]);

  useEffect(() => {
      if (!data) return;
      const handleAppState = async ({ isActive }: { isActive: boolean }) => {
          if (isActive) {
              if (data.settings.security.isEnabled) {
                  setIsLocked(true);
                  setUnlockPin('');
              }
              await refreshAllSchedules(data);
          } else {
              saveData(data);
              if (data.settings.owner.isLoggedIn && data.settings.owner.uid) {
                   syncDataToCloud(data.settings.owner.uid, data).catch(() => {});
              }
          }
      };
      const listener = CapacitorApp.addListener('appStateChange', handleAppState);
      return () => { listener.then(l => l.remove()); };
  }, [data]);

  useEffect(() => {
    if (!data) return;
    const handler = setTimeout(async () => {
      saveData(data);
      if (!document.hidden && data.settings.owner.isLoggedIn && data.settings.owner.uid) {
          setSyncStatus('syncing');
          await syncDataToCloud(data.settings.owner.uid, data);
          setSyncStatus('done');
          setTimeout(() => setSyncStatus('idle'), 2000);
      }
    }, 2000);
    return () => clearTimeout(handler);
  }, [data]);

  const triggerAlarm = (title: string, body: string) => {
      if (isRingingRef.current) return; 
      isRingingRef.current = true;
      setAlertMsg({ title, body });
      startContinuousAlarm(); 
  };

  const stopAlarm = () => {
      stopContinuousAlarm();
      setAlertMsg(null);
      isRingingRef.current = false;
      if (navigator.vibrate) navigator.vibrate(50);
  };

  const handleDefaulterAcknowledge = () => {
      const now = new Date();
      const alertKey = `defaulter_alert_${now.getFullYear()}_${now.getMonth()}`;
      localStorage.setItem(alertKey, 'true'); 
      setDefaulterList(null);
      stopContinuousAlarm();
  };

  useEffect(() => {
      if (!data) return;
      const checkAlarms = () => {
          const now = new Date();
          const deadline = data.settings.rentPaymentDeadline || 8;
          if (now.getDate() >= deadline) {
              const alertKey = `defaulter_alert_${now.getFullYear()}_${now.getMonth()}`;
              if (!localStorage.getItem(alertKey) && !defaulterList && !isRingingRef.current) {
                  const defaulters = data.tenants.filter(t => t.status === 'Active' && t.due > 0);
                  if (defaulters.length > 0) {
                      setDefaulterList(defaulters);
                      triggerAlarm("Rent Deadline", "Rent payment is pending for some tenants.");
                  }
              }
          }
      };
      const interval = setInterval(checkAlarms, 60000);
      checkAlarms();
      return () => clearInterval(interval);
  }, [data, defaulterList]);

  if (!data) return (
    <div className="h-screen flex items-center justify-center bg-[#0F1014]">
        <Loader2 className="animate-spin text-app-accent" size={48} />
    </div>
  );

  return (
    <ErrorBoundary>
      <div className={`h-screen flex flex-col overflow-hidden transition-colors duration-300 ${themeClass}`}>
          <div className="flex-1 overflow-hidden relative">
              <Suspense fallback={<div className="h-screen flex items-center justify-center"><Loader2 className="animate-spin text-app-accent" size={32} /></div>}>
                  {page === 'dashboard' && (
                    <Dashboard 
                        data={data} 
                        setData={setData} 
                        onOpenSettings={() => setShowSettings(true)} 
                        setPage={setPage} 
                        onEditTenant={(id, field) => { 
                            setEditingTenantId(id); 
                            setFocusField(field || null); 
                            setPage('form'); 
                        }} 
                    />
                  )}
                  {page === 'tenants' && (
                    <Tenants 
                        data={data} 
                        setData={setData} 
                        weather={{loading: false} as any} 
                        onOpenSettings={() => setShowSettings(true)} 
                        onEditTenant={(id) => { 
                            setEditingTenantId(id); 
                            setFocusField(null);
                            setPage('form'); 
                        }} 
                    />
                  )}
                  {page === 'form' && (
                    <RentForm 
                        data={data} 
                        setData={setData} 
                        setPage={setPage} 
                        setNavVisible={setNavVisible} 
                        onOpenSettings={() => setShowSettings(true)} 
                        editingId={editingTenantId} 
                        clearEditing={() => {
                            setEditingTenantId(null);
                            setFocusField(null);
                        }} 
                        focusField={focusField}
                    />
                  )}
                  {page === 'units' && <Units data={data} setData={setData} onOpenSettings={() => setShowSettings(true)} />}
                  {page === 'search' && (
                    <SearchPage 
                        data={data} 
                        setData={setData}
                        onOpenSettings={() => setShowSettings(true)} 
                        setNavVisible={setNavVisible} 
                        setPage={setPage} 
                        onResultClick={(id, type) => { 
                            if(type === 'tenant') { 
                                setEditingTenantId(id); 
                                setFocusField(null);
                                setPage('form'); 
                            } 
                        }} 
                    />
                  )}
                  {page === 'todos' && <Todos data={data} setData={setData} onOpenSettings={() => setShowSettings(true)} setPage={setPage} />}
                  {page === 'services' && <ServiceBook data={data} setData={setData} onOpenSettings={() => setShowSettings(true)} />}
                  {page === 'expenses' && <Expenses data={data} setData={setData} onOpenSettings={() => setShowSettings(true)} />}
                  {page === 'tools' && <Tools data={data} setData={setData} onOpenSettings={() => setShowSettings(true)} setPage={setPage} />}
              </Suspense>
          </div>

          <BottomNav data={data} activePage={page} setPage={setPage} visible={navVisible && !isKeyboardOpen} />
          
          {showSettings && <SettingsModal data={data} setData={setData} onClose={() => setShowSettings(false)} />}
          
          {/* Global Alert Overlay */}
          {alertMsg && (
              <div className="fixed inset-0 z-[10000] bg-red-600 flex flex-col items-center justify-center p-6 text-center text-white animate-pulse">
                  <Siren size={80} className="mb-6" />
                  <h2 className="text-3xl font-black mb-2">{alertMsg.title}</h2>
                  <p className="text-xl font-bold mb-8">{alertMsg.body}</p>
                  <button onClick={stopAlarm} className="px-10 py-4 bg-white text-red-600 font-black rounded-2xl shadow-2xl flex items-center gap-2">
                      <Square size={24} fill="currentColor" /> STOP ALARM
                  </button>
              </div>
          )}

          {/* Defaulter Alert List Modal */}
          {defaulterList && (
              <div className="fixed inset-0 z-[9999] bg-black/90 backdrop-blur-md flex items-center justify-center p-6 pb-safe">
                  <div className="w-full max-w-sm bg-[#1A1C23] rounded-[32px] border border-red-500/30 overflow-hidden shadow-2xl animate-slide-up mb-safe">
                      <div className="bg-red-600 p-6 text-white text-center">
                          <AlertTriangle size={40} className="mx-auto mb-2 animate-bounce" />
                          <h2 className="text-xl font-black uppercase tracking-widest">Defaulter Alert</h2>
                          <p className="text-xs font-bold opacity-80 mt-1">Pending Rent Since {data.settings.rentPaymentDeadline || 8}th</p>
                      </div>
                      <div className="p-4 max-h-[300px] overflow-y-auto space-y-2">
                          {defaulterList.map(t => (
                              <div key={t.id} className="flex justify-between items-center p-3 bg-white/5 rounded-xl border border-white/5">
                                  <div>
                                      <h4 className="font-bold text-white text-sm">{t.name}</h4>
                                      <p className="text-[10px] text-gray-500">Room {t.unitId}</p>
                                  </div>
                                  <span className="text-red-500 font-black">৳{t.due}</span>
                              </div>
                          ))}
                      </div>
                      <div className="p-4 border-t border-white/5">
                          <button onClick={handleDefaulterAcknowledge} className="w-full py-4 bg-white text-black font-black rounded-2xl active:scale-95 transition">GOT IT</button>
                      </div>
                  </div>
              </div>
          )}

          {/* Sync status toast notification */}
          {syncStatus !== 'idle' && (
              <div className={`fixed top-20 left-1/2 -translate-x-1/2 px-4 py-2 rounded-full flex items-center gap-2 text-xs font-bold shadow-lg transition-all z-[9999] ${syncStatus === 'syncing' ? 'bg-blue-500 text-white' : 'bg-green-500 text-white'}`}>
                  {syncStatus === 'syncing' ? <Loader2 size={12} className="animate-spin" /> : <CheckCircle size={12} />}
                  {syncStatus === 'syncing' ? 'Syncing...' : 'Synced to Cloud'}
              </div>
          )}
      </div>
    </ErrorBoundary>
  );
};

export default App;