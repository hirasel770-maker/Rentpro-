
export interface CustomField {
  id: string;
  label: string;
  amount: number;
}

export interface Todo {
  id: string;
  text: string;
  completed: boolean;
  color: string; // generic color class or hex
}

export interface Medicine {
  id: string;
  name: string;
  time: string; // e.g. "08:00"
  instruction: 'Before Food' | 'After Food' | 'Empty Stomach';
  duration?: string; // Added: How many days
  startDate?: string; // Added: When the course started (ISO String)
}

export interface Tenant {
  id: string;
  name: string;
  phone: string;
  unitId: string; // Acts as House No now
  meterNumber?: string; // New field
  rentAmount: number;
  advance: number;
  entryDate: string;
  startMeterReading?: number; // Initial meter reading (kwh)
  currentMeterReading?: number; // Tracks the last recorded reading
  unitPrice?: number; // Added: Tenant specific unit price
  occupation?: string; // Job Holder, Student, etc.
  idImage?: string; // base64 or URL (Front Side)
  idBackImage?: string; // base64 or URL (Back Side) - NEW FIELD
  profileImage?: string; // base64 or URL
  entryMeterImage?: string; // NEW: Move-in meter photo (Permanent)
  lastMeterImage?: string; // Recurring: Photo of the last bill meter reading
  customFields?: CustomField[]; // WiFi, Gas, etc.
  due: number;
  status: 'Active' | 'Left' | 'Archived';
  reminderDate?: string; // Date string for payment promise
  garbageBill?: number; // Added field
}

export interface Unit {
  id: string;
  name: string; // e.g. "Room 101"
  meterNumber: string;
  currentMeterReading: number;
  status: 'occupied' | 'vacant' | 'maintenance';
}

export interface Bill {
  id: string;
  tenantId: string;
  date: string;
  month: string;
  rentAmount: number;
  prevMeter: number;
  currMeter: number;
  unitPrice: number;
  electricityBill: number;
  totalAmount: number;
  paidAmount: number;
  isPaid: boolean;
  meterImage?: string; // base64 or URL
  advanceAdjustment?: number; // Added: Amount deducted from advance
}

export interface UserProfile {
  uid?: string; // Firebase UID
  name: string;
  email: string;
  photo?: string;
  isLoggedIn: boolean;
  language: 'en' | 'bn';
  lastSync?: number; // Timestamp
}

export interface DeveloperProfile {
  name: string;
  phone: string;
  email: string;
  photo?: string;
}

export interface Expense {
  id: string;
  title: string;
  amount: number;
  date: string;
  category: 'Repair' | 'Utility' | 'Paint' | 'Salary' | 'Other';
  note?: string;
}

// Added 'tools' to Page type
export type Page = 'dashboard' | 'tenants' | 'form' | 'units' | 'search' | 'settings' | 'todos' | 'services' | 'expenses' | 'tools';

// --- Service Directory Types ---
export type ServiceCategory = 'Emergency' | 'Mason' | 'Electrician' | 'Plumber' | 'Painter' | 'Gas' | 'Other';

export interface ServiceContact {
  id: string;
  name: string;
  phone: string;
  category: ServiceCategory;
  isEmergency?: boolean; // Pinned at top
  image?: string; // Tenant Profile Photo
  profession?: string; // NEW: Profession/Occupation
}

export interface WeatherData {
  temp: number;
  humidity?: number;
  condition?: string;
  isNight: boolean;
  code: number;
  loading: boolean;
}

export interface AppData {
  tenants: Tenant[];
  units: Unit[];
  bills: Bill[];
  todos: Todo[];
  expenses: Expense[]; 
  serviceContacts: ServiceContact[]; 
  medicines?: Medicine[]; // Added Medicine List
  notepad?: string; 
  settings: AppSettings;
}

export interface AppSettings {
  unitPrice: number; // Electricity unit price (Global Default)
  waterFixed: number;
  gasFixed: number;
  serviceFixed: number;
  energyLimit?: number; // New field for vibration threshold
  rentPaymentDeadline?: number; // New field: Day of month for rent deadline
  theme: 'neon' | 'light'; // Changed 'dark' to 'light' for clearer toggle
  closingDate: number; 
  security: {
    pin: string; // 4 digit pin
    isEnabled: boolean;
    lockTimerMinutes: number; // 5, 10, 15
  };
  owner: UserProfile;
  developer: DeveloperProfile; // New field for dynamic About section
}