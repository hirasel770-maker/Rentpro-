
import React, { useState, useRef } from 'react';
import { AppData } from '../types';
import { compressImage } from '../pages/services/imageService';
import { signInWithGoogle, signOut } from '../pages/services/authService';
import { saveData } from '../pages/services/storageService'; // Import saveData
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { startContinuousAlarm, stopContinuousAlarm, scheduleMonthlyDefaulterNotification, syncAlarmsWithSystem } from '../pages/services/notificationService'; 
import { Capacitor } from '@capacitor/core';
import { X, User, Settings, Camera, Moon, Sun, Upload, Info, Phone, Mail, Database, LogOut, Cloud, Loader2, ChevronLeft, Zap, FileSpreadsheet, Save, BellRing, CalendarClock, RefreshCw, BookOpen, LayoutGrid, Users, CreditCard, PenTool, Lock } from 'lucide-react';

interface Props {
  data: AppData;
  setData: (data: AppData) => void;
  onClose: () => void;
}

const DEMO_AVATAR = "https://cdn-icons-png.flaticon.com/512/4140/4140048.png";

const SettingsModal: React.FC<Props> = ({ data, setData, onClose }) => {
  const { owner, developer } = data.settings;
  const isLight = data.settings.theme === 'light';
  const isWeb = Capacitor.getPlatform() === 'web';
  
  // Local edit states
  const [isEditing, setIsEditing] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showGuide, setShowGuide] = useState(false); 
  const [tempName, setTempName] = useState(owner.name);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isTestingAlarm, setIsTestingAlarm] = useState(false);
  
  // Advanced Settings State
  const [energyLimit, setEnergyLimit] = useState(data.settings.energyLimit?.toString() || '200');
  const [rentDeadline, setRentDeadline] = useState(data.settings.rentPaymentDeadline?.toString() || '8');
  
  // Security State
  const [securityPin, setSecurityPin] = useState(data.settings.security.pin || '');
  const [securityEnabled, setSecurityEnabled] = useState(data.settings.security.isEnabled || false);

  // File Input Refs
  const fileInputRef = useRef<HTMLInputElement>(null);

  const toggleTheme = () => {
    const newTheme = isLight ? 'neon' : 'light';
    setData({ ...data, settings: { ...data.settings, theme: newTheme } });
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const compressed = await compressImage(file, 200, 0.7);
        setData({
           ...data,
           settings: { ...data.settings, owner: { ...owner, photo: compressed } }
        });
      } catch (err) {
        alert("Failed to update photo");
      }
    }
  };

  const saveName = () => {
      setData({ ...data, settings: { ...data.settings, owner: { ...owner, name: tempName } } });
      setIsEditing(false);
  };
  
  const saveAdvanced = async () => {
      const limit = Number(energyLimit) || 200;
      const deadline = Number(rentDeadline) || 8;
      
      const updatedData = { 
          ...data, 
          settings: { 
              ...data.settings, 
              energyLimit: limit, 
              rentPaymentDeadline: deadline,
              security: {
                  ...data.settings.security,
                  pin: securityPin,
                  isEnabled: securityEnabled
              }
          } 
      };
      setData(updatedData);
      
      // Immediate Save
      await saveData(updatedData);
      
      if (Capacitor.isNativePlatform()) {
          await scheduleMonthlyDefaulterNotification(deadline);
          alert(`✅ Alarm Set!\n\nSystem will automatically ring on the ${deadline}th of every month if rent is pending.`);
      } else {
          alert("✅ Settings Saved!");
      }
      
      setShowAdvanced(false);
  };

  const handleTestAlarm = () => {
      if (isTestingAlarm) {
          stopContinuousAlarm();
          setIsTestingAlarm(false);
      } else {
          setIsTestingAlarm(true);
          startContinuousAlarm();
          setTimeout(() => {
              stopContinuousAlarm();
              setIsTestingAlarm(false);
          }, 5000);
      }
  };

  const handleManualAlarmSync = async () => {
      // Passes medicines AND rent deadline to sync everything
      await syncAlarmsWithSystem(data.medicines || [], data.settings.rentPaymentDeadline || 8);
      alert("✅ System Sync Complete!\n\nRent Alerts, Month-End Reminders & Medicine Alarms have been refreshed.");
  };

  // --- IRON-CLAD LOGIN HANDLER ---
  const handleLogin = async () => {
      setIsSyncing(true);
      const user = await signInWithGoogle();
      
      if (user) {
          // 1. Create the new definitive owner object
          const newOwner = {
              ...owner,
              name: user.displayName || owner.name || 'Landlord',
              email: user.email || owner.email,
              // Fix for undefined photo: use null coalescing or default to null if not present
              photo: user.photoURL || owner.photo || undefined,
              isLoggedIn: true,
              uid: user.uid
          };
          
          const updatedData = { ...data, settings: { ...data.settings, owner: newOwner } };
          
          // 2. Update React State IMMEDIATELY
          setData(updatedData);
          
          // 3. LAYER 2: HARD DISK LOCK
          // We save to storage immediately. We do NOT wait for the 2-second debounce timer.
          // This ensures if the app crashes or reloads instantly, the "isLoggedIn: true" is physically written to DB.
          await saveData(updatedData);
          
          console.log("🔒 Login State Locked to Persistent Storage");
      }
      setIsSyncing(false);
  };

  const handleLogout = async () => {
      await signOut();
      const updatedData = { 
          ...data, 
          settings: { 
              ...data.settings, 
              owner: { ...owner, isLoggedIn: false, uid: undefined } 
          } 
      };
      setData(updatedData);
      await saveData(updatedData); // Immediate Save on Logout too
  };

  // --- BACKUP & EXPORT HANDLERS ---
  const handleBackup = async () => {
      const fileName = `neonrent_backup_${new Date().toISOString().split('T')[0]}.json`;
      const jsonString = JSON.stringify(data);

      if (isWeb) {
          const blob = new Blob([jsonString], {type: "application/json"});
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = fileName;
          link.click();
          // FIX: Prevent Memory Leak
          setTimeout(() => URL.revokeObjectURL(url), 5000);
      } else {
          try {
              try {
                  await Filesystem.mkdir({
                      path: 'NeonRent_Backups',
                      directory: Directory.Documents,
                      recursive: true
                  });
              } catch (e) {}

              await Filesystem.writeFile({
                  path: `NeonRent_Backups/${fileName}`,
                  data: jsonString,
                  directory: Directory.Documents,
                  encoding: Encoding.UTF8
              });

              alert(`✅ Full Backup Saved!\n\nLocation: Documents > NeonRent_Backups`);
          } catch (e) {
              alert("⚠️ Could not save. Check Permissions.");
          }
      }
  };

  const handleExportCSV = async () => {
      let csvContent = "Name,Phone,Room,Rent,Due,Status\n";
      data.tenants.forEach(t => {
          const row = `"${t.name}","${t.phone}","${t.unitId}",${t.rentAmount},${t.due},${t.status}`;
          csvContent += row + "\n";
      });

      const fileName = `tenant_list_${new Date().toISOString().split('T')[0]}.csv`;

      if (isWeb) {
          const encodedUri = encodeURI("data:text/csv;charset=utf-8," + csvContent);
          const link = document.createElement("a");
          link.setAttribute("href", encodedUri);
          link.setAttribute("download", fileName);
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
      } else {
           try {
              await Filesystem.writeFile({
                  path: `NeonRent_Backups/${fileName}`,
                  data: csvContent,
                  directory: Directory.Documents,
                  encoding: Encoding.UTF8
              });
              alert(`✅ Excel List Exported!\n\nLocation: Documents > NeonRent_Backups`);
           } catch (e) {
               alert("Export failed. Check permissions.");
           }
      }
  };

  const handleRestoreClick = () => {
      fileInputRef.current?.click();
  };

  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
          try {
              const json = JSON.parse(event.target?.result as string);
              if (json && typeof json === 'object') {
                  if(confirm("⚠️ This will REPLACE all current data with the backup file. Are you sure?")) {
                      setData(json); 
                      saveData(json); // Save immediately
                      alert("✅ Data restored successfully!");
                      onClose();
                  }
              } else {
                  alert("Invalid backup file format.");
              }
          } catch (err) {
              alert("Error reading backup file.");
          }
      };
      reader.readAsText(file);
      if (e.target) e.target.value = '';
  };

  const glassContainer = "bg-white/10 backdrop-blur-2xl border border-white/20 shadow-2xl";
  const glassItem = "bg-white/5 hover:bg-white/10 transition-colors border-b border-white/5";

  // --- GUIDE CONTENT ---
  const guides = [
      { icon: LayoutGrid, title: "Dashboard", desc: "View total collected rent, pending dues, and energy usage at a glance. Tap on 'Due' or 'Collected' cards for detailed lists." },
      { icon: Users, title: "Add Tenant", desc: "Go to 'Add' (+). Enter Name, Room No, and Rent. You can upload ID/Photo. Room No connects tenants to Estate view." },
      { icon: CreditCard, title: "Billing & Rent", desc: "In 'Tenants' page: Green switch = Bill Generate. Red switch = Collect Rent. Use the Camera icon to AI scan meter readings!" },
      { icon: PenTool, title: "Tools & Utils", desc: "Use 'Utility Box' for Medicine Reminders (works offline), Currency Converter, and Emergency Contacts." },
      { icon: Database, title: "Data Safety", desc: "Use 'Backup' regularly. If you sign in with Google, data syncs to the cloud automatically." },
  ];

  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm animate-fade-in pb-safe" onClick={onClose}>
        <div 
            className={`w-full max-w-[320px] max-h-[calc(100vh-4rem)] overflow-hidden p-5 relative flex flex-col items-center animate-slide-up ${glassContainer} text-white mb-safe`}
            onClick={e => e.stopPropagation()}
        >
            {/* Header */}
            <div className="w-full flex justify-between items-center mb-1 shrink-0">
                {showAdvanced || showGuide ? (
                    <button onClick={() => { setShowAdvanced(false); setShowGuide(false); }} className="p-2 bg-white/10 rounded-full hover:bg-white/20"><ChevronLeft size={16}/></button>
                ) : (
                    <button onClick={onClose} className="p-2 bg-white/10 rounded-full hover:bg-white/20"><X size={16}/></button>
                )}
                
                <div className="flex gap-2">
                    {owner.isLoggedIn && !showAdvanced && !showGuide && <Cloud size={16} className="text-green-400 animate-pulse" />}
                    {!showAdvanced && !showGuide && (
                        <button onClick={() => setShowAdvanced(true)} className="p-2 bg-white/10 rounded-full hover:bg-white/20"><Settings size={16}/></button>
                    )}
                </div>
            </div>

            {/* --- 1. USER GUIDE VIEW --- */}
            {showGuide ? (
                <div className="flex-1 w-full overflow-y-auto min-h-0 flex flex-col pt-2 animate-fade-in">
                    <div className="text-center mb-4">
                        <div className="w-12 h-12 bg-app-accent rounded-full flex items-center justify-center mx-auto mb-2 shadow-glow">
                            <BookOpen size={24} className="text-black" />
                        </div>
                        <h3 className="font-bold text-lg">App Guide</h3>
                        <p className="text-[10px] text-gray-400">How to manage your estate</p>
                    </div>
                    
                    <div className="space-y-3 pb-4">
                        {guides.map((g, i) => (
                            <div key={i} className="bg-white/5 p-3 rounded-xl border border-white/5">
                                <div className="flex items-center gap-2 mb-1">
                                    <g.icon size={14} className="text-app-accent" />
                                    <h4 className="font-bold text-sm text-white">{g.title}</h4>
                                </div>
                                <p className="text-[11px] text-gray-400 leading-relaxed text-justify">{g.desc}</p>
                            </div>
                        ))}
                    </div>
                    <button onClick={() => setShowGuide(false)} className="w-full py-3 bg-white/10 text-white font-bold rounded-xl mt-auto active:scale-95 transition">
                        Got it!
                    </button>
                </div>
            ) : showAdvanced ? (
            /* --- 2. ADVANCED SETTINGS VIEW --- */
                <div className="flex-1 w-full overflow-y-auto min-h-0 flex flex-col pt-4 animate-slide-up">
                    <h3 className="text-center font-bold text-lg mb-6">Advanced Config</h3>
                    
                    {/* SECURITY SECTION */}
                    <div className="w-full bg-black/40 rounded-xl p-4 mb-4 border border-white/10 relative">
                        <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2 text-rose-400">
                                <Lock size={18} />
                                <span className="text-sm font-bold">App Security</span>
                            </div>
                            <label className="relative inline-flex items-center cursor-pointer">
                                <input 
                                    type="checkbox" 
                                    checked={securityEnabled} 
                                    onChange={(e) => setSecurityEnabled(e.target.checked)} 
                                    className="sr-only peer"
                                />
                                <div className="w-9 h-5 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-rose-500"></div>
                            </label>
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] text-gray-400 font-bold uppercase">4-Digit Lock PIN</label>
                            <input 
                                type="tel" 
                                maxLength={4}
                                value={securityPin}
                                onChange={(e) => setSecurityPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                                placeholder="0000"
                                className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-2 text-white font-black text-center text-lg tracking-[8px] outline-none focus:border-rose-500 transition-colors placeholder-gray-600"
                            />
                        </div>
                    </div>

                    <div className="w-full bg-white/5 rounded-xl p-4 mb-4 border border-white/10">
                        <div className="flex items-center gap-2 mb-2 text-yellow-400">
                            <Zap size={18} />
                            <span className="text-sm font-bold">Energy Shake Limit</span>
                        </div>
                        <div className="flex gap-2">
                            <input 
                                type="number" 
                                value={energyLimit}
                                onChange={(e) => setEnergyLimit(e.target.value)}
                                className="flex-1 bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-white font-bold outline-none"
                            />
                            <span className="flex items-center text-xs font-bold text-gray-500">Units</span>
                        </div>
                    </div>

                    <div className="w-full bg-white/5 rounded-xl p-4 mb-4 border border-white/10">
                        <div className="flex items-center gap-2 mb-2 text-blue-400">
                            <CalendarClock size={18} />
                            <span className="text-sm font-bold">Rent Deadline Day</span>
                        </div>
                        <div className="flex gap-2">
                            <input 
                                type="number" 
                                value={rentDeadline}
                                onChange={(e) => setRentDeadline(e.target.value)}
                                max={31}
                                min={1}
                                className="flex-1 bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-white font-bold outline-none"
                            />
                            <span className="flex items-center text-xs font-bold text-gray-500">of Month</span>
                        </div>
                    </div>

                    <div className="w-full bg-white/5 rounded-xl p-4 mb-4 border border-white/10">
                        <div className="flex items-center gap-2 mb-2 text-red-400">
                            <BellRing size={18} />
                            <span className="text-sm font-bold">System Alarm Check</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                             <button 
                                onClick={handleTestAlarm}
                                className={`py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition active:scale-95 ${isTestingAlarm ? 'bg-red-500 text-white animate-pulse' : 'bg-gray-700 text-gray-300'}`}
                             >
                                {isTestingAlarm ? 'Stop' : 'Test Sound'}
                             </button>
                             
                             <button 
                                onClick={handleManualAlarmSync}
                                className="py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition active:scale-95 bg-blue-500 text-white"
                             >
                                <RefreshCw size={14} /> Re-Sync
                             </button>
                        </div>
                    </div>

                    <button onClick={saveAdvanced} className="w-full py-3 bg-green-500 text-white font-bold rounded-xl mt-auto shadow-lg active:scale-95 transition">
                        Save Changes
                    </button>
                </div>
            ) : (
                /* --- 3. MAIN SETTINGS VIEW --- */
                <div className="flex-1 w-full overflow-y-auto min-h-0 flex flex-col items-center scrollbar-hide">
                    {/* Profile Avatar */}
                    <div className="relative mb-2 mt-1 group shrink-0">
                        <div className="absolute inset-0 bg-gradient-to-tr from-blue-500 to-purple-500 rounded-full blur-md opacity-70 group-hover:opacity-100 transition"></div>
                        <div className="relative w-16 h-16 rounded-full p-[2px] bg-gradient-to-tr from-white/50 to-white/10">
                            <div className="w-full h-full rounded-full overflow-hidden bg-gray-900 relative">
                                {/* Use uploaded photo OR Demo Avatar */}
                                <img src={owner.photo || DEMO_AVATAR} className="w-full h-full object-cover" alt="Profile" />
                                
                                {owner.isLoggedIn && (
                                    <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-black z-10"></div>
                                )}
                                
                                {/* Always show Camera Overlay to allow uploading "when I want" */}
                                <label className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 cursor-pointer transition">
                                    <Camera size={16} />
                                    <input type="file" className="hidden" accept="image/*" onChange={handlePhotoUpload} />
                                </label>
                            </div>
                        </div>
                    </div>

                    {/* Name / Login Status */}
                    {isEditing && !owner.isLoggedIn ? (
                        <div className="flex gap-2 mb-4 w-full justify-center shrink-0">
                            <input 
                                value={tempName} 
                                onChange={e => setTempName(e.target.value)} 
                                onFocus={e => e.target.select()}
                                autoFocus
                                className="bg-white/10 border border-white/20 rounded-lg px-2 py-1 text-center font-bold outline-none w-32 text-sm"
                            />
                            <button onClick={saveName} className="text-xs bg-green-500 px-2 rounded font-bold">OK</button>
                        </div>
                    ) : (
                        <div className="text-center mb-4 shrink-0">
                            <h2 onClick={() => !owner.isLoggedIn && setIsEditing(true)} className="text-base font-bold cursor-pointer hover:text-gray-300 transition flex items-center justify-center gap-1">
                                {owner.name} 
                            </h2>
                            <p className="text-[10px] text-gray-400">{owner.isLoggedIn ? owner.email : 'Local Account'}</p>
                        </div>
                    )}

                    {/* AUTH BUTTON */}
                    {owner.isLoggedIn ? (
                        <button 
                            onClick={handleLogout}
                            className="w-full mb-4 py-2 bg-red-500/20 text-red-400 rounded-xl text-xs font-bold border border-red-500/30 flex items-center justify-center gap-2 hover:bg-red-500/30 transition shrink-0"
                        >
                            <LogOut size={14}/> Sign Out
                        </button>
                    ) : (
                        <button 
                            onClick={handleLogin}
                            disabled={isSyncing}
                            className="w-full mb-4 py-3 bg-white text-black rounded-xl text-xs font-bold shadow-lg flex items-center justify-center gap-2 active:scale-95 transition shrink-0"
                        >
                            {isSyncing ? <Loader2 size={16} className="animate-spin"/> : <img src="https://www.google.com/favicon.ico" className="w-4 h-4" />}
                            Sign in with Google
                        </button>
                    )}

                    {/* Menu Items */}
                    <div className="w-full rounded-2xl overflow-hidden bg-black/20 backdrop-blur-md border border-white/5 mb-4 shrink-0">
                        <div className={`p-3 flex items-center justify-between ${glassItem}`}>
                            <div className="flex items-center gap-2">
                                {isLight ? <Sun size={16} className="text-yellow-400"/> : <Moon size={16} className="text-purple-400"/>}
                                <span className="text-xs font-medium">Mode</span>
                            </div>
                            <button 
                                onClick={toggleTheme} 
                                className={`w-14 h-7 rounded-full relative transition-colors flex items-center border ${isLight ? 'bg-gray-200 border-gray-300' : 'bg-black border-gray-600'}`}
                            >
                                <div className={`absolute w-5 h-5 rounded-full shadow-md transition-all duration-300 flex items-center justify-center ${isLight ? 'right-1 bg-white text-yellow-500' : 'left-1 bg-gray-800 text-purple-400'}`}>
                                    {isLight ? <Sun size={12} fill="currentColor"/> : <Moon size={12} fill="currentColor"/>}
                                </div>
                            </button>
                        </div>
                    </div>

                    {/* DATA MANAGEMENT SECTION */}
                    <div className="w-full mb-4 shrink-0">
                        <div className="flex items-center justify-between mb-2 px-1">
                            <div className="flex items-center gap-2">
                                <Database size={14} className="text-orange-400" />
                                <span className="text-[10px] font-bold uppercase text-gray-400 tracking-widest">Data & Help</span>
                            </div>
                            {owner.isLoggedIn && <span className="text-[9px] text-green-400 font-medium">Cloud Sync Active</span>}
                        </div>
                        
                        <div className="grid grid-cols-4 gap-2">
                            <button onClick={handleBackup} className="bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl p-2 flex flex-col items-center justify-center gap-1 transition-all active:scale-95">
                                <Save size={16} className="text-green-400" />
                                <span className="text-[8px] font-bold text-gray-300">Backup</span>
                            </button>
                            
                            <button onClick={handleExportCSV} className="bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl p-2 flex flex-col items-center justify-center gap-1 transition-all active:scale-95">
                                <FileSpreadsheet size={16} className="text-emerald-400" />
                                <span className="text-[8px] font-bold text-gray-300">Excel</span>
                            </button>

                            <button onClick={handleRestoreClick} className="bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl p-2 flex flex-col items-center justify-center gap-1 transition-all active:scale-95">
                                <Upload size={16} className="text-blue-400" />
                                <span className="text-[8px] font-bold text-gray-300">Restore</span>
                            </button>

                            <button onClick={() => setShowGuide(true)} className="bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl p-2 flex flex-col items-center justify-center gap-1 transition-all active:scale-95">
                                <BookOpen size={16} className="text-app-accent" />
                                <span className="text-[8px] font-bold text-app-accent">Guide</span>
                            </button>
                        </div>
                        <input type="file" ref={fileInputRef} onChange={handleRestoreFile} className="hidden" accept=".json" />
                    </div>

                    {/* DEVELOPER SECTION */}
                    <div className="w-full rounded-2xl overflow-hidden bg-blue-500/10 border border-blue-500/20 mb-4 p-3 relative shrink-0">
                        <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                                <Info size={16} className="text-blue-400"/>
                                <span className="text-xs font-bold text-blue-300">About Developer</span>
                            </div>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="w-12 h-12 rounded-xl bg-gray-800 border border-gray-700 overflow-hidden flex-shrink-0 relative group">
                                <img src={developer?.photo || 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png'} className="w-full h-full object-cover" alt="Developer" />
                            </div>
                            
                            <div className="flex-1 min-w-0">
                                <h4 className="font-bold text-sm text-white truncate">{developer?.name || 'Unknown Developer'}</h4>
                                {developer?.phone && (
                                    <a href={`tel:${developer.phone}`} className="flex items-center gap-1 text-[10px] text-gray-400 hover:text-green-400 transition mt-1">
                                        <Phone size={10} /> {developer.phone}
                                    </a>
                                )}
                                {developer?.email && (
                                    <a href={`mailto:${developer.email}`} className="flex items-center gap-1 text-[10px] text-gray-400 hover:text-blue-400 transition truncate mt-0.5">
                                        <Mail size={10} /> {developer.email}
                                    </a>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            )}

        </div>
    </div>
  );
};

export default SettingsModal;
