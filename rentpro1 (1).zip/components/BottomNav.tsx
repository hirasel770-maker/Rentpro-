
import React, { useEffect, useState, useMemo } from 'react';
import { 
  LayoutGrid, Users, Plus, Contact, Building2, 
  // --- 1. SENSITIVE MOOD ICONS ---
  Smile, Meh, ThumbsUp, ThumbsDown, PartyPopper, Diamond, Shield,
  Frown, AlertTriangle, Skull, CloudRain, Droplets, Bomb, Flame,
  // --- 2. CANVAS COLLECTION (MASSIVE VARIETY) ---
  Rocket, Moon, Star, Sun, Snowflake, Zap, CloudLightning,
  Leaf, Flower, Trees, Mountain, Sunset, Wind, Umbrella, Anchor,
  Cat, Dog, Fish, Bird, Bug, Bot, Ghost, Baby, Brain, Fingerprint, Dna,
  Gamepad2, Headphones, Camera, Watch, Car, Bike, Key, Bell, Lightbulb, 
  Radio, Mic, Speaker, Smartphone, Laptop, Tv, Printer, Scan,
  Wrench, Hammer, Axe, Briefcase, Calculator, Compass, Flag, Gift,
  Glasses, Magnet, Map, MapPin, Navigation, Package, PenTool, Scissors,
  Crown, Trophy, Medal, Target, Tent, Ticket, Truck, Wallet, Coins,
  Coffee, Pizza, Utensils, Wine, Beer, Cake, Cookie, Candy,
  Circle, Square, Triangle, Hexagon, Octagon, Box, Layers,
  Activity, Heart, Music, Play, Pause, Power, RefreshCw, Send,
  Globe, Plane, Train, Bus, Ship,
  Sword, ShieldCheck, Skull as Skull2, Sprout, Stamp
} from 'lucide-react';
import { Page, AppData } from '../types';

interface Props {
  data: AppData;
  activePage: Page;
  setPage: (page: Page) => void;
  visible: boolean;
}

// --- CONFIG: The "Canvas" Engine ---
const ANIMATION_INTERVAL_MS = 2800; // Change every 2.8s

const ANIMATIONS = [
    'animate-bounce', 'animate-spin', 'animate-pulse', 'animate-ping',
    'animate-tada', 'animate-jello', 'animate-rubberBand', 'animate-swing',
    'animate-wobble', 'animate-bounce-in', 'animate-roll-in', 
    'animate-zoom-in-down', 'animate-flip', 'animate-light-speed'
];

const COLORS = [
    '#CCF381', // Lime (Brand)
    '#00FFFF', // Cyan
    '#FF00FF', // Magenta
    '#FFD700', // Gold
    '#00FF7F', // Spring Green
    '#FF69B4', // Hot Pink
    '#F4A261', // Orange
    '#E76F51', // Burnt Sienna
    '#2A9D8F', // Teal
    '#9D4EDD', // Deep Purple
    '#FF4444', // Red
    '#4DA8DA', // Sky Blue
    '#FFFFFF', // White
];

// Combine all icons into a massive array
const MEGA_ICON_SET = [
    Rocket, Moon, Star, Sun, Snowflake, Flame, Zap, CloudLightning,
    Leaf, Flower, Trees, Mountain, Sunset, Wind, Umbrella, Anchor,
    Cat, Dog, Fish, Bird, Bug, Bot, Ghost, Baby, Brain, Fingerprint, Dna,
    Gamepad2, Headphones, Camera, Watch, Car, Bike, Key, Bell, Lightbulb, 
    Radio, Mic, Speaker, Smartphone, Laptop, Tv, Printer, Scan,
    Wrench, Hammer, Axe, Briefcase, Calculator, Compass, Flag, Gift,
    Glasses, Magnet, Map, MapPin, Navigation, Package, PenTool, Scissors,
    Crown, Trophy, Medal, Target, Tent, Ticket, Truck, Wallet, Coins,
    Coffee, Pizza, Utensils, Wine, Beer, Cake, Cookie, Candy,
    Circle, Square, Triangle, Hexagon, Octagon, Box, Layers,
    Activity, Heart, Music, Play, Pause, Power, RefreshCw, Send,
    Globe, Plane, Train, Bus, Ship,
    Sword, ShieldCheck, Skull2, Sprout, Stamp,
    Smile, PartyPopper, Diamond
];

type Mood = 'normal' | 'happy' | 'sad' | 'alert' | 'love' | 'rain' | 'rich' | 'angry' | 'success' | 'magic' | 'delete';

const BottomNav: React.FC<Props> = ({ data, activePage, setPage, visible }) => {
  // Base Mood (Passive)
  const [baseMood, setBaseMood] = useState<Mood>('normal');
  
  // Reactive Mood (Active) - Overrides base mood for a short time
  const [activeMood, setActiveMood] = useState<Mood | null>(null);
  const [activeDuration, setActiveDuration] = useState(0);

  const [dynamicIcon, setDynamicIcon] = useState<any>(Plus);
  const [dynamicColor, setDynamicColor] = useState('#CCF381'); 
  const [animationClass, setAnimationClass] = useState('');
  const [iconKey, setIconKey] = useState(0); 
  const [clickShockwave, setClickShockwave] = useState(false);

  const isLight = data.settings.theme === 'light';

  // --- 1. EVENT LISTENER FOR REACTIVE EMOTIONS ---
  useEffect(() => {
      const handleEmotion = (e: any) => {
          const type = e.detail?.type as Mood;
          if (!type) return;

          setActiveMood(type);
          setActiveDuration(Date.now() + 3000); // 3 seconds duration
          setIconKey(prev => prev + 1); // Force re-render animation
          
          // Immediate visual update based on type
          if (type === 'rich') {
              setDynamicIcon(Crown);
              setDynamicColor('#FFD700');
              setAnimationClass('animate-bounce');
          } else if (type === 'success') {
              setDynamicIcon(ThumbsUp);
              setDynamicColor('#00FF7F');
              setAnimationClass('animate-tada');
          } else if (type === 'angry' || type === 'delete') {
              setDynamicIcon(Skull);
              setDynamicColor('#FF0000');
              setAnimationClass('animate-shake');
          } else if (type === 'sad') {
              setDynamicIcon(CloudRain);
              setDynamicColor('#4DA8DA');
              setAnimationClass('animate-pulse');
          } else if (type === 'magic') {
              setDynamicIcon(Zap);
              setDynamicColor('#FF00FF');
              setAnimationClass('animate-spin-slow');
          } else if (type === 'love') {
              setDynamicIcon(Heart);
              setDynamicColor('#FF69B4');
              setAnimationClass('animate-heartbeat');
          }
      };

      window.addEventListener('neon-emotion', handleEmotion);
      return () => window.removeEventListener('neon-emotion', handleEmotion);
  }, []);

  // --- 2. SENSITIVE MOOD DETECTION (Business Logic - Passive) ---
  useEffect(() => {
    const totalDue = data.tenants.reduce((acc, t) => acc + t.due, 0);
    const totalCollected = data.tenants.reduce((acc, t) => t.due === 0 ? acc + t.rentAmount : acc, 0);
    const date = new Date();
    const isValentines = date.getMonth() === 1 && date.getDate() === 14;
    
    if (isValentines) { setBaseMood('love'); return; }
    
    if (totalDue > 15000) { setBaseMood('sad'); } 
    else if (totalDue > 0 && date.getDate() > 10) { setBaseMood('alert'); } 
    else if (totalCollected > 50000) { setBaseMood('rich'); } 
    else if (totalDue === 0 && data.tenants.length > 0) { setBaseMood('happy'); } 
    else { setBaseMood('normal'); }
  }, [data]);

  // --- 3. THE INFINITE CANVAS LOOP (Modified to respect Active Mood) ---
  useEffect(() => {
    if (!visible) return;
    
    const triggerLife = () => {
        // If an Active Emotion is playing, skip the random canvas loop
        if (activeMood && Date.now() < activeDuration) {
            return;
        } else if (activeMood && Date.now() >= activeDuration) {
            setActiveMood(null); // Reset active mood
        }

        // Force React to treat this as a "New" icon every time to restart animation
        setIconKey(prev => prev + 1); 

        // Use Base Mood Logic
        const currentMood = baseMood;

        if (currentMood === 'sad' || currentMood === 'alert') {
            const badIcons = [Frown, ThumbsDown, Skull, AlertTriangle, Bomb, Shield];
            setDynamicIcon(badIcons[Math.floor(Math.random() * badIcons.length)]);
            setDynamicColor(currentMood === 'sad' ? '#FF4444' : '#FF9F1C');
            setAnimationClass('animate-shake');
        } 
        else if (currentMood === 'rain') {
            setDynamicIcon(Math.random() > 0.5 ? CloudRain : Droplets);
            setDynamicColor('#4DA8DA');
            setAnimationClass('animate-bounce');
        }
        else if (currentMood === 'love') {
            setDynamicIcon(Heart);
            setDynamicColor('#FF69B4');
            setAnimationClass('animate-heartbeat');
        }
        else if (currentMood === 'rich') {
            setDynamicIcon(Diamond);
            setDynamicColor('#FFD700');
            setAnimationClass('animate-tada');
        }
        // --- THE CANVAS MODE (Normal/Happy) ---
        else {
            if (Math.random() > 0.1) {
                const randomIcon = MEGA_ICON_SET[Math.floor(Math.random() * MEGA_ICON_SET.length)];
                setDynamicIcon(randomIcon);
                const randomColor = COLORS[Math.floor(Math.random() * COLORS.length)];
                setDynamicColor(randomColor);
                const randomAnim = ANIMATIONS[Math.floor(Math.random() * ANIMATIONS.length)];
                setAnimationClass(randomAnim);
            } else {
                setDynamicIcon(Plus);
                setDynamicColor(isLight ? '#000000' : '#CCF381');
                setAnimationClass('animate-pulse');
            }
        }
    };
    
    triggerLife();
    const interval = setInterval(triggerLife, ANIMATION_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [visible, baseMood, isLight, activeMood, activeDuration]);

  // Monster Shockwave Trigger
  const handleFabClick = () => {
      setClickShockwave(true);
      if (navigator.vibrate) navigator.vibrate(100); 
      
      // Navigate immediately
      setPage('form');

      setTimeout(() => {
          setClickShockwave(false);
      }, 600);
  };

  const navItems = [
    { id: 'dashboard', icon: LayoutGrid, label: 'Home' },
    { id: 'tenants', icon: Users, label: 'Tenants' }, 
    { id: 'form', icon: Plus, label: 'Add', isFab: true },
    { id: 'units', icon: Building2, label: 'Estate' }, 
    { id: 'services', icon: Contact, label: 'Phonebook' }, 
  ];

  return (
    <div className={`fixed bottom-6 left-2 right-2 h-[76px] flex items-center justify-between px-4 z-[90] transition-all duration-500 cubic-bezier(0.4, 0, 0.2, 1) pointer-events-none ${visible ? 'translate-y-0 opacity-100' : 'translate-y-full opacity-0'}`}>
      
      {navItems.map((item) => {
        const isActive = activePage === item.id;
        // Logic: If not on Form page, show the Dynamic Canvas Icon.
        const IconToRender = item.isFab ? dynamicIcon : item.icon; 

        if (item.isFab) {
           return (
            <button
              key={item.id}
              onClick={handleFabClick}
              style={{ 
                  backgroundColor: isActive ? dynamicColor : (isLight ? '#111' : '#222'),
                  boxShadow: isActive ? `0 0 35px ${dynamicColor}80` : '0 10px 20px rgba(0,0,0,0.3)', // Stronger glow
                  borderColor: isActive ? dynamicColor : (isLight ? '#e5e7eb' : '#333'),
                  transform: isActive ? 'translateY(-30px) scale(1.1)' : 'translateY(-24px) scale(1)'
              }}
              // 3D Effect Wrapper
              className={`pointer-events-auto relative w-[56px] h-[56px] rounded-full flex items-center justify-center transition-all duration-500 border-[3px] active:scale-90 group z-50 overflow-visible
                ${isActive ? 'text-white' : 'text-white hover:bg-[#333]'}
              `}
            >
              {/* THE MONSTER SHOCKWAVE EFFECT */}
              {clickShockwave && (
                  <>
                    <div className="absolute inset-0 rounded-full bg-white opacity-50 animate-ping"></div>
                    <div className="absolute inset-0 rounded-full border-4 border-white opacity-0 animate-shockwave" style={{ animationDuration: '0.6s' }}></div>
                  </>
              )}

              {/* Alert Rings (Existing) */}
              {!clickShockwave && (baseMood === 'alert' || baseMood === 'sad') && <div className="absolute inset-0 rounded-full border-2 border-red-500 animate-ping opacity-50"></div>}
              
              {/* The Icon Canvas */}
              <div className={`${!isActive ? animationClass : ''} transition-all duration-500`}>
                  <IconToRender 
                    key={iconKey} // Key forces re-render to restart CSS animation
                    size={28} 
                    strokeWidth={2.5} 
                    className="drop-shadow-md" 
                  />
              </div>
            </button>
           )
        }

        return (
          <button
            key={item.id}
            onClick={() => setPage(item.id as Page)}
            className={`pointer-events-auto relative flex flex-col items-center justify-center h-full w-14 transition-all duration-300 group`}
          >
            <div 
                className={`transition-all duration-300 p-2.5 rounded-2xl flex items-center justify-center backdrop-blur-md
                    ${isActive 
                        ? (isLight ? 'bg-white text-black shadow-lg scale-105' : 'bg-[#1E1E24] text-[#CCF381] shadow-glow scale-105 border border-white/10') 
                        : (isLight ? 'bg-white/40 text-gray-500 hover:bg-white shadow-sm' : 'bg-black/40 text-gray-400 hover:bg-black/60 border border-white/5')
                    }
                `}
            >
                <item.icon 
                  size={isActive ? 22 : 20} 
                  strokeWidth={isActive ? 2.5 : 2}
                  className="drop-shadow-sm"
                />
            </div>
            {isActive && (
                <div className={`absolute -bottom-1 w-1 h-1 rounded-full ${isLight ? 'bg-black' : 'bg-[#CCF381]'} shadow`}></div>
            )}
          </button>
        );
      })}
    </div>
  );
};

export default BottomNav;
