import React, { useEffect, useRef, useState, ReactNode } from 'react';

interface Props {
  children?: ReactNode;
  height?: number | string;
  className?: string;
  minHeight?: number;
  minWidth?: number;
}

/**
 * FixChartWrapper
 * 
 * A robust wrapper for Recharts that delays rendering of the chart component
 * until the parent container has valid, non-zero physical dimensions.
 * This prevents the common "width(-1)" and "height(-1)" console warnings
 * and ensures charts render correctly inside tabs, modals, or flex containers.
 */
export default function FixChartWrapper({ children, height = 300, minHeight = 0, minWidth = 0, className = '' }: Props) {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const [shouldRender, setShouldRender] = useState(false);

  useEffect(() => {
    const node = wrapperRef.current;
    if (!node) return;

    // Use ResizeObserver to detect when the container actually has size
    const ro = new ResizeObserver((entries) => {
      // Use requestAnimationFrame to avoid "ResizeObserver loop limit exceeded" errors
      window.requestAnimationFrame(() => {
        if (!Array.isArray(entries) || !entries.length) return;
        
        const { width, height } = entries[0].contentRect;
        
        // Only render children if we have valid pixel dimensions
        if (width > 0 && height > 0) {
          setShouldRender(true);
        }
      });
    });

    ro.observe(node);

    // Initial check in case it's already visible
    const { width, height } = node.getBoundingClientRect();
    if (width > 0 && height > 0) {
        setShouldRender(true);
    }

    return () => ro.disconnect();
  }, []);

  const styleHeight = typeof height === 'number' ? `${height}px` : height;
  const styleMinHeight = minHeight ? `${minHeight}px` : undefined;

  return (
    <div
      ref={wrapperRef}
      className={className}
      style={{
        width: '100%',
        height: styleHeight,
        minHeight: styleMinHeight,
        minWidth: minWidth,
        position: 'relative',
        display: 'block',
        overflow: 'hidden'
      }}
    >
      {shouldRender ? (
        <div style={{ width: '100%', height: '100%' }}>
          {children}
        </div>
      ) : (
        // Placeholder to maintain layout flow while waiting for dimensions
        <div style={{ width: '100%', height: '100%' }} />
      )}
    </div>
  );
}