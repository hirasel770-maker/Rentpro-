import React, { useState, useEffect } from 'react';
import { Search, Bell, Phone, User, Calendar, Zap, CreditCard, X, AlertTriangle, Layers, ChevronRight, ChevronLeft, Eye, CheckCircle } from 'lucide-react';
import { AppData } from '../types';

interface Props {
  title?: React.ReactNode; 
  data: AppData;
  setData?: (data: AppData) => void; // Added setData for settling due
  onOpenSettings: () => void;
  onSearchClick?: () => void;
  rightAction?: React.ReactNode; 
}

const DEMO_AVATAR = "https://cdn-icons-png.flaticon.com/512/4140/4140048.png";

const TopBar: React.FC<Props> = ({ title, data, setData, onOpenSettings, onSearchClick, rightAction }) => {
  const isLight = data.settings.theme === 'light';
  const { owner } = data.settings;
  const [dateStr, setDateStr] = useState(new Date().toDateString());
  const [showRunawayModal, setShowRunawayModal] = useState(false);
  const [confirmSettleId, setConfirmSettleId] = useState<string | null>(null);
  
  // Viewer State for Evidence
  const [viewerImages, setViewerImages] = useState<{src: string, label: string}[] | null>(null);
  const [viewerIndex, setViewerIndex] = useState(0);

  // Profile Zoom State
  const [zoomedProfile, setZoomedProfile] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
        setDateStr(new Date().toDateString());
    }, 60000); 
    return () => clearInterval(timer);
  }, []);

  // Filter for Runaway Tenants (Archived + Due > 0)
  const runawayTenants = (data.tenants || []).filter(t => t.status === 'Archived' && t.due > 0);
  const hasRunaway = runawayTenants.length > 0;

  const openViewer = (images: {src: string, label: string}[]) => {
      if (images.length > 0) {
          setViewerImages(images);
          setViewerIndex(0);
      }
  };

  const nextImage = (e?: React.MouseEvent) => {
      e?.stopPropagation();
      if (viewerImages) {
          setViewerIndex((prev) => (prev + 1) % viewerImages.length);
      }
  };

  const prevImage = (e?: React.MouseEvent) => {
      e?.stopPropagation();
      if (viewerImages) {
          setViewerIndex((prev) => (prev - 1 + viewerImages.length) % viewerImages.length);
      }
  };

  // Trigger Custom Confirmation Modal
  const initiateSettle = (tenantId: string) => {
      setConfirmSettleId(tenantId);
  };

  // Actual Settle Action
  const confirmSettle = () => {
      if (!setData || !confirmSettleId) return;
      
      const updatedTenants = data.tenants.map(t => 
          t.id === confirmSettleId ? { ...t, due: 0 } : t
      );
      setData({ ...data, tenants: updatedTenants });
      setConfirmSettleId(null);
  };

  return (
    <>
    {/* Updated classes for Glassmorphism in BOTH Light and Dark modes */}
    <div className={`sticky top-0 left-0 w-full h-[70px] flex items-center justify-between px-5 z-40 transition-all duration-300 border-b 
        ${isLight 
            ? 'bg-white/40 backdrop-blur-xl border-white/30 shadow-[0_4px_30px_rgba(0,0,0,0.03)]' 
            : 'bg-black/30 backdrop-blur-xl border-white/5 shadow-[0_4px_30px_rgba(0,0,0,0.2)]'
        }`}>
        
        {/* Left: Title & Date */}
        <div className="flex flex-col justify-center">
            {title ? (
                <h1 className={`text-lg font-black tracking-tight leading-tight ${isLight ? 'text-gray-800' : 'text-white'}`}>{title}</h1>
            ) : (
                <h1 className={`text-xl font-black tracking-tight leading-tight ${isLight ? 'text-gray-800' : 'text-white'}`}>Rent<span className="text-app-accent">Manager</span></h1>
            )}
            <p className={`text-[10px] font-bold uppercase tracking-widest ${isLight ? 'text-gray-600' : 'text-gray-400 opacity-60'}`}>{dateStr}</p>
        </div>

        {/* Right: Profile & Actions */}
        <div className="flex items-center gap-3">
            
            {/* Optional Right Action */}
            {rightAction}

            {/* RUNAWAY BELL (New Feature) - Shows only if due exists in archive */}
            {hasRunaway && (
                <button 
                    onClick={() => setShowRunawayModal(true)}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-all active:scale-90 shadow-lg relative overflow-hidden group ${isLight ? 'bg-red-100 text-red-600' : 'bg-red-500/20 text-red-500'}`}
                >
                    <Bell size={18} className="animate-[swing_1s_ease-in-out_infinite]" />
                    <span className="absolute top-1.5 right-2 w-1.5 h-1.5 bg-red-600 rounded-full animate-ping"></span>
                </button>
            )}

            {/* Quick Search Icon (Only if onSearchClick is passed) */}
            {onSearchClick && (
                <button 
                    onClick={onSearchClick}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-all active:scale-90 ${isLight ? 'bg-white/50 text-gray-600 hover:bg-white' : 'bg-white/5 text-gray-300 hover:bg-white/10'}`}
                >
                    <Search size={18} />
                </button>
            )}

            {/* Profile / Settings Trigger */}
            <button onClick={onOpenSettings} className="relative group active:scale-95 transition">
                <div className={`w-10 h-10 rounded-full overflow-hidden border-2 transition-all ${isLight ? 'border-white/50 shadow-md' : 'border-white/10 bg-white/5 hover:border-app-accent'}`}>
                    <img 
                        src={owner.photo || DEMO_AVATAR} 
                        className="w-full h-full object-cover" 
                        alt="Profile" 
                    />
                </div>
            </button>
        </div>
    </div>

    {/* RUNAWAY TENANTS MODAL */}
    {showRunawayModal && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in pb-safe" onClick={() => setShowRunawayModal(false)}>
            <div className={`w-full max-w-sm rounded-[32px] overflow-hidden flex flex-col max-h-[85vh] shadow-2xl relative ${isLight ? 'bg-white' : 'bg-[#121214] border border-red-500/30'}`} onClick={e => e.stopPropagation()}>
                
                {/* Header */}
                <div className={`p-5 border-b flex justify-between items-center shrink-0 ${isLight ? 'bg-red-50 border-red-100' : 'bg-red-900/20 border-red-500/20'}`}>
                    <div className="flex items-center gap-2">
                        <div className="bg-red-500 text-white p-2 rounded-full shadow-lg animate-pulse"><AlertTriangle size={20}/></div>
                        <div>
                            <h3 className={`font-black text-lg ${isLight ? 'text-black' : 'text-white'}`}>Runaway Alert</h3>
                            <p className="text-[10px] text-red-500 font-bold uppercase tracking-wider">{runawayTenants.length} Tenants Found</p>
                        </div>
                    </div>
                    <button onClick={() => setShowRunawayModal(false)} className="p-2 bg-black/5 rounded-full hover:bg-black/10 transition"><X size={20} className={isLight ? 'text-gray-500' : 'text-gray-400'}/></button>
                </div>

                {/* List - Added min-h-0 to guarantee scrolling in flex containers */}
                <div className="flex-1 overflow-y-auto min-h-0 p-4 space-y-4 overscroll-contain">
                    {runawayTenants.map(t => {
                        // Find last bill info to guess leaving date
                        const lastBill = data.bills
                            .filter(b => b.tenantId === t.id)
                            .sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
                        
                        const leaveDate = lastBill ? new Date(lastBill.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }) : 'Unknown Date';

                        // Prepare Image Arrays
                        const identityImages = [
                            t.idImage ? { src: t.idImage, label: 'NID FRONT' } : null,
                            t.idBackImage ? { src: t.idBackImage, label: 'NID BACK' } : null
                        ].filter(Boolean) as {src: string, label: string}[];

                        const meterImages = [
                            t.entryMeterImage ? { src: t.entryMeterImage, label: 'PREV METER' } : null,
                            t.lastMeterImage ? { src: t.lastMeterImage, label: 'LATEST METER' } : null
                        ].filter(Boolean) as {src: string, label: string}[];

                        // Dynamic Due Font Size
                        const dueLength = t.due.toString().length;
                        const dueFontSize = dueLength > 6 ? 'text-xl' : 'text-2xl';

                        return (
                            <div key={t.id} className={`rounded-[24px] p-4 border-2 relative overflow-hidden flex flex-col gap-3 ${isLight ? 'bg-white border-red-100 shadow-sm' : 'bg-[#1a0505] border-red-500/30'}`}>
                                
                                {/* Top Section: Profile & Main Info */}
                                <div className="flex items-start gap-4 relative z-10">
                                    {/* Left: Profile Picture (Clickable) */}
                                    <button 
                                        onClick={() => t.profileImage && setZoomedProfile(t.profileImage)}
                                        className={`w-16 h-16 rounded-2xl border-2 overflow-hidden shrink-0 active:scale-95 transition shadow-lg ${isLight ? 'border-gray-200' : 'border-red-500/30'}`}
                                    >
                                        {t.profileImage ? <img src={t.profileImage} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center bg-gray-200 text-gray-400"><User size={28}/></div>}
                                    </button>

                                    {/* Right: Info Vertical Stack */}
                                    <div className="flex-1 min-w-0 flex flex-col">
                                        {/* Name */}
                                        <h3 className={`font-black text-lg truncate leading-tight ${isLight ? 'text-black' : 'text-white'}`}>{t.name}</h3>
                                        
                                        {/* Room (Middle) */}
                                        <span className={`text-[11px] font-bold mt-1 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>Room: {t.unitId}</span>
                                        
                                        {/* Due (Dynamic Size) */}
                                        <div className={`font-black text-red-500 leading-none mt-1 ${dueFontSize}`}>
                                            Due: ৳{t.due}
                                        </div>

                                        {/* Left Date (Under Due) */}
                                        <div className={`text-[10px] font-bold flex items-center gap-1 mt-1 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>
                                            <Calendar size={10}/> Left: {leaveDate}
                                        </div>
                                    </div>

                                    {/* Call Button */}
                                    <a href={`tel:${t.phone}`} className="w-10 h-10 rounded-full bg-green-500 text-white flex items-center justify-center shadow-lg active:scale-90 transition shrink-0"><Phone size={18}/></a>
                                </div>

                                {/* Images Section with Titles */}
                                <div className="grid grid-cols-2 gap-3 relative z-10 mt-1">
                                    
                                    {/* Column 1: NID */}
                                    <div>
                                        <p className={`text-[10px] font-bold mb-1 uppercase tracking-wider text-center ${isLight ? 'text-blue-600' : 'text-blue-400'}`}>NID: {t.idImage ? 'Available' : 'Missing'}</p>
                                        <div 
                                            onClick={() => openViewer(identityImages)}
                                            className={`relative aspect-[4/3] rounded-xl border-2 overflow-hidden cursor-pointer group active:scale-95 transition ${isLight ? 'bg-gray-100 border-gray-200' : 'bg-black/30 border-white/10'} ${identityImages.length === 0 ? 'opacity-50 pointer-events-none' : ''}`}
                                        >
                                            {identityImages.length > 0 ? (
                                                <>
                                                    <img src={identityImages[0].src} className="w-full h-full object-cover" />
                                                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                                        <Eye className="text-white drop-shadow-md" size={24} />
                                                    </div>
                                                    {identityImages.length > 1 && <div className="absolute top-2 right-2 bg-black/60 text-white text-[8px] font-bold px-1.5 rounded flex items-center gap-1"><Layers size={8}/> 2</div>}
                                                </>
                                            ) : (
                                                <div className="w-full h-full flex flex-col items-center justify-center text-gray-400"><CreditCard size={20} /></div>
                                            )}
                                        </div>
                                    </div>

                                    {/* Column 2: Meter */}
                                    <div>
                                        <p className={`text-[10px] font-bold mb-1 uppercase tracking-wider text-center ${isLight ? 'text-yellow-600' : 'text-yellow-400'}`}>METER: {t.entryMeterImage || t.lastMeterImage ? 'Available' : 'Missing'}</p>
                                        <div 
                                            onClick={() => openViewer(meterImages)}
                                            className={`relative aspect-[4/3] rounded-xl border-2 overflow-hidden cursor-pointer group active:scale-95 transition ${isLight ? 'bg-gray-100 border-gray-200' : 'bg-black/30 border-white/10'} ${meterImages.length === 0 ? 'opacity-50 pointer-events-none' : ''}`}
                                        >
                                            {meterImages.length > 0 ? (
                                                <>
                                                    <img src={meterImages[meterImages.length - 1].src} className="w-full h-full object-cover" />
                                                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                                        <Eye className="text-white drop-shadow-md" size={24} />
                                                    </div>
                                                    {meterImages.length > 1 && <div className="absolute top-2 right-2 bg-black/60 text-white text-[8px] font-bold px-1.5 rounded flex items-center gap-1"><Layers size={8}/> 2</div>}
                                                </>
                                            ) : (
                                                <div className="w-full h-full flex flex-col items-center justify-center text-gray-400"><Zap size={20} /></div>
                                            )}
                                        </div>
                                    </div>

                                </div>

                                {/* SETTLE BUTTON */}
                                {setData && (
                                    <button 
                                        onClick={(e) => { 
                                            e.preventDefault(); 
                                            e.stopPropagation(); 
                                            initiateSettle(t.id); 
                                        }}
                                        className="w-full py-3 bg-green-500 text-white font-black rounded-xl shadow-lg active:scale-95 transition flex items-center justify-center gap-2 relative z-10"
                                    >
                                        <CheckCircle size={18} /> OK / SETTLED
                                    </button>
                                )}

                                {/* Background Decoration - Added pointer-events-none to prevent blocking clicks */}
                                <div className="absolute -bottom-4 -right-4 text-red-500/5 rotate-[-20deg] pointer-events-none"><Zap size={120} /></div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    )}

    {/* CONFIRM SETTLE MODAL - REPLACES WINDOW.CONFIRM */}
    {confirmSettleId && (
        <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in" onClick={() => setConfirmSettleId(null)}>
            <div className={`w-full max-w-xs rounded-[24px] p-6 shadow-2xl relative flex flex-col items-center text-center animate-slide-up ${isLight ? 'bg-white' : 'bg-[#1E1E24] border border-gray-700'}`} onClick={e => e.stopPropagation()}>
                <div className="w-12 h-12 bg-green-500/20 text-green-500 rounded-full flex items-center justify-center mb-4 ring-4 ring-green-500/10">
                    <CheckCircle size={28} />
                </div>
                <h3 className={`text-lg font-black mb-2 ${isLight ? 'text-black' : 'text-white'}`}>Money Received?</h3>
                <p className={`text-sm mb-6 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>"Have you received the money?"</p>
                <div className="flex gap-3 w-full">
                    <button 
                        onClick={() => setConfirmSettleId(null)} 
                        className={`flex-1 py-3 rounded-xl font-bold text-sm ${isLight ? 'bg-gray-100 text-gray-600' : 'bg-white/5 text-gray-400'}`}
                    >
                        No
                    </button>
                    <button 
                        onClick={confirmSettle} 
                        className="flex-1 py-3 rounded-xl font-bold text-sm bg-green-500 text-white shadow-lg active:scale-95 transition"
                    >
                        Yes
                    </button>
                </div>
            </div>
        </div>
    )}

    {/* PROFILE ZOOM MODAL */}
    {zoomedProfile && (
        <div className="fixed inset-0 z-[10000] bg-black/90 backdrop-blur-sm flex items-center justify-center p-6 animate-fade-in" onClick={() => setZoomedProfile(null)}>
            <div className="relative max-w-sm w-full bg-white p-2 rounded-[20px] shadow-2xl animate-zoom-in-down" onClick={e => e.stopPropagation()}>
                <img src={zoomedProfile} className="w-full h-auto rounded-[16px] object-cover aspect-[3/4]" alt="Passport Profile" />
                <button 
                    onClick={() => setZoomedProfile(null)}
                    className="absolute -top-4 -right-4 bg-white text-black p-2 rounded-full shadow-lg active:scale-90"
                >
                    <X size={24} />
                </button>
                <div className="absolute bottom-4 left-0 right-0 text-center">
                    <span className="bg-black/60 text-white text-xs font-bold px-3 py-1 rounded-full backdrop-blur-md">Passport View</span>
                </div>
            </div>
        </div>
    )}

    {/* FULL SCREEN EVIDENCE VIEWER */}
    {viewerImages && (
        <div className="fixed inset-0 z-[10000] bg-black flex flex-col animate-fade-in" onClick={() => setViewerImages(null)}>
            {/* Header */}
            <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center z-10 bg-gradient-to-b from-black/80 to-transparent pb-12" onClick={e => e.stopPropagation()}>
                <div className="text-white">
                    <h3 className="font-black text-lg tracking-wider text-app-accent">{viewerImages[viewerIndex].label}</h3>
                    <p className="text-xs text-gray-300 font-bold">{viewerIndex + 1} / {viewerImages.length}</p>
                </div>
                <button onClick={() => setViewerImages(null)} className="bg-white/10 p-2 rounded-full text-white backdrop-blur-md hover:bg-white/20"><X size={20}/></button>
            </div>

            {/* Image Area - TAP TO SWITCH */}
            <div className="flex-1 flex items-center justify-center relative overflow-hidden" onClick={(e) => { e.stopPropagation(); nextImage(); }}>
                <img 
                    src={viewerImages[viewerIndex].src} 
                    className="max-w-full max-h-full object-contain transition-all duration-300 animate-zoom-in-down"
                    alt="Evidence"
                />
                
                {/* Nav Hints (Only if multiple) */}
                {viewerImages.length > 1 && (
                    <>
                        <button onClick={prevImage} className="absolute left-4 p-3 rounded-full bg-black/50 text-white backdrop-blur-sm border border-white/10 active:scale-90 transition"><ChevronLeft/></button>
                        <button onClick={nextImage} className="absolute right-4 p-3 rounded-full bg-black/50 text-white backdrop-blur-sm border border-white/10 active:scale-90 transition"><ChevronRight/></button>
                    </>
                )}
            </div>

            {/* Footer Caption */}
            <div className="absolute bottom-10 left-0 right-0 text-center pointer-events-none">
                <span className="bg-black/60 text-white text-xs font-bold px-4 py-2 rounded-full backdrop-blur-md border border-white/10">
                    Tap image to switch view
                </span>
            </div>
        </div>
    )}
    </>
  );
};

export default TopBar;