
import path from 'path';
import { fileURLToPath } from 'url';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, '.', '');
    return {
      base: './', // Ensures relative paths for assets (Fixes blank screen on Netlify/WebToApk)
      server: {
        port: 3000,
        host: '0.0.0.0',
      },
      build: {
        target: 'es2020', // CRITICAL: Ensures compatibility with webviews and older browsers
        outDir: 'dist',
        assetsDir: 'assets',
        emptyOutDir: true,
        sourcemap: false, // Disable sourcemaps for production
      },
      plugins: [react()],
      define: {
        // Safe stringify ensuring undefined is handled
        'process.env.API_KEY': JSON.stringify(env.API_KEY || ""),
      },
      resolve: {
        alias: {
          '@': path.resolve(__dirname, '.'),
        }
      }
    };
});