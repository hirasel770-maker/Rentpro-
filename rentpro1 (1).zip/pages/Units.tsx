import React, { useState, useEffect } from 'react';
import { AppData, Unit, Tenant } from '../types';
import TopBar from '../components/TopBar';
import { triggerNavEmotion } from './services/notificationService';
import { Zap, Home, Plus, X, User, Phone, Eye, CreditCard, Rotate3D, Share2, Layers, RefreshCw, Wallet, AlertCircle, CheckCircle2, Sparkles, ArrowRightLeft, RotateCw, Trash2, Archive, Search, Calendar } from 'lucide-react';

interface Props {
  data: AppData;
  setData: (data: AppData) => void;
  onOpenSettings: () => void;
}

const EstateControlRoom: React.FC<Props> = ({ data, setData, onOpenSettings }) => {
  const isLight = data.settings.theme === 'light';
  
  const [searchTerm, setSearchTerm] = useState(''); 
  
  const [selectedUnit, setSelectedUnit] = useState<{ unit: Unit, tenant?: Tenant } | null>(null);
  
  const [activeDoc, setActiveDoc] = useState<'profile' | 'nid' | 'entryMeter' | 'lastMeter' | null>(null);
  const [nidSide, setNidSide] = useState<'front' | 'back'>('front'); 
  const [rotation, setRotation] = useState(0); 

  const norm = (str: string) => str ? str.trim().toLowerCase() : '';

  const filteredUnits = data.units.filter(unit => {
      const tenant = data.tenants.find(t => norm(t.unitId) === norm(unit.name) && t.status === 'Active');
      const search = norm(searchTerm);
      const matchRoom = norm(unit.name).includes(search);
      const matchTenantName = tenant ? norm(tenant.name).includes(search) : false;
      const matchPhone = tenant ? tenant.phone.includes(search) : false;
      return matchRoom || matchTenantName || matchPhone;
  });

  const syncRoomsFromTenants = () => {
      const existingNames = new Set(data.units.map(u => norm(u.name)));
      const newUnits: Unit[] = [];
      data.tenants.forEach(t => {
          if (t.status === 'Active' && t.unitId && !existingNames.has(norm(t.unitId))) {
              newUnits.push({ id: 'auto_' + Date.now() + Math.random(), name: t.unitId, meterNumber: t.meterNumber || 'N/A', currentMeterReading: t.currentMeterReading || 0, status: 'occupied' });
              existingNames.add(norm(t.unitId));
          }
      });
      if (newUnits.length > 0) {
          setData({ ...data, units: [...data.units, ...newUnits] });
          alert(`✅ ${newUnits.length} rooms auto-created!`);
      } else {
          alert("All active tenants already have rooms assigned.");
      }
  };

  const handleDeleteUnit = (id: string, name: string) => {
      const isOccupied = data.tenants.some(t => norm(t.unitId) === norm(name) && t.status === 'Active');
      if (isOccupied) {
          alert("Use the Archive button to remove the tenant first.");
          return;
      }
      if(confirm(`Permanently remove Room ${name}?`)) {
          setData({ ...data, units: data.units.filter(u => u.id !== id) });
          setSelectedUnit(null);
      }
  };

  const handleCardClick = (unit: Unit) => {
      const tenant = data.tenants.find(t => norm(t.unitId) === norm(unit.name) && t.status === 'Active');
      setSelectedUnit({ unit, tenant });
  };

  const shareDocument = async (imgBase64: string, name: string) => {
      if (!imgBase64) return;
      if (navigator.share) {
          try {
              const fetchRes = await fetch(imgBase64);
              const blob = await fetchRes.blob();
              const file = new File([blob], `${name}.jpg`, { type: 'image/jpeg' });
              await navigator.share({ files: [file], title: name });
          } catch (e: any) { if (e.name !== 'AbortError') console.error(e); }
      } else { alert("Sharing not supported on this device."); }
  };

  const toggleNidSide = () => {
      if (selectedUnit?.tenant?.idBackImage) { setNidSide(prev => prev === 'front' ? 'back' : 'front'); setRotation(0); }
  };

  return (
    <div className={`h-screen flex flex-col animate-fade-in ${isLight ? 'bg-[#F2F4F7]' : 'bg-[#0F1014]'}`}>
      <div className="flex-none z-50">
          <TopBar title={<><span className={isLight ? 'text-gray-800' : 'text-white'}>Estate</span><span className="text-emerald-500">Control</span></>} data={data} setData={setData} onOpenSettings={onOpenSettings} />
      </div>
      <div className="flex-1 overflow-y-auto pb-40">
          <div className={`sticky top-0 z-30 px-5 pt-4 pb-2 backdrop-blur-md ${isLight ? 'bg-[#F2F4F7]/80' : 'bg-[#0F1014]/80'}`}>
              <div className="flex justify-between items-center mb-3">
                   <div><h3 className={`text-sm font-black uppercase tracking-wider ${isLight ? 'text-gray-600' : 'text-gray-300'}`}>Floor Plan</h3><p className="text-[10px] text-gray-400 font-bold">{data.units.length} Properties Configured</p></div>
                   <div className="flex gap-2">
                       <button onClick={syncRoomsFromTenants} title="Auto-Sync" className={`flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-500 text-white text-xs font-bold shadow-lg active:scale-95 transition`}>
                           <RefreshCw size={14} /> Auto-Sync
                       </button>
                   </div>
              </div>
              <div className={`relative flex items-center px-4 rounded-2xl border transition-all ${isLight ? 'bg-white border-gray-200 focus-within:border-emerald-400 shadow-sm' : 'bg-white/5 border-white/10 focus-within:border-emerald-500/50'}`}><Search size={18} className="text-gray-500 mr-3 shrink-0" /><input value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Search Room, Name, Mobile..." className={`w-full py-3.5 bg-transparent outline-none text-sm font-bold ${isLight ? 'text-black' : 'text-white'}`} />{searchTerm && <button onClick={() => setSearchTerm('')} className="p-1 rounded-full text-gray-500"><X size={16} /></button>}</div>
          </div>
          <div className="px-5 mt-2">
              {data.units.length === 0 && (<div className="text-center py-12 border-2 border-dashed rounded-[32px] opacity-60 flex flex-col items-center"><div className="bg-gray-100 dark:bg-white/5 p-4 rounded-full mb-3"><Home size={32} className="text-gray-400"/></div><p className="text-sm font-bold mb-2">No Rooms Created Yet</p><button onClick={syncRoomsFromTenants} className="px-5 py-2.5 bg-blue-500 text-white rounded-xl text-xs font-bold shadow-lg active:scale-95 transition mt-2">⚡ Auto-Create</button></div>)}
              {searchTerm && filteredUnits.length === 0 && (<div className="text-center py-20 opacity-50"><Search size={48} className="mx-auto mb-2 text-gray-500" /><p className="text-sm font-bold text-gray-500">No results found.</p></div>)}
              <div className="grid grid-cols-2 gap-3 pb-4">
                  {filteredUnits.map(unit => {
                      const tenant = data.tenants.find(t => norm(t.unitId) === norm(unit.name) && t.status === 'Active');
                      const isOccupied = !!tenant;
                      const hasDue = tenant && tenant.due > 0;
                      const hasAdvance = tenant && tenant.advance > 0;
                      const hasHistory = tenant ? data.bills.some(b => b.tenantId === tenant.id) : false;
                      let cardBg = ""; let borderColor = ""; let shadow = ""; let roomNumColor = ""; let statusBadge = null;
                      if (!isOccupied) { cardBg = isLight ? "bg-white/60" : "bg-white/5"; borderColor = isLight ? "border-gray-200 border-dashed" : "border-white/10 border-dashed"; roomNumColor = isLight ? "text-gray-400" : "text-gray-500"; statusBadge = <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Vacant</span>; } 
                      else if (hasDue) { cardBg = isLight ? "bg-gradient-to-br from-white to-red-50" : "bg-gradient-to-br from-[#1a0505] to-[#2a0a0a]"; borderColor = "border-red-500/50"; shadow = isLight ? "shadow-md" : "shadow-glow shadow-red-500/20"; roomNumColor = "text-red-500"; statusBadge = (<div className="flex items-center gap-1 bg-red-500 text-white px-2 py-0.5 rounded-md shadow-sm"><AlertCircle size={8} fill="currentColor" className="text-red-800" /><span className="text-[9px] font-bold uppercase">Due</span></div>); } 
                      else if (!hasHistory) { cardBg = isLight ? "bg-gradient-to-br from-white to-cyan-50" : "bg-gradient-to-br from-[#05101a] to-[#0a1520]"; borderColor = "border-cyan-500/30"; shadow = isLight ? "shadow-md" : "shadow-glow shadow-cyan-500/20"; roomNumColor = "text-cyan-500"; statusBadge = (<div className="flex items-center gap-1 bg-cyan-500 text-white px-2 py-0.5 rounded-md shadow-sm"><Sparkles size={8} /><span className="text-[9px] font-bold uppercase">New</span></div>); } 
                      else { cardBg = isLight ? "bg-gradient-to-br from-white to-emerald-50" : "bg-gradient-to-br from-[#051a10] to-[#0a2015]"; borderColor = "border-emerald-500/30"; shadow = isLight ? "shadow-md" : "shadow-glow shadow-emerald-500/20"; roomNumColor = "text-emerald-500"; statusBadge = (<div className="flex items-center gap-1 bg-emerald-500 text-white px-2 py-0.5 rounded-md shadow-sm"><CheckCircle2 size={8} /><span className="text-[9px] font-bold uppercase">Paid</span></div>); }
                      return (
                          <div key={unit.id} onClick={() => handleCardClick(unit)} className={`relative min-h-[140px] w-full rounded-[24px] flex flex-col p-3.5 cursor-pointer transition-all duration-300 active:scale-95 border group ${cardBg} ${borderColor} ${shadow}`}>
                              {!isLight && isOccupied && (<div className={`absolute top-0 right-0 w-20 h-20 bg-gradient-to-br ${hasDue ? 'from-red-500' : (!hasHistory ? 'from-cyan-500' : 'from-emerald-500')} to-transparent opacity-10 blur-2xl rounded-full pointer-events-none`}></div>)}
                              <div className="flex justify-between items-start mb-3 relative z-10"><div className="flex flex-col min-w-0"><h3 className={`text-[11px] font-black uppercase tracking-wider truncate ${roomNumColor}`}>ROOM: {unit.name}</h3>{isOccupied && tenant && (<span className={`text-[8px] font-bold opacity-70 mt-0.5 flex items-center gap-0.5 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}><Calendar size={8} /> {new Date(tenant.entryDate).toLocaleDateString()}</span>)}</div><div className="shrink-0">{statusBadge}</div></div>
                              <div className="flex-1 flex flex-col justify-end relative z-10">
                                  {isOccupied ? (
                                      <><div className="flex items-center gap-2 mb-3"><div className={`w-8 h-8 rounded-full flex items-center justify-center overflow-hidden border shadow-sm ${isLight ? 'border-white bg-gray-200' : 'border-white/10 bg-gray-700'}`}>{tenant.profileImage ? <img src={tenant.profileImage} className="w-full h-full object-cover"/> : <User size={14} className="text-gray-500"/>}</div><div className="min-w-0"><p className={`text-xs font-bold truncate ${isLight ? 'text-gray-800' : 'text-gray-200'}`}>{tenant.name}</p><p className={`text-[9px] font-medium truncate ${isLight ? 'text-gray-500' : 'text-gray-500'}`}>{tenant.phone}</p></div></div><div className="space-y-1.5"><div className={`flex justify-between items-center px-2 py-1 rounded-lg border ${isLight ? 'bg-white border-gray-100' : 'bg-black/20 border-white/5'}`}><span className={`text-[9px] font-bold uppercase ${isLight ? 'text-gray-400' : 'text-gray-500'}`}>{hasDue ? 'Due' : 'Rent'}</span><span className={`text-xs font-black ${hasDue ? 'text-red-500' : (isLight ? 'text-gray-700' : 'text-white')}`}>৳{hasDue ? tenant.due : tenant.rentAmount}</span></div><div className={`flex justify-between items-center px-2 py-1 rounded-lg border ${hasAdvance ? (isLight ? 'bg-blue-50 border-blue-100' : 'bg-blue-900/10 border-blue-500/20') : (isLight ? 'bg-orange-50 border-orange-100' : 'bg-orange-900/10 border-orange-500/20')}`}><div className="flex items-center gap-1"><Wallet size={8} className={hasAdvance ? 'text-blue-500' : 'text-orange-500'} /><span className={`text-[9px] font-bold uppercase ${hasAdvance ? 'text-blue-600' : 'text-orange-600'}`}>Adv</span></div><span className={`text-[10px] font-bold ${hasAdvance ? 'text-blue-600' : 'text-orange-600'}`}>{hasAdvance ? `৳${tenant.advance}` : 'Pending'}</span></div></div></>
                                  ) : (
                                      <div className="flex flex-col items-center justify-center h-full opacity-40 mb-2"><Plus size={24} className={isLight ? 'text-gray-400' : 'text-gray-600'} /><span className="text-[9px] font-bold mt-1">Tap to Add</span></div>
                                  )}
                              </div>
                          </div>
                      );
                  })}
              </div>
          </div>
      </div>

      {selectedUnit && (
          <div className="fixed inset-0 z-[5000] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 pb-safe" onClick={() => setSelectedUnit(null)}>
              <div className={`w-full sm:max-w-sm max-h-[85vh] rounded-[32px] p-6 animate-slide-up relative flex flex-col overflow-hidden mb-20 ${isLight ? 'bg-white' : 'bg-[#18191F] border border-gray-700'}`} onClick={e => e.stopPropagation()}>
                  <div className="flex justify-between items-start mb-6 shrink-0">
                      <div><h2 className={`text-2xl font-black ${isLight ? 'text-black' : 'text-white'}`}>{selectedUnit.unit.name}</h2><div className="flex items-center gap-2 text-xs text-gray-500 mt-1"><Zap size={12} className="text-yellow-500"/> <span className="font-mono">{selectedUnit.unit.meterNumber}</span></div></div>
                      <button onClick={() => setSelectedUnit(null)} className={`p-2 rounded-xl transition ${isLight ? 'bg-gray-100 text-gray-600' : 'bg-white/10 text-white'}`}><X size={18} /></button>
                  </div>
                  <div className="flex-1 overflow-y-auto min-h-0">
                      {selectedUnit.tenant ? (
                          <>
                            <div className={`p-4 rounded-2xl border mb-4 ${isLight ? 'bg-gray-50 border-gray-200' : 'bg-black/20 border-gray-700'}`}>
                                <div className="flex items-center gap-4 mb-4"><div className="w-16 h-16 rounded-2xl bg-gray-300 overflow-hidden shrink-0 border-2 border-white/20">{selectedUnit.tenant.profileImage ? <img src={selectedUnit.tenant.profileImage} className="w-full h-full object-cover"/> : <User size={24} className="m-auto mt-4 text-gray-500"/>}</div><div><h3 className={`font-bold text-lg ${isLight ? 'text-black' : 'text-white'}`}>{selectedUnit.tenant.name}</h3><a href={`tel:${selectedUnit.tenant.phone}`} className="flex items-center gap-1 text-xs text-blue-500 font-bold mt-1"><Phone size={12}/> {selectedUnit.tenant.phone}</a>{selectedUnit.tenant.entryDate && <p className="text-[10px] text-gray-500 mt-1">Joined: {new Date(selectedUnit.tenant.entryDate).toLocaleDateString()}</p>}</div></div>
                                <div className="grid grid-cols-3 gap-2 text-center"><div className={`p-3 rounded-xl ${isLight ? 'bg-white' : 'bg-white/5'}`}><span className="text-[10px] text-gray-500 font-bold uppercase">RENT</span><div className={`text-lg font-black ${isLight ? 'text-black' : 'text-white'}`}>৳{selectedUnit.tenant.rentAmount}</div></div><div className={`p-3 rounded-xl ${selectedUnit.tenant.due > 0 ? 'bg-red-500/10' : (isLight ? 'bg-white' : 'bg-white/5')}`}><span className="text-[10px] text-gray-500 font-bold uppercase">DUE</span><div className={`text-lg font-black ${selectedUnit.tenant.due > 0 ? 'text-red-500' : 'text-emerald-500'}`}>৳{selectedUnit.tenant.due}</div></div><div className={`p-3 rounded-xl border ${isLight ? 'bg-yellow-50 border-yellow-100' : 'bg-yellow-500/10 border-yellow-500/20'}`}><span className="text-[10px] text-gray-500 font-bold uppercase">RATE</span><div className="text-lg font-black text-yellow-600">৳{selectedUnit.tenant.unitPrice !== undefined ? selectedUnit.tenant.unitPrice : data.settings.unitPrice}</div></div></div>
                                <div className={`mt-2 p-3 rounded-xl text-center border ${selectedUnit.tenant.advance > 0 ? (isLight ? 'bg-blue-50 border-blue-100' : 'bg-blue-900/10 border-blue-500/20') : (isLight ? 'bg-orange-50 border-orange-100' : 'bg-orange-900/10 border-orange-500/20')}`}><span className={`text-[10px] font-bold uppercase tracking-widest block mb-1 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>Advance Deposit</span><div className={`text-xl font-black ${selectedUnit.tenant.advance > 0 ? 'text-blue-500' : 'text-orange-500 animate-pulse'}`}>{selectedUnit.tenant.advance > 0 ? `৳${selectedUnit.tenant.advance}` : 'Pending'}</div></div>
                            </div>
                            <div>
                                <h4 className={`text-[10px] font-bold uppercase tracking-widest mb-3 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>Documents & Evidence</h4>
                                <div className="grid grid-cols-4 gap-2">
                                    <button onClick={() => { setActiveDoc('profile'); setRotation(0); }} className={`aspect-square rounded-2xl border flex flex-col items-center justify-center gap-2 relative overflow-hidden group active:scale-95 transition ${isLight ? 'bg-white border-gray-200' : 'bg-black/20 border-gray-700'}`}>{selectedUnit.tenant.profileImage ? (<><img src={selectedUnit.tenant.profileImage} className="absolute inset-0 w-full h-full object-cover opacity-80" /><div className="absolute inset-0 flex items-center justify-center bg-black/30"><Eye className="text-white" size={16} /></div><div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-[7px] font-black text-center py-0.5">FACE</div></>) : (<><User size={18} className="text-gray-500"/><span className="text-[8px] font-bold text-gray-500">No Photo</span></>)}</button>
                                    <button onClick={() => { if(selectedUnit.tenant?.idImage) { setActiveDoc('nid'); setRotation(0); setNidSide('front'); } }} className={`aspect-square rounded-2xl border flex flex-col items-center justify-center gap-2 relative overflow-hidden group active:scale-95 transition ${isLight ? 'bg-white border-gray-200' : 'bg-black/20 border-gray-700'}`}>{selectedUnit.tenant.idImage ? (<><img src={selectedUnit.tenant.idImage} className="absolute inset-0 w-full h-full object-cover opacity-80" /><div className="absolute inset-0 flex items-center justify-center bg-black/30"><CreditCard className="text-white" size={16} /></div><div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-[7px] font-black text-center py-0.5">NID</div></>) : (<><CreditCard size={18} className="text-gray-500"/><span className="text-[8px] font-bold text-gray-500">No ID</span></>)}</button>
                                    
                                    {/* UPDATED ROLLING LABELS: SLOT 1 (PREVIOUS) */}
                                    <button onClick={() => { if(selectedUnit.tenant?.entryMeterImage) { setActiveDoc('entryMeter'); setRotation(0); } }} className={`aspect-square rounded-2xl border flex flex-col items-center justify-center gap-2 relative overflow-hidden group active:scale-95 transition ${isLight ? 'bg-white border-gray-200' : 'bg-black/20 border-gray-700'}`}>{selectedUnit.tenant.entryMeterImage ? (<><img src={selectedUnit.tenant.entryMeterImage} className="absolute inset-0 w-full h-full object-cover opacity-80" /><div className="absolute inset-0 flex items-center justify-center bg-black/30"><Zap className="text-white" size={16} /></div><div className="absolute bottom-0 left-0 right-0 bg-cyan-500 text-black text-[7px] font-black text-center py-0.5 uppercase tracking-tighter leading-none p-0.5">Prev Meter</div></>) : (<><Zap size={18} className="text-gray-500"/><span className="text-[7px] font-bold text-gray-500 text-center leading-tight">No Prev Photo</span></>)}</button>
                                    
                                    {/* UPDATED ROLLING LABELS: SLOT 2 (CURRENT/LATEST) */}
                                    <button onClick={() => { if(selectedUnit.tenant?.lastMeterImage) { setActiveDoc('lastMeter'); setRotation(0); } }} className={`aspect-square rounded-2xl border flex flex-col items-center justify-center gap-2 relative overflow-hidden group active:scale-95 transition ${isLight ? 'bg-white border-gray-200' : 'bg-black/20 border-gray-700'}`}>{selectedUnit.tenant.lastMeterImage ? (<><img src={selectedUnit.tenant.lastMeterImage} className="absolute inset-0 w-full h-full object-cover opacity-80" /><div className="absolute inset-0 flex items-center justify-center bg-black/30"><Zap className="text-white" size={16} /></div><div className="absolute bottom-0 left-0 right-0 bg-yellow-500 text-black text-[7px] font-black text-center py-0.5 uppercase tracking-tighter leading-none p-0.5">Latest Meter</div></>) : (<><Zap size={18} className="text-gray-500"/><span className="text-[7px] font-bold text-gray-500 text-center leading-tight">No Latest Photo</span></>)}</button>
                                </div>
                            </div>
                          </>
                      ) : (
                          <div className="flex flex-col items-center justify-center h-40 opacity-50"><Home size={40} className="text-gray-500 mb-2"/><p className="text-sm font-bold text-gray-500">Room is Vacant</p></div>
                      )}
                      {!selectedUnit.tenant && (
                          <div className="mt-6 pt-4 border-t border-dashed border-gray-700/50"><button onClick={() => handleDeleteUnit(selectedUnit.unit.id, selectedUnit.unit.name)} className="w-full py-3 rounded-xl border border-red-500/30 text-red-500 font-bold text-xs flex items-center justify-center gap-2 transition"><Trash2 size={16} /> Delete Room</button></div>
                      )}
                  </div>
              </div>
          </div>
      )}

      {activeDoc && selectedUnit?.tenant && (
          <div className="fixed inset-0 z-[6000] bg-black flex flex-col animate-fade-in" onClick={(e) => e.stopPropagation()}>
              <div className="flex justify-between items-center p-4 bg-black/50 backdrop-blur-md absolute top-0 left-0 right-0 z-10"><div className="text-white"><h3 className="font-bold text-sm">{activeDoc === 'profile' ? 'Profile Photo' : activeDoc === 'entryMeter' ? 'Previous Meter Reading' : activeDoc === 'lastMeter' ? 'Latest Meter Reading' : `National ID (${nidSide.toUpperCase()})`}</h3><p className="text-[10px] opacity-70">{selectedUnit.tenant.name}</p></div><div className="flex gap-4"><button onClick={() => setRotation(r => r + 90)} className="p-2 bg-white/10 rounded-full text-white"><RotateCw size={20} /></button>{activeDoc === 'nid' && selectedUnit.tenant.idBackImage && (<button onClick={toggleNidSide} className="p-2 bg-blue-500 rounded-full text-white shadow-lg"><RefreshCw size={20} /></button>)}<button onClick={() => { const src = activeDoc === 'profile' ? selectedUnit.tenant!.profileImage : activeDoc === 'entryMeter' ? selectedUnit.tenant!.entryMeterImage : activeDoc === 'lastMeter' ? selectedUnit.tenant!.lastMeterImage : (nidSide === 'front' ? selectedUnit.tenant!.idImage : selectedUnit.tenant!.idBackImage); if(src) shareDocument(src, `${selectedUnit.tenant!.name}_${activeDoc}`); }} className="p-2 bg-white/10 rounded-full text-white"><Share2 size={20} /></button><button onClick={() => setActiveDoc(null)} className="p-2 bg-red-500/80 rounded-full text-white"><X size={20} /></button></div></div>
              <div className="flex-1 flex items-center justify-center overflow-hidden p-4 relative">{(() => { let src = ""; if (activeDoc === 'profile') src = selectedUnit.tenant.profileImage || ""; else if (activeDoc === 'entryMeter') src = selectedUnit.tenant.entryMeterImage || ""; else if (activeDoc === 'lastMeter') src = selectedUnit.tenant.lastMeterImage || ""; else if (activeDoc === 'nid') src = nidSide === 'front' ? (selectedUnit.tenant.idImage || "") : (selectedUnit.tenant.idBackImage || ""); if (!src) return <p className="text-white font-bold">Image Unavailable</p>; return (<img src={src} className="max-w-full max-h-full object-contain transition-transform duration-300" style={{ transform: `rotate(${rotation}deg)` }} />); })()}</div>
          </div>
      )}
    </div>
  );
};

export default EstateControlRoom;