import { AppData, AppSettings } from "../../types";

const DB_NAME = 'NeonRentDB';
const DB_VERSION = 1;
const STORE_NAME = 'app_data';

const DEFAULT_SETTINGS: AppSettings = {
    unitPrice: 10,
    waterFixed: 500,
    gasFixed: 1000,
    serviceFixed: 200,
    energyLimit: 200, // Default limit
    rentPaymentDeadline: 8, // Default deadline day (8th of month)
    theme: 'neon',
    closingDate: 1,
    security: {
        pin: '',
        isEnabled: false,
        lockTimerMinutes: 5
    },
    owner: {
        name: 'Owner',
        email: 'owner@example.com',
        isLoggedIn: false,
        language: 'en'
    },
    developer: {
        name: 'MD Rasel',
        phone: '01834 985 982',
        email: 'hirasel007@gmail.com',
        // Updated to a Smart 3D Avatar
        photo: 'https://cdn-icons-png.flaticon.com/512/4140/4140048.png' 
    }
};

// Clean slate for Unlimited Entries
const DEFAULT_DATA: AppData = {
    tenants: [],
    units: [], 
    bills: [],
    todos: [],
    expenses: [], 
    serviceContacts: [], 
    medicines: [], 
    notepad: '', 
    settings: DEFAULT_SETTINGS
};

// --- INDEXED DB HELPER ---
const openDB = (): Promise<IDBDatabase> => {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        
        request.onupgradeneeded = (event) => {
            const db = (event.target as IDBOpenDBRequest).result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME);
            }
        };

        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
        
        // Add robustness for blocked event (e.g. open in another tab)
        request.onblocked = () => {
            console.warn("DB Open Blocked: Close other tabs with this app open.");
        };
    });
};

export const loadData = async (): Promise<AppData> => {
    try {
        const db = await openDB();
        return new Promise((resolve) => {
            try {
                const tx = db.transaction(STORE_NAME, 'readonly');
                const store = tx.objectStore(STORE_NAME);
                const request = store.get('root');

                request.onsuccess = () => {
                    const result = request.result;
                    if (result) {
                        // Merge defaults safely
                        resolve({ 
                            ...DEFAULT_DATA, 
                            ...result,
                            settings: { 
                                ...DEFAULT_DATA.settings, 
                                ...result.settings,
                                // FORCE UPDATE: Ensure developer info is always fresh from code, overriding old DB data
                                developer: DEFAULT_SETTINGS.developer 
                            } 
                        });
                    } else {
                        // MIGRATION: Check LocalStorage for old data
                        const local = localStorage.getItem('neonrent_data_v4');
                        if (local) {
                            try {
                                const parsed = JSON.parse(local);
                                // FIX: Ensure developer info is updated even when migrating from LocalStorage
                                const migratedSettings = {
                                    ...DEFAULT_DATA.settings,
                                    ...(parsed.settings || {}),
                                    developer: DEFAULT_SETTINGS.developer // FORCE OVERRIDE
                                };

                                resolve({ 
                                    ...DEFAULT_DATA, 
                                    ...parsed,
                                    settings: migratedSettings
                                });
                            } catch {
                                resolve(DEFAULT_DATA);
                            }
                        } else {
                            resolve(DEFAULT_DATA);
                        }
                    }
                };
                request.onerror = () => resolve(DEFAULT_DATA);
            } catch (err) {
                console.error("Transaction Creation Error", err);
                resolve(DEFAULT_DATA);
            }
        });
    } catch (e) {
        console.error("DB Load Error", e);
        return DEFAULT_DATA;
    }
};

export const saveData = async (data: AppData) => {
    try {
        const db = await openDB();
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        store.put(data, 'root');
    } catch (e) {
        console.error("DB Save Error", e);
    }
};