import React, { useState } from 'react';
import { AppData, WeatherData, Todo } from '../types';
import TopBar from '../components/TopBar';
import { Plus, Check, Trash2, CheckCircle, Circle } from 'lucide-react';

interface Props {
  data: AppData;
  setData: (data: AppData) => void;
  weather: WeatherData;
  onOpenSettings: () => void;
}

const Todos: React.FC<Props> = ({ data, setData, weather, onOpenSettings }) => {
  const [newTodo, setNewTodo] = useState('');
  const isLight = data.settings.theme === 'light';

  const addTodo = () => {
      if (!newTodo.trim()) return;
      const todo: Todo = {
          id: Date.now().toString(),
          text: newTodo,
          completed: false,
          color: 'bg-blue-500'
      };
      setData({ ...data, todos: [todo, ...data.todos] });
      setNewTodo('');
  };

  const toggleTodo = (id: string) => {
      const updated = data.todos.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
      setData({ ...data, todos: updated });
  };

  const deleteTodo = (id: string) => {
      const updated = data.todos.filter(t => t.id !== id);
      setData({ ...data, todos: updated });
  };

  return (
    <div className={`min-h-screen pb-32 animate-fade-in ${isLight ? 'bg-gray-50' : 'bg-[#0F1014]'}`}>
      <TopBar title="Tasks" data={data} weather={weather} onOpenSettings={onOpenSettings} />
      
      <div className="p-5">
          {/* Input */}
          <div className={`flex gap-2 mb-6 p-2 rounded-2xl border ${isLight ? 'bg-white border-gray-200' : 'bg-[#18191F] border-gray-800'}`}>
              <input 
                  value={newTodo}
                  onChange={e => setNewTodo(e.target.value)}
                  placeholder="Add a new task..."
                  className={`flex-1 bg-transparent px-3 outline-none font-medium ${isLight ? 'text-black' : 'text-white'}`}
                  onKeyDown={e => e.key === 'Enter' && addTodo()}
              />
              <button onClick={addTodo} className="p-3 bg-app-accent rounded-xl text-black active:scale-90 transition">
                  <Plus size={20} />
              </button>
          </div>

          {/* List */}
          <div className="space-y-3">
              {data.todos.length === 0 && (
                  <p className="text-center text-gray-500 text-sm mt-10">No tasks pending. Great job!</p>
              )}
              {data.todos.map(todo => (
                  <div key={todo.id} className={`group flex items-center justify-between p-4 rounded-2xl border transition-all ${
                      todo.completed 
                        ? (isLight ? 'bg-gray-100 border-gray-200 opacity-60' : 'bg-gray-900 border-gray-800 opacity-50') 
                        : (isLight ? 'bg-white border-gray-200 shadow-sm' : 'bg-[#18191F] border-gray-800')
                  }`}>
                      <div className="flex items-center gap-3 overflow-hidden">
                          <button onClick={() => toggleTodo(todo.id)} className={`shrink-0 transition-colors ${todo.completed ? 'text-green-500' : 'text-gray-400 hover:text-app-accent'}`}>
                              {todo.completed ? <CheckCircle size={22} className="fill-green-500/10"/> : <Circle size={22} />}
                          </button>
                          <span className={`font-medium truncate ${todo.completed ? 'line-through text-gray-500' : (isLight ? 'text-black' : 'text-white')}`}>
                              {todo.text}
                          </span>
                      </div>
                      <button onClick={() => deleteTodo(todo.id)} className="text-gray-500 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Trash2 size={18} />
                      </button>
                  </div>
              ))}
          </div>
      </div>
    </div>
  );
};

export default Todos;
