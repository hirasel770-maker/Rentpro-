import { db, storage } from './firebaseConfig';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { ref, uploadString, getDownloadURL } from 'firebase/storage';
import { AppData } from '../../types';

// Helper: Check if string is base64 image
const isBase64 = (str: string) => str && str.startsWith('data:image');

// Helper: Upload Image to Firebase Storage
const uploadImageToCloud = async (userId: string, imageBase64: string, path: string): Promise<string> => {
    if (!isBase64(imageBase64)) return imageBase64; // Already a URL
    
    try {
        const imageRef = ref(storage, `users/${userId}/${path}_${Date.now()}.jpg`);
        await uploadString(imageRef, imageBase64, 'data_url');
        return await getDownloadURL(imageRef);
    } catch (e) {
        console.warn("Image Cloud Upload Skipped (Offline/Permission)", e);
        // If upload fails (e.g. storage rules not set), fallback to keeping the base64 locally
        return imageBase64; 
    }
};

export const syncDataToCloud = async (userId: string, data: AppData): Promise<AppData> => {
    // Prevent sync for Demo User (Mock User)
    if (userId === 'mock-user-123') {
        console.log("Mock Cloud Sync: Skipped for Demo User (Success Simulation)");
        // Return data as-is to simulate a successful sync without errors
        return data;
    }

    const newData = { ...data };
    let hasChanges = false;

    try {
        // 1. Optimize Tenant Images (Profile & ID)
        const updatedTenants = await Promise.all(newData.tenants.map(async (t) => {
            let tUpdated = { ...t };
            
            if (t.profileImage && isBase64(t.profileImage)) {
                const url = await uploadImageToCloud(userId, t.profileImage, `tenants/${t.id}/profile`);
                if (url !== t.profileImage) {
                    tUpdated.profileImage = url;
                    hasChanges = true;
                }
            }
            
            if (t.idImage && isBase64(t.idImage)) {
                const url = await uploadImageToCloud(userId, t.idImage, `tenants/${t.id}/id`);
                if (url !== t.idImage) {
                    tUpdated.idImage = url;
                    hasChanges = true;
                }
            }

            return tUpdated;
        }));

        // 2. Optimize Bill Images (Meter Readings)
        const updatedBills = await Promise.all(newData.bills.map(async (b) => {
            let bUpdated = { ...b };
            if (b.meterImage && isBase64(b.meterImage)) {
                 const url = await uploadImageToCloud(userId, b.meterImage, `bills/${b.id}/meter`);
                 if (url !== b.meterImage) {
                     bUpdated.meterImage = url;
                     hasChanges = true;
                 }
            }
            return bUpdated;
        }));

        if (hasChanges) {
            newData.tenants = updatedTenants;
            newData.bills = updatedBills;
        }

        // SANITIZE: Remove undefined values which crash Firestore
        const cleanData = JSON.parse(JSON.stringify(newData));

        // 3. Save JSON to Firestore
        await setDoc(doc(db, 'users', userId), {
            appData: cleanData,
            lastUpdated: serverTimestamp(),
            device: navigator.userAgent
        }, { merge: true });
        
        console.log("✅ Cloud Sync Successful");
        
        // Return the optimized data (with URLs) to update local state
        return hasChanges ? newData : data;

    } catch (e) {
        console.error("Cloud Sync Failed:", e);
        // Return original data so app continues working offline
        return data;
    }
};

export const fetchDataFromCloud = async (userId: string): Promise<AppData | null> => {
    if (userId === 'mock-user-123') return null;

    try {
        const docSnap = await getDoc(doc(db, 'users', userId));
        if (docSnap.exists()) {
            console.log("✅ Cloud Data Fetched");
            const remoteData = docSnap.data().appData as AppData;
            return remoteData;
        }
        return null;
    } catch (e) {
        console.error("Cloud Fetch Failed:", e);
        return null;
    }
};