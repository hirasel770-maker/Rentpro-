
/**
 * Compresses and resizes an image file to a Base64 string.
 * Optimized for "Unlimited Entries": Ensures images don't bloat the IndexedDB storage.
 */
export const compressImage = (file: File, maxWidth: number = 500, quality: number = 0.6): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                // Smart Resize: Maintain aspect ratio but force reasonable limits
                if (width > maxWidth) {
                    height = (maxWidth / width) * height;
                    width = maxWidth;
                }
                
                // Extra check for very tall images (like long receipts)
                if (height > maxWidth * 1.5) {
                     width = (maxWidth * 1.5 / height) * width;
                     height = maxWidth * 1.5;
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (ctx) {
                    // White background for transparent PNGs converted to JPEG
                    ctx.fillStyle = '#FFFFFF';
                    ctx.fillRect(0, 0, width, height);
                    
                    ctx.drawImage(img, 0, 0, width, height);
                    
                    // Export as JPEG with optimized quality to save space
                    resolve(canvas.toDataURL('image/jpeg', quality));
                } else {
                    reject(new Error("Canvas context error"));
                }
            };
            img.onerror = (err) => reject(err);
        };
        reader.onerror = (err) => reject(err);
    });
};

/**
 * Smart Crop: Crops an image to a square focused on the bounding box
 */
export const cropImage = (base64: string, box: {ymin:number, xmin:number, ymax:number, xmax:number}): Promise<string> => {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.src = base64;
        img.onload = () => {
            const canvas = document.createElement('canvas');
            const w = img.width;
            const h = img.height;
            
            // Normalize 0-1000 to pixels
            let x = (box.xmin / 1000) * w;
            let y = (box.ymin / 1000) * h;
            let bw = ((box.xmax - box.xmin) / 1000) * w;
            let bh = ((box.ymax - box.ymin) / 1000) * h;

            // Safety check
            if (bw <= 0 || bh <= 0) { resolve(base64); return; }

            // Make crop square centered on the face
            const size = Math.max(bw, bh) * 1.5; // 1.5x Zoom Out from tight face box for context
            const cx = x + bw / 2;
            const cy = y + bh / 2;
            
            let cropX = Math.max(0, cx - size / 2);
            let cropY = Math.max(0, cy - size / 2);
            let cropW = size;
            let cropH = size;

            // Boundary checks (clamp to image)
            if (cropX + cropW > w) {
                // shift left if possible
                cropX = Math.max(0, w - cropW);
                // if still too big, shrink
                if (cropX + cropW > w) cropW = w - cropX;
            }
            if (cropY + cropH > h) {
                cropY = Math.max(0, h - cropH);
                if (cropY + cropH > h) cropH = h - cropY;
            }

            canvas.width = cropW;
            canvas.height = cropH;
            const ctx = canvas.getContext('2d');
            if(ctx) {
                ctx.drawImage(img, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);
                resolve(canvas.toDataURL('image/jpeg', 0.8));
            } else {
                resolve(base64);
            }
        };
        img.onerror = () => resolve(base64);
    });
};
