
import { Capacitor } from '@capacitor/core';

// AdMob Service Disabled as per user request
// Kept as dummy functions to prevent import errors during refactoring

const isWeb = Capacitor.getPlatform() === 'web';

export const initializeAdMob = async () => {
    console.log('AdMob Disabled');
};

export const showBannerAd = async () => {
    console.log('Banner Disabled');
};

export const hideBannerAd = async () => {
    // No-op
};

export const showInterstitialAd = async () => {
    console.log('Interstitial Disabled');
};

export const showRewardedAd = async (): Promise<boolean> => {
    console.log('Rewarded Disabled');
    return true; // Always return true to grant access immediately
};
