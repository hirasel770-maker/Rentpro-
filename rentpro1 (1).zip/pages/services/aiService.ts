
import { GoogleGenAI, Type } from "@google/genai";
import { Tenant, Bill } from "../../types";

const getClient = () => {
    // The API key must be obtained exclusively from the environment variable process.env.API_KEY
    if (!process.env.API_KEY) {
        console.warn("API Key not found or configured"); 
        return null;
    }
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
}

// --- UTILITY: ROBUST AI RESPONSE CLEANER ---
const cleanAIResponse = (text: string) => {
    if (!text) return "{}";
    
    // 1. Remove Markdown code blocks
    let cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
    
    // 2. Extract JSON object using bracket matching (Fix for "Here is the data: {...}")
    const firstOpen = cleaned.indexOf('{');
    const lastClose = cleaned.lastIndexOf('}');
    
    if (firstOpen !== -1 && lastClose !== -1 && lastClose > firstOpen) {
        cleaned = cleaned.substring(firstOpen, lastClose + 1);
    }
    
    return cleaned;
};

// Fixed: Switched to gemini-3-flash-preview and used systemInstruction for better clarity
export const generateMonthlySummary = async (bills: Bill[], tenants: Tenant[]) => {
  const ai = getClient();
  if (!ai) return "AI Summary requires API Key";

  const totalCollected = bills.reduce((acc, b) => acc + b.paidAmount, 0);
  const totalDue = bills.reduce((acc, b) => acc + (b.totalAmount - b.paidAmount), 0);
  
  const prompt = `Analyze this rent data:
    Total Collected: ${totalCollected}
    Total Pending: ${totalDue}
    Active Tenants: ${tenants.length}`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "You are a strategic rental property analyst. Provide a professional, concise 2-sentence summary for the landlord.",
      }
    });
    return response.text || "No summary generated.";
  } catch (error) {
    return "Summary temporarily unavailable.";
  }
};

// Fixed: Switched to gemini-3-flash-preview and optimized prompt
export const generateReminder = async (tenant: Tenant) => {
    const ai = getClient();
    if (!ai) return `Hello ${tenant.name}, rent of ${tenant.due} is due.`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Write a polite 1-sentence sms reminder for rent due: ${tenant.due} Tk.`,
            config: {
                systemInstruction: "You are a helpful landlord assistant writing a friendly SMS reminder."
            }
        });
        return response.text || `Hello ${tenant.name}, rent of ${tenant.due} is due.`;
    } catch (e) {
        return `Hello ${tenant.name}, rent of ${tenant.due} is due.`;
    }
};

// Fixed: Switched to gemini-3-flash-preview and added responseSchema for guaranteed JSON structure
export const extractTenantInfoFromID = async (imageBase64: string) => {
    const ai = getClient();
    if (!ai) return null;

    try {
        const base64Data = imageBase64.split(',')[1] || imageBase64;
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: {
                parts: [
                    { inlineData: { mimeType: 'image/jpeg', data: base64Data } },
                    { text: "Extract Name and NID Number from this ID." }
                ]
            },
            config: { 
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        name: { type: Type.STRING },
                        nidNumber: { type: Type.STRING }
                    },
                    required: ["name", "nidNumber"]
                }
            }
        });
        
        const text = cleanAIResponse(response.text || "{}");
        try {
            return JSON.parse(text);
        } catch (parseError) {
            console.warn("AI JSON Parse failed:", text);
            return null;
        }
    } catch (e) {
        console.error("ID Extraction Error", e);
        return null;
    }
};

// Fixed: Switched to gemini-3-flash-preview and used responseSchema for face coordinates
export const detectFaceCoordinates = async (imageBase64: string) => {
    const ai = getClient();
    if (!ai) return null;

    try {
        const base64Data = imageBase64.split(',')[1] || imageBase64;
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: {
                parts: [
                    { inlineData: { mimeType: 'image/jpeg', data: base64Data } },
                    { text: "Detect the main face in the image." }
                ]
            },
            config: { 
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        ymin: { type: Type.NUMBER },
                        xmin: { type: Type.NUMBER },
                        ymax: { type: Type.NUMBER },
                        xmax: { type: Type.NUMBER }
                    },
                    required: ["ymin", "xmin", "ymax", "xmax"]
                }
            }
        });
        
        const text = cleanAIResponse(response.text || "{}");
        return JSON.parse(text);
    } catch (e) {
        console.warn("Face Detection Error", e);
        return null;
    }
};

// Fixed: Switched to gemini-3-pro-preview for high-quality search grounding results
export const searchWebWithAI = async (query: string) => {
    const ai = getClient();
    if (!ai) return { text: "API Key Required", sources: [] };

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: query,
            config: {
                tools: [{ googleSearch: {} }]
            }
        });
        
        const text = response.text || "No results found.";
        const sources = (response.candidates?.[0]?.groundingMetadata?.groundingChunks as any[])?.map((c: any) => 
            c.web ? { title: c.web.title, uri: c.web.uri } : null
        ).filter(Boolean) || [];

        return { text, sources };
    } catch (e) {
        console.error("Search Error", e);
        return { text: "Search currently unavailable.", sources: [] };
    }
};

// Fixed: Switched to gemini-3-flash-preview and used responseSchema for meter reading extraction
export const analyzeMeterImage = async (imageBase64: string) => {
    const ai = getClient();
    if (!ai) return null;

    try {
        const base64Data = imageBase64.split(',')[1] || imageBase64;
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: {
                parts: [
                    { inlineData: { mimeType: 'image/jpeg', data: base64Data } },
                    { text: "Read the electricity meter reading (kWh)." }
                ]
            },
            config: { 
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        reading: { type: Type.NUMBER }
                    },
                    required: ["reading"]
                }
            }
        });
        
        const text = cleanAIResponse(response.text || "{}");
        try {
            const json = JSON.parse(text);
            return json.reading !== undefined ? parseFloat(json.reading) : null;
        } catch (parseError) {
            console.warn("Meter JSON Parse failed:", text);
            return null;
        }
    } catch (e) {
        console.error("Meter Reading Error", e);
        return null;
    }
};

// Fixed: Switched to gemini-3-pro-preview for complex behavioral analysis and added strict responseSchema
export const predictTenantBehavior = async (tenant: Tenant, bills: Bill[]) => {
    const ai = getClient();
    if (!ai) return null;

    const tenantBills = bills.filter(b => b.tenantId === tenant.id).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 6);

    const historySummary = tenantBills.map(b => ({
        month: b.month,
        total: b.totalAmount,
        paid: b.paidAmount,
        isPaid: b.isPaid,
        billDate: b.date
    }));

    const prompt = `Tenant Profile:
        - Name: ${tenant.name}
        - Current Due: ${tenant.due}
        - Rent Amount: ${tenant.rentAmount}
        - Unit: ${tenant.unitId}
        
        Recent Transaction History (Last 6 records): 
        ${JSON.stringify(historySummary)}`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: prompt,
            config: { 
                systemInstruction: `Role: Expert Psychological Behavioral Analyst & Risk Manager for Rental Property.
                    Analyze the tenant's financial behavior pattern to predict future actions.
                    1. Calculate "Risk Score" (0-100). 
                    2. Assign a "Psychological Persona".
                    3. Predict when/how they will pay next month.
                    4. Recommend a SPECIFIC tactical action.
                    IMPORTANT: TRANSLATE ALL OUTPUT STRING VALUES TO BENGALI (BANGLA). Keep keys in English.`,
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        riskScore: { type: Type.NUMBER },
                        persona: { type: Type.STRING },
                        prediction: { type: Type.STRING },
                        action: { type: Type.STRING },
                        color: { type: Type.STRING }
                    },
                    required: ["riskScore", "persona", "prediction", "action", "color"]
                }
            }
        });
        
        const text = cleanAIResponse(response.text || "{}");
        return JSON.parse(text);
    } catch (e) {
        console.error("Prediction Error", e);
        return null;
    }
};
