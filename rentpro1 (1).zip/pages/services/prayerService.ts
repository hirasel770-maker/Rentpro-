
export interface PrayerTimes {
    Tahajjud: string;
    Fajr: string;
    Dhuhr: string;
    Asr: string;
    Maghrib: string;
    Isha: string;
    Jumuah: string;
}

// 1. Fallback Static Data (Instant Load / No Internet)
const OFFLINE_TIMES: PrayerTimes = {
    Tahajjud: "03:45",
    Fajr: "05:15",
    Dhuhr: "12:10",
    Asr: "16:15",
    Maghrib: "18:00",
    Isha: "19:30",
    Jumuah: "13:30"
};

// Helper: Clean Time String
const formatTime = (time: string) => {
    if (!time) return "00:00";
    return time.split(' ')[0];
};

// Helper: Fast Timeout Wrapper
const timeoutPromise = (ms: number, promise: Promise<any>) => {
    return new Promise((resolve, reject) => {
        const timeoutId = setTimeout(() => {
            reject(new Error("Timeout"));
        }, ms);
        promise.then(
            (res) => {
                clearTimeout(timeoutId);
                resolve(res);
            },
            (err) => {
                clearTimeout(timeoutId);
                reject(err);
            }
        );
    });
};

// Helper: Promisified Geolocation
const getPosition = (): Promise<GeolocationPosition> => {
    return new Promise((resolve, reject) => {
        if (!navigator.geolocation) return reject(new Error("No GPS"));
        navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: false, // Low accuracy is faster and battery efficient
            timeout: 4000, // Strict 4s timeout
            maximumAge: 1000 * 60 * 60 // Reuse cache for 1 hour
        });
    });
};

// Helper: Get Local Date Key (Fixes Timezone Issues)
const getCacheKey = () => {
    const d = new Date();
    return `prayer_v3_${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
};

// Helper: Get API Date String (DD-MM-YYYY)
const getApiDateString = () => {
    const d = new Date();
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    return `${day}-${month}-${d.getFullYear()}`;
};

export const getPrayerTimes = async (lat?: number, lon?: number): Promise<PrayerTimes> => {
    // 2. Check Daily Cache First (Zero Network Call)
    const cacheKey = getCacheKey();
    
    try {
        const cached = localStorage.getItem(cacheKey);
        if (cached) return JSON.parse(cached);
    } catch(e) { localStorage.removeItem(cacheKey); }

    let data;

    try {
        // 3. Race Condition: GPS vs Timeout
        let finalLat = lat;
        let finalLon = lon;

        if (!finalLat || !finalLon) {
            try {
                // Try getting GPS in 4 seconds max
                const pos = await timeoutPromise(4000, getPosition()) as GeolocationPosition;
                finalLat = pos.coords.latitude;
                finalLon = pos.coords.longitude;
            } catch (e) {
                console.warn("GPS too slow or failed, switching to City Fallback");
            }
        }

        // Use Date String for API (More reliable than timestamp)
        const dateStr = getApiDateString();

        // 4. Fetch Data (GPS API)
        if (finalLat && finalLon) {
            try {
                const controller = new AbortController();
                const id = setTimeout(() => controller.abort(), 5000); // 5s API Timeout
                
                const res = await fetch(
                    `https://api.aladhan.com/v1/timings/${dateStr}?latitude=${finalLat}&longitude=${finalLon}&method=2`, 
                    { signal: controller.signal }
                );
                clearTimeout(id);
                
                if (res.ok) data = await res.json();
            } catch (e) {
                console.warn("GPS API Fetch failed, trying fallback");
            }
        }

        // 5. Fallback API (Dhaka)
        if (!data || !data.data) {
            try {
                const controller = new AbortController();
                const id = setTimeout(() => controller.abort(), 5000); // 5s API Timeout

                const res = await fetch(
                    `https://api.aladhan.com/v1/timingsByCity/${dateStr}?city=Dhaka&country=Bangladesh&method=2`,
                    { signal: controller.signal }
                );
                clearTimeout(id);

                if (res.ok) data = await res.json();
            } catch (e) {
                console.warn("City API Fetch failed");
            }
        }

        // 6. Process & Cache
        if(data && data.data && data.data.timings) {
            const t = data.data.timings;
            const times = {
                Tahajjud: t.Lastthird || "03:45",
                Fajr: formatTime(t.Fajr),
                Dhuhr: formatTime(t.Dhuhr),
                Asr: formatTime(t.Asr),
                Maghrib: formatTime(t.Maghrib),
                Isha: formatTime(t.Isha),
                Jumuah: formatTime(t.Dhuhr), // Fallback if not Friday
            };
            localStorage.setItem(cacheKey, JSON.stringify(times));
            return times;
        }
        
        // Handle invalid API response gracefully
        console.warn("API returned invalid data, using offline fallback");
        return OFFLINE_TIMES;

    } catch (error) {
        console.warn("Prayer API Error (Using Offline Data):", error);
        return OFFLINE_TIMES; // 7. Fail-safe: Always return valid data
    }
};
