
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAuth } from "firebase/auth";
import { getAnalytics, isSupported } from "firebase/analytics"; 

// Firebase configuration updated from new google-services.json
const firebaseConfig = {
  apiKey: "AIzaSyA3NY-hlr2HEyxuEDwOi1gAVZVDO7SvzPo",
  authDomain: "neonrent-ai-manager-pro1.firebaseapp.com",
  projectId: "neonrent-ai-manager-pro1",
  storageBucket: "neonrent-ai-manager-pro1.firebasestorage.app",
  messagingSenderId: "15878833660",
  appId: "1:15878833660:android:247567ecb8cdaa5a909e79" // Updated App ID
};

// Initialize Firebase safely
const app = initializeApp(firebaseConfig);

// Initialize Services
export const db = getFirestore(app);
export const storage = getStorage(app);
export const auth = getAuth(app);

// Analytics: Safe initialization (Fixes "missing exports" warning)
export const initAnalytics = async () => {
  // Prevent "Failed to fetch" error when measurementId is missing (common in Android-only configs used on Web)
  if (!(firebaseConfig as any).measurementId) {
      return null;
  }

  try {
    // Check if the environment (browser/mobile) supports analytics using named export
    const supported = await isSupported();
    if (supported) {
      return getAnalytics(app);
    }
    return null;
  } catch (e) {
    // Fail silently without cluttering the console
    return null;
  }
};

export default app;
