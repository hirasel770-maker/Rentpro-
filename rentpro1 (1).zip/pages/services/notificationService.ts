
import { LocalNotifications } from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';
import { AppData } from '../../types';

// Global variables
let alarmLoopInterval: any = null;
let audioCtx: AudioContext | null = null;

// --- EMOTION ENGINE TRIGGER ---
export const triggerNavEmotion = (type: string) => {
    const event = new CustomEvent('neon-emotion', { detail: { type } });
    window.dispatchEvent(event);
};

// --- 1. INITIALIZE AUDIO ---
export const initAudio = () => {
    try {
        const CtxClass = window.AudioContext || (window as any).webkitAudioContext;
        if (!audioCtx && CtxClass) {
            audioCtx = new CtxClass();
            const buffer = audioCtx.createBuffer(1, 1, 22050);
            const source = audioCtx.createBufferSource();
            source.buffer = buffer;
            source.connect(audioCtx.destination);
            source.start(0);
            if (audioCtx.state === 'suspended') {
                audioCtx.resume();
            }
        } else if (audioCtx && audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
    } catch (e) {}
};

// --- 2. FOREGROUND SIREN ---
const playTone = () => {
    try {
        if (!audioCtx) initAudio();
        if (!audioCtx) return; 

        if (audioCtx.state === 'suspended') {
            audioCtx.resume().catch(() => {});
        }
        
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();

        osc.connect(gain);
        gain.connect(audioCtx.destination);

        const now = audioCtx.currentTime;
        osc.type = 'sawtooth'; 
        osc.frequency.setValueAtTime(800, now); 
        osc.frequency.linearRampToValueAtTime(1500, now + 0.25); 
        osc.frequency.linearRampToValueAtTime(800, now + 0.5);  

        gain.gain.setValueAtTime(1.0, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.5);

        osc.start(now);
        osc.stop(now + 0.5);
    } catch (e) {}
};

// --- 3. START CONTINUOUS ALARM (Foreground Only) ---
export const startContinuousAlarm = () => {
    if (alarmLoopInterval) return; 
    playTone();
    if (navigator.vibrate) navigator.vibrate([1000, 500, 1000, 500, 2000]); 
    alarmLoopInterval = setInterval(() => {
        playTone();
        if (navigator.vibrate) navigator.vibrate([1000, 500]);
    }, 1000); 
};

export const stopContinuousAlarm = () => {
    if (alarmLoopInterval) {
        clearInterval(alarmLoopInterval);
        alarmLoopInterval = null;
    }
    if (navigator.vibrate) navigator.vibrate(0);
};

// --- PERMISSIONS & CHANNELS ---
export const requestNotificationPermission = async () => {
    try {
        if (Capacitor.isNativePlatform()) {
            const result = await LocalNotifications.requestPermissions();
            await LocalNotifications.createChannel({
                id: 'neon_ultra_alarm_v1', 
                name: 'NeonRent Power Alarms',
                importance: 5, // MAX Importance: Banner + Sound
                visibility: 1, 
                vibration: true,
                lights: true,
                lightColor: '#FF0000',
                sound: undefined 
            });
            if (result.display === 'granted') return true;
        }
    } catch (e) {}
    return false;
};

// --- 4. BACKGROUND SCHEDULES (WORKS WHEN APP KILLED) ---

export const scheduleMonthEndNotification = async () => {
    if (!Capacitor.isNativePlatform()) return; 

    try {
        const cancelIds = [];
        for(let j=0; j<65; j++) cancelIds.push({ id: 90000 + j });
        await LocalNotifications.cancel({ notifications: cancelIds });

        const notifications = [];
        const now = new Date();
        
        for (let i = 0; i < 60; i++) {
            // মাসের শেষ দিন নির্ধারণ
            const targetDate = new Date(now.getFullYear(), now.getMonth() + 1 + i, 0); 
            targetDate.setHours(9, 0, 0, 0); // সকাল ৯ টায় বাজবে

            if (targetDate.getTime() <= now.getTime()) continue;

            notifications.push({
                title: "📅 মিটার দেখে বিল তৈরি করুন!",
                body: `আজ মাসের শেষ দিন (${targetDate.toLocaleDateString()})। দয়া করে সকল মিটারের রিডিং নিন এবং বিল তৈরি করুন।`,
                id: 90000 + i,
                channelId: 'neon_ultra_alarm_v1',
                schedule: { 
                    at: targetDate, 
                    allowWhileIdle: true // স্ক্রিন অফ থাকলেও কাজ করবে
                },
                ongoing: true, // নোটিফিকেশন ট্রে-তে আটকে থাকবে যতক্ষণ না দেখবেন
                autoCancel: false
            });
        }

        if (notifications.length > 0) {
            await LocalNotifications.schedule({ notifications });
            console.log(`✅ Scheduled ${notifications.length} Month-End alarms`);
        }
    } catch (e) {}
};

export const scheduleMonthlyDefaulterNotification = async (dayOfMonth: number = 8) => {
    if (!Capacitor.isNativePlatform()) return;
    try {
        await LocalNotifications.cancel({ notifications: [{ id: 88888 }] });
        await LocalNotifications.schedule({
            notifications: [{
                title: "🚨 ভাড়া আদায়ের সময় শেষ!",
                body: `আজ ${dayOfMonth} তারিখ। যাদের ভাড়া এখনো বাকি আছে তাদের কাছ থেকে দ্রুত ভাড়া সংগ্রহ করুন।`,
                id: 88888,
                channelId: 'neon_ultra_alarm_v1',
                schedule: { 
                    on: { day: dayOfMonth, hour: 10, minute: 0 },
                    allowWhileIdle: true 
                },
                ongoing: true,
                autoCancel: false
            }]
        });
    } catch (e) {}
};

export const syncAlarmsWithSystem = async (medicines: any[], rentDeadline: number = 8) => {
    if (!Capacitor.isNativePlatform()) return;
    await requestNotificationPermission();
    
    // সিডিউলগুলো মেমোরিতে লক করা
    await scheduleMonthlyDefaulterNotification(rentDeadline);
    await scheduleMonthEndNotification();

    if (medicines && medicines.length > 0) {
        for (const med of medicines) {
            if (med.time) {
                const [hours, minutes] = med.time.split(':').map(Number);
                const notifId = parseInt(med.id.slice(-8)) || Math.floor(Math.random() * 100000);
                await scheduleRepeatingNotification(notifId, med.name, `ওষুধ খাওয়ার সময় হয়েছে: ${med.name}`, hours, minutes);
            }
        }
    }
};

export const scheduleRepeatingNotification = async (id: number, title: string, body: string, hour: number, minute: number) => {
    if (!Capacitor.isNativePlatform()) return false;
    try {
        await LocalNotifications.schedule({
            notifications: [{
                title: "💊 " + title,
                body: body,
                id: id,
                channelId: 'neon_ultra_alarm_v1',
                schedule: { on: { hour, minute }, allowWhileIdle: true },
                ongoing: true,
                autoCancel: false
            }]
        });
        return true;
    } catch (e) { return false; }
};

export const refreshAllSchedules = async (data: AppData) => {
    if (!Capacitor.isNativePlatform()) return;
    const deadline = data.settings.rentPaymentDeadline || 8;
    await syncAlarmsWithSystem(data.medicines || [], deadline);
};

export const cancelNotification = async (id: number) => {
   try { await LocalNotifications.cancel({ notifications: [{ id }] }); } catch(e) {}
};
