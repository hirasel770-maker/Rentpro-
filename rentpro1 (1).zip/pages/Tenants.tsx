import React, { useState, useRef, useEffect } from 'react';
import {
  User, Home, Phone, Search,
  Archive, RotateCcw, Bell, Share2,
  Camera, X, FileText,
  History, Calendar, Clock, CheckCircle, AlertTriangle, ChevronLeft, ChevronRight, Trash2, DollarSign, Sparkles, Loader2, ScanLine, Wallet, ListFilter, Power, ArrowDownLeft, ArrowUpRight, Zap
} from 'lucide-react';
import TopBar from '../components/TopBar';
import { compressImage } from './services/imageService';
import { analyzeMeterImage } from './services/aiService';
import { triggerNavEmotion } from './services/notificationService'; 
import { AppData, Tenant, Bill, WeatherData, Unit } from '../types';

interface Props {
  data: AppData;
  setData: (data: AppData) => void;
  weather: WeatherData;
  onOpenSettings: () => void;
  onEditTenant: (id: string) => void;
}

// --- DYNAMIC CARD THEMES ---
const CARD_THEMES = [
    { light: 'bg-red-50 border-red-200', dark: 'bg-[#200A0A] border-red-500/30 shadow-[0_0_15px_-5px_rgba(239,68,68,0.3)]' },
    { light: 'bg-orange-50 border-orange-200', dark: 'bg-[#20100A] border-orange-500/30 shadow-[0_0_15px_-5px_rgba(249,115,22,0.3)]' },
    { light: 'bg-amber-50 border-amber-200', dark: 'bg-[#20180A] border-orange-500/30 shadow-[0_0_15px_-5px_rgba(245,158,11,0.3)]' },
    { light: 'bg-lime-50 border-lime-200', dark: 'bg-[#15200A] border-lime-500/30 shadow-[0_0_15px_-5px_rgba(132,204,22,0.3)]' },
    { light: 'bg-emerald-50 border-emerald-200', dark: 'bg-[#0A2015] border-emerald-500/30 shadow-[0_0_15px_-5px_rgba(16,185,129,0.3)]' },
    { light: 'bg-teal-50 border-teal-200', dark: 'bg-[#0A2020] border-teal-500/30 shadow-[0_0_15px_-5px_rgba(20,184,166,0.3)]' },
    { light: 'bg-cyan-50 border-cyan-200', dark: 'bg-[#0A1A20] border-cyan-500/30 shadow-[0_0_15px_-5px_rgba(6,182,212,0.3)]' },
    { light: 'bg-sky-50 border-sky-200', dark: 'bg-[#0A1520] border-sky-500/30 shadow-[0_0_15px_-5px_rgba(14,165,233,0.3)]' },
    { light: 'bg-blue-50 border-blue-200', dark: 'bg-[#0A1020] border-blue-500/30 shadow-[0_0_15px_-5px_rgba(59,130,246,0.3)]' },
    { light: 'bg-indigo-50 border-indigo-200', dark: 'bg-[#100A20] border-indigo-500/30 shadow-[0_0_15px_-5px_rgba(99,102,241,0.3)]' },
    { light: 'bg-violet-50 border-violet-200', dark: 'bg-[#180A20] border-violet-500/30 shadow-[0_0_15px_-5px_rgba(139,92,246,0.3)]' },
    { light: 'bg-purple-50 border-purple-200', dark: 'bg-[#200A20] border-purple-500/30 shadow-[0_0_15px_-5px_rgba(168,85,247,0.3)]' },
    { light: 'bg-fuchsia-50 border-fuchsia-200', dark: 'bg-[#200A18] border-fuchsia-500/30 shadow-[0_0_15px_-5px_rgba(217,70,239,0.3)]' },
    { light: 'bg-pink-50 border-pink-200', dark: 'bg-[#200A10] border-pink-500/30 shadow-[0_0_15px_-5px_rgba(236,72,153,0.3)]' },
    { light: 'bg-rose-50 border-rose-200', dark: 'bg-[#200A0D] border-rose-500/30 shadow-[0_0_15px_-5px_rgba(244,63,94,0.3)]' },
];

const getTenantTheme = (id: string) => {
    let hash = 0;
    for (let i = 0; i < id.length; i++) {
        hash = id.charCodeAt(i) + ((hash << 5) - hash);
    }
    return CARD_THEMES[Math.abs(hash) % CARD_THEMES.length];
};

const getLocalDateString = () => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const time = d.toTimeString().split(' ')[0];
    return `${year}-${month}-${day}T${time}`;
};

const norm = (str: string) => str ? str.trim().toLowerCase() : '';

const CustomCalendarModal = ({ isOpen, onClose, onSelect }: { isOpen: boolean; onClose: () => void; onSelect: (date: string) => void }) => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [selectedDay, setSelectedDay] = useState<number | null>(null);
    if (!isOpen) return null;
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDay = new Date(year, month, 1).getDay(); 
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const handlePrev = () => setCurrentDate(new Date(year, month - 1, 1));
    const handleNext = () => setCurrentDate(new Date(year, month + 1, 1));
    const handleDayClick = (day: number) => {
        setSelectedDay(day);
        const mStr = (month + 1).toString().padStart(2, '0');
        const dStr = day.toString().padStart(2, '0');
        onSelect(`${year}-${mStr}-${dStr}`);
        onClose();
    };
    const days = [];
    for (let i = 0; i < firstDay; i++) days.push(<div key={`empty-${i}`} className="w-8 h-8"></div>);
    for (let d = 1; d <= daysInMonth; d++) {
        const isSelected = selectedDay === d;
        const isToday = new Date().getDate() === d && new Date().getMonth() === month && new Date().getFullYear() === year;
        days.push(
            <button key={d} onClick={() => handleDayClick(d)} className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold transition-all active:scale-90 ${isSelected ? 'bg-[#FF5722] text-white shadow-lg shadow-orange-500/40' : (isToday ? 'bg-white/10 text-white border border-white/20' : 'text-gray-300 hover:bg-white/5')}`}>
                {d}
            </button>
        );
    }
    return (
        <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in pb-safe" onClick={onClose}>
            <div className="w-[320px] bg-[#1E1E24] rounded-[32px] overflow-hidden shadow-2xl border border-gray-700 p-5 relative mb-safe" onClick={e => e.stopPropagation()}>
                <div className="bg-gradient-to-r from-violet-600 to-indigo-600 rounded-2xl p-4 mb-4 flex justify-between items-center shadow-lg shadow-indigo-500/20"><button onClick={handlePrev} className="p-1 rounded-full hover:bg-white/20 text-white"><ChevronLeft size={20}/></button><span className="text-white font-bold text-lg drop-shadow-md">{monthNames[month]} {year}</span><button onClick={handleNext} className="p-1 rounded-full hover:bg-white/20 text-white"><ChevronRight size={20}/></button></div>
                <div className="grid grid-cols-7 gap-1 mb-2 text-center">{['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (<div key={day} className="text-[10px] font-bold text-gray-500 uppercase tracking-wide">{day}</div>))}</div>
                <div className="grid grid-cols-7 gap-1 place-items-center">{days}</div>
                <button onClick={onClose} className="mt-4 w-full py-3 bg-gray-800 rounded-xl text-gray-400 text-xs font-bold hover:bg-gray-700">Cancel</button>
            </div>
        </div>
    );
};

// --- VERTICAL POWER SWITCH ---
const VerticalPowerSwitch = ({ type, onClick, disabled, isUrgent }: { type: 'due' | 'paid' | 'generate', onClick: (e: any) => void, disabled: boolean, isUrgent?: boolean }) => {
    let containerClass = "";
    let knobClass = "";
    let icon = null;
    if (type === 'due') {
        containerClass = "bg-[#1a0505] border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.3)] animate-pulse";
        knobClass = "top-[6px] bg-gradient-to-b from-red-500 to-red-700 shadow-[0_0_10px_#ef4444]";
        icon = <Power size={18} className="text-white" />;
    } else if (type === 'paid') {
        containerClass = "bg-[#051a05] border-green-500 shadow-[0_0_15px_rgba(34,197,94,0.3)] opacity-90";
        knobClass = "top-[calc(100%-46px)] bg-gradient-to-b from-green-400 to-green-600 shadow-[0_0_10px_#22c55e]";
        icon = <CheckCircle size={18} className="text-white" />;
    } else if (type === 'generate') {
        containerClass = `bg-[#1a1505] border-yellow-400 shadow-[0_0_15px_rgba(250,204,21,0.3)] ${isUrgent ? 'animate-[pulse_1.5s_infinite] border-yellow-300' : 'animate-pulse'}`;
        knobClass = "top-[6px] bg-gradient-to-b from-yellow-300 to-yellow-500 shadow-[0_0_10px_#facc15]";
        icon = <Sparkles size={18} className={`${isUrgent ? 'animate-spin-slow' : ''} text-black`} />;
    }
    return (
        <button onClick={(e) => { e.stopPropagation(); if (!disabled) onClick(e); }} disabled={disabled} className={`relative w-[50px] h-[90px] rounded-[30px] border-2 transition-all duration-500 flex flex-col items-center justify-between py-2 ${containerClass} ${disabled ? 'cursor-default opacity-80' : 'cursor-pointer active:scale-95'}`}>
            <div className={`absolute left-[3px] w-[40px] h-[40px] rounded-full flex items-center justify-center border border-white/20 transition-all duration-500 z-10 ${knobClass}`}>{icon}</div>
            <div className="flex-1 w-full flex flex-col items-center justify-between text-[8px] font-black tracking-widest text-white/30 pt-1 pb-1">
                <span className={type === 'paid' ? 'opacity-20' : 'opacity-100'}>ON</span>
                <span className={type === 'paid' ? 'opacity-100' : 'opacity-20'}>OFF</span>
            </div>
        </button>
    );
};

const Tenants: React.FC<Props> = ({ data, setData, weather, onOpenSettings, onEditTenant }) => {
  const [viewMode, setViewMode] = useState<'active' | 'archived'>('active');
  const [searchTerm, setSearchTerm] = useState('');
  const [billTenant, setBillTenant] = useState<Tenant | null>(null);
  const [payTenant, setPayTenant] = useState<Tenant | null>(null);
  const [showCalendar, setShowCalendar] = useState(false);
  const [showReadingConfirm, setShowReadingConfirm] = useState(false);
  const [restoreConflict, setRestoreConflict] = useState<Tenant | null>(null);
  const [restoreRoom, setRestoreRoom] = useState('');
  const [restoreMeter, setRestoreMeter] = useState('');
  const [restoreMeterImg, setRestoreMeterImg] = useState<string | null>(null); 
  const [showRestoreReadingConfirm, setShowRestoreReadingConfirm] = useState(false); 
  const [shakeInput, setShakeInput] = useState(false); 
  const [currReading, setCurrReading] = useState<string>('');
  const [meterImg, setMeterImg] = useState<string | null>(null);
  const [isAiReading, setIsAiReading] = useState(false);
  const [aiSuccess, setAiSuccess] = useState(false);
  const [payAmount, setPayAmount] = useState<string>('');
  const [nextDate, setNextDate] = useState<string>('');
  const [useAdvance, setUseAdvance] = useState(false); 
  
  // New State for Custom Delete Modal
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const isLight = data.settings.theme === 'light';
  
  // CHECK FOR ARCHIVED TENANTS
  const hasArchived = (data.tenants || []).some(t => t.status === 'Archived');

  // --- SMART DATE LOGIC ---
  const now = new Date();
  const currentMonth = now.toLocaleString('default', { month: 'long', year: 'numeric' });
  const currentDay = now.getDate();
  const lastDayOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const deadlineDay = data.settings.rentPaymentDeadline || 8;
  
  // LOGIC: Reset happens on the LAST day of the month OR if new month started
  const isLastDay = currentDay === lastDayOfMonth;
  const isBillingSeason = currentDay >= lastDayOfMonth - 1 || currentDay <= 5 || currentDay === deadlineDay;

  const handleMeterUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          try {
              setIsAiReading(true); setAiSuccess(false);
              const compressed = await compressImage(file, 800, 0.7);
              setMeterImg(compressed); setAiSuccess(true); 
          } catch (err) { console.error("Meter upload error:", err); } finally { setIsAiReading(false); }
      }
  };

  const handleRestoreMeterUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          try {
              const compressed = await compressImage(file, 800, 0.7);
              setRestoreMeterImg(compressed); 
          } catch (err) { console.error("Restore meter upload error:", err); }
      }
  };

  const cycleDate = new Date();
  cycleDate.setMonth(cycleDate.getMonth() + 1);
  cycleDate.setDate(deadlineDay);
  const nextPayDateStr = cycleDate.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

  const billsThisMonth = new Set((data.bills || [])
      .filter(b => b.month === currentMonth)
      .map(b => b.tenantId));

  const filtered = (data.tenants || []).filter(t => {
      const statusMatch = viewMode === 'active' ? t.status !== 'Archived' : t.status === 'Archived';
      const searchMatch = t.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          t.unitId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          t.phone.includes(searchTerm);
      return statusMatch && searchMatch;
  }).sort((a, b) => {
      const hasBillA = billsThisMonth.has(a.id);
      const hasBillB = billsThisMonth.has(b.id);
      const groupA = !hasBillA ? 0 : (a.due > 0 ? 1 : 2);
      const groupB = !hasBillB ? 0 : (b.due > 0 ? 1 : 2);
      if (groupA !== groupB) return groupA - groupB;
      return b.due - a.due; 
  });

  const shareTenantDetails = (t: Tenant) => {
      let phone = t.phone.replace(/\D/g, ""); if (phone.length === 11 && phone.startsWith("01")) phone = "88" + phone; 
      const curBill = (data.bills || []).find(b => b.tenantId === t.id && b.month === currentMonth);
      let currentRent = t.rentAmount;
      let garbage = t.garbageBill || 0;
      let otherCharges = (t.customFields || []).reduce((sum, f) => sum + f.amount, 0);
      let electricityCost = 0, unitsUsed = 0, prevReading = 0, currReading = 0, calculatedPreviousDue = 0, totalPayable = 0;
      if (curBill) {
          electricityCost = curBill.electricityBill; unitsUsed = curBill.currMeter - curBill.prevMeter;
          prevReading = curBill.prevMeter; currReading = curBill.currMeter;
          const currentMonthTotal = currentRent + garbage + electricityCost + otherCharges;
          calculatedPreviousDue = t.due > currentMonthTotal ? t.due - currentMonthTotal : 0;
          totalPayable = t.due;
      } else {
          calculatedPreviousDue = t.due; totalPayable = calculatedPreviousDue + currentRent + garbage + otherCharges;
      }
      let msg = `*ভাড়ার বিস্তারিত হিসাব (Rent Bill)*\n----------------------------\n📅 মাস: ${currentMonth}\n👤 নাম: ${t.name}\n🏠 রুম নং: ${t.unitId}\n\n*খরচের বিবরণ:*\n🔹 বাসা ভাড়া: ${currentRent} টাকা\n`;
      if (garbage > 0) msg += `🔹 ময়লা বিল: ${garbage} টাকা\n`;
      if (electricityCost > 0) msg += `🔹 বিদ্যুৎ বিল: ${electricityCost} টাকা\n   (রিডিং: ${currReading} - ${prevReading} = ${unitsUsed} ইউনিট)\n`;
      else if (!curBill) msg += `🔹 বিদ্যুৎ বিল: (যোগ করা হয়নি)\n`;
      if (otherCharges > 0) (t.customFields || []).forEach(f => { msg += `🔹 ${f.label}: ${f.amount} টাকা\n`; });
      if (calculatedPreviousDue > 0) msg += `🔹 পূর্বের বকেয়া: ${calculatedPreviousDue} টাকা\n`;
      msg += `----------------------------\n*💰 সর্বমোট বকেয়া: ${Math.round(totalPayable)} টাকা*\n----------------------------\n\nঅনুগ্রহ করে দ্রুত পরিশোধ করুন। ধন্যবাদ!`;
      if (navigator.share) navigator.share({ title: `Rent Bill for ${t.name}`, text: msg }).catch((e) => { if (e.name !== 'AbortError') console.error(e); });
      else window.open(`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const getDueBreakdown = (t: Tenant) => {
      if (t.due <= 0) return [];
      const relevantBills = (data.bills || []).filter(b => b.tenantId === t.id && b.month !== 'Payment').sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      let remainingDue = t.due; const breakdown = [];
      for (let i = 0; i < relevantBills.length; i++) {
          if (remainingDue <= 0) break;
          const bill = relevantBills[i]; const amount = Math.min(bill.totalAmount, remainingDue);
          const label = bill.month.includes(new Date(bill.date).getFullYear().toString()) ? bill.month : `${bill.month} ${new Date(bill.date).getFullYear()}`;
          breakdown.push({ id: bill.id, label, amount, isRunning: i === 0 });
          remainingDue -= amount;
      }
      if (remainingDue > 0) breakdown.push({ id: 'prev-balance', label: 'Previous Balance', amount: remainingDue, isRunning: false });
      return breakdown.reverse();
  };

  const moveToRecycleBin = (id: string) => {
      const t = data.tenants.find(x => x.id === id); if (!t) return;
      
      // NEW: Enforce bill creation for current month before archiving
      const isBillCreated = data.bills.some(b => b.tenantId === id && b.month === currentMonth);
      if (!isBillCreated) {
          alert("⚠️ বিল তৈরি করা হয়নি! আর্কাইভ করার আগে 'Make Bill' সম্পূর্ণ করুন।");
          return;
      }

      triggerNavEmotion('angry');
      const updatedTenants = data.tenants.map(tenant => tenant.id === id ? { ...tenant, status: 'Archived' as const } : tenant);
      const updatedUnits = data.units.filter(u => norm(u.name) !== norm(t.unitId));
      setData({ ...data, tenants: updatedTenants, units: updatedUnits });
  };

  const restoreTenant = (id: string) => {
      const t = data.tenants.find(x => x.id === id); if (!t) return;
      if (data.tenants.some(active => active.status === 'Active' && norm(active.unitId) === norm(t.unitId))) {
          setRestoreConflict(t); setRestoreRoom(''); setRestoreMeter(''); setRestoreMeterImg(null); return;
      }
      triggerNavEmotion('success');
      const updatedTenants = data.tenants.map(tenant => tenant.id === id ? { ...tenant, status: 'Active' as const } : tenant);
      let updatedUnits = [...data.units];
      if (!updatedUnits.some(u => norm(u.name) === norm(t.unitId))) updatedUnits.push({ id: 'auto_' + Date.now(), name: t.unitId, meterNumber: t.meterNumber || 'N/A', currentMeterReading: t.currentMeterReading || 0, status: 'occupied' });
      setData({ ...data, tenants: updatedTenants, units: updatedUnits });
  };

  const confirmRestoreWithNewRoom = () => {
      if(!restoreConflict || !restoreRoom || !restoreMeter) return;
      
      const targetOccupied = data.tenants.find(t => 
          norm(t.unitId) === norm(restoreRoom) && 
          t.status === 'Active' && 
          t.id !== restoreConflict.id
      );

      if (targetOccupied) {
          alert(`Room ${restoreRoom} is occupied by ${targetOccupied.name}!`);
          setShowRestoreReadingConfirm(false);
          setShakeInput(true);
          return;
      }

      const updatedTenants = data.tenants.map(t => {
          if (t.id === restoreConflict.id) {
              return { 
                  ...t, 
                  status: 'Active' as const,
                  unitId: restoreRoom,
                  currentMeterReading: Number(restoreMeter),
                  startMeterReading: Number(restoreMeter),
                  entryMeterImage: restoreMeterImg || t.entryMeterImage
              };
          }
          return t;
      });

      let updatedUnits = [...data.units];
      const unitIndex = updatedUnits.findIndex(u => norm(u.name) === norm(restoreRoom));
      
      if (unitIndex >= 0) {
          updatedUnits[unitIndex] = {
              ...updatedUnits[unitIndex],
              status: 'occupied',
              currentMeterReading: Number(restoreMeter)
          };
      } else {
          updatedUnits.push({
              id: 'auto_' + Date.now(),
              name: restoreRoom,
              meterNumber: restoreConflict.meterNumber || 'N/A',
              currentMeterReading: Number(restoreMeter),
              status: 'occupied'
          });
      }

      setData({ ...data, tenants: updatedTenants, units: updatedUnits });
      
      setRestoreConflict(null);
      setRestoreRoom('');
      setRestoreMeter('');
      setRestoreMeterImg(null);
      setShowRestoreReadingConfirm(false);
      triggerNavEmotion('success');
  };

  const confirmDeleteAction = () => {
      if(deleteConfirmId) {
          const updatedTenants = data.tenants.filter(t => t.id !== deleteConfirmId);
          const updatedBills = data.bills.filter(b => b.tenantId !== deleteConfirmId);
          setData({ ...data, tenants: updatedTenants, bills: updatedBills });
          triggerNavEmotion('delete');
          setDeleteConfirmId(null);
      }
  };

  const generateBill = () => {
      if(!billTenant) return;
      if (data.bills.find(b => b.tenantId === billTenant.id && b.month === currentMonth)) { alert(`⚠️ Bill for ${currentMonth} already exists!`); setShowReadingConfirm(false); return; }
      const current = Number(currReading), previous = billTenant.currentMeterReading || billTenant.startMeterReading || 0;
      if(current < previous) { alert("Current reading cannot be less than previous"); setShowReadingConfirm(false); return; }
      const unitsUsed = current - previous, rate = billTenant.unitPrice !== undefined ? billTenant.unitPrice : data.settings.unitPrice;
      const elecBill = Math.round(unitsUsed * rate), customTotal = (billTenant.customFields || []).reduce((acc, i) => acc + i.amount, 0);
      const total = Math.round(billTenant.rentAmount + elecBill + (billTenant.garbageBill || 0) + customTotal);
      const newBill: Bill = { id: Date.now().toString(), tenantId: billTenant.id, date: getLocalDateString(), month: currentMonth, rentAmount: billTenant.rentAmount, prevMeter: previous, currMeter: current, unitPrice: rate, electricityBill: elecBill, totalAmount: total, paidAmount: 0, isPaid: false, meterImage: meterImg || undefined };
      const updatedTenants = (data.tenants || []).map(t => {
          if (t.id === billTenant.id) return { ...t, due: Math.round(t.due + total), currentMeterReading: current, entryMeterImage: t.lastMeterImage, lastMeterImage: meterImg || t.lastMeterImage };
          return t;
      });
      setData({ ...data, tenants: updatedTenants, bills: [newBill, ...(data.bills || [])] });
      triggerNavEmotion('magic'); setBillTenant(null); setCurrReading(''); setMeterImg(null); setShowReadingConfirm(false);
  };

  const receivePayment = () => {
      if(!payTenant) return;
      const cashAmount = Math.round(Number(payAmount)) || 0; let advanceDeducted = 0, finalDue = payTenant.due;
      if (useAdvance && payTenant.advance > 0) { advanceDeducted = Math.min(finalDue, payTenant.advance); finalDue -= advanceDeducted; }
      finalDue -= cashAmount; if (cashAmount <= 0 && advanceDeducted <= 0) return;
      const newDue = Math.max(0, Math.round(finalDue)), totalSettled = cashAmount + advanceDeducted;
      if (newDue > 0 && !nextDate) { alert("Partial payment detected! Please select a reminder date."); setShowCalendar(true); return; }
      
      // ADDED: Saved advanceAdjustment field for proof
      const newBill: Bill = { 
          id: Date.now().toString(), 
          tenantId: payTenant.id, 
          date: getLocalDateString(), 
          month: 'Payment', 
          rentAmount: 0, 
          prevMeter: 0, 
          currMeter: 0, 
          unitPrice: 0, 
          electricityBill: 0, 
          totalAmount: 0, 
          paidAmount: totalSettled, 
          isPaid: true,
          advanceAdjustment: advanceDeducted > 0 ? advanceDeducted : undefined 
      };
      
      let updatedTenants = [...(data.tenants || [])];
      if (payTenant.status === 'Archived' && newDue === 0) updatedTenants = updatedTenants.filter(t => t.id !== payTenant.id);
      else updatedTenants = updatedTenants.map(t => t.id === payTenant.id ? { ...t, due: newDue, advance: Math.max(0, Math.round(t.advance - advanceDeducted)), reminderDate: nextDate || undefined } : t);
      setData({ ...data, tenants: updatedTenants, bills: [newBill, ...(data.bills || [])] });
      triggerNavEmotion('rich'); setPayTenant(null); setPayAmount(''); setNextDate(''); setUseAdvance(false);
  };

  const handleSwitchClick = (tenant: Tenant) => {
      if (tenant.due > 0) { setPayTenant(tenant); setUseAdvance(false); } 
      else setBillTenant(tenant);
  };

  const displayDue = payTenant ? (payTenant.due - (useAdvance ? Math.min(payTenant.due, payTenant.advance) : 0)) : 0;
  const remainingDue = Math.max(0, displayDue - (Number(payAmount) || 0));
  const isPayDisabled = (remainingDue > 0 && !nextDate) || (Number(payAmount) + (useAdvance ? Math.min(payTenant?.due || 0, payTenant?.advance || 0) : 0) > (payTenant?.due || 0)) || (Number(payAmount) + (useAdvance ? Math.min(payTenant?.due || 0, payTenant?.advance || 0) : 0) <= 0);

  // Helper for showing advance adjustment
  const potentialAdjustment = payTenant ? Math.min(payTenant.due, payTenant.advance) : 0;

  return (
      <div className={`h-screen flex flex-col animate-fade-in ${isLight ? 'bg-app-lightBg' : 'bg-app-bg'}`}>
          <div className="flex-none z-50"><TopBar title="Tenants" data={data} setData={setData} weather={weather} onOpenSettings={onOpenSettings} /></div>
          <div className="flex-1 overflow-y-auto pb-32">
              <div className={`sticky top-0 z-30 px-5 py-3 backdrop-blur-md ${isLight ? 'bg-white/80' : 'bg-app-bg/80'}`}>
                  <div className="flex gap-2 mb-3">
                      <div className={`flex-1 flex items-center px-3 rounded-xl border ${isLight ? 'bg-white border-gray-200' : 'bg-[#18191F] border-gray-800'}`}><Search size={16} className="text-gray-400 mr-2"/><input value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Search..." className={`w-full py-3 bg-transparent outline-none text-sm font-bold ${isLight ? 'text-black' : 'text-white'}`} /></div>
                      <button onClick={() => setViewMode(viewMode === 'active' ? 'archived' : 'active')} className={`px-4 rounded-xl border font-bold text-xs flex flex-col items-center justify-center ${viewMode === 'active' ? (isLight ? 'bg-white text-gray-600' : 'bg-[#18191F] text-gray-400') : 'bg-red-500 text-white border-red-500'}`}>
                          {viewMode === 'active' ? (
                              <div className="relative">
                                  <Trash2 size={14} className={hasArchived ? "text-red-500 animate-[swing_1s_ease-in-out_infinite]" : ""} />
                                  {hasArchived && <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-ping"></span>}
                              </div>
                          ) : <RotateCcw size={14}/>}
                          <span>{viewMode === 'active' ? 'Archived' : 'List'}</span>
                      </button>
                  </div>
              </div>
              <div className="px-5 space-y-4">
                  {filtered.map(t => {
                      const curBill = (data.bills || []).find(b => b.tenantId === t.id && b.month === currentMonth);
                      const hasBillThisMonth = !!curBill;
                      const theme = getTenantTheme(t.id); const cardStyle = isLight ? theme.light : theme.dark;
                      
                      let switchType: 'due' | 'paid' | 'generate' = 'generate';
                      let isDisabled = false;

                      if (t.due <= 0) {
                          if (hasBillThisMonth && !isLastDay) {
                              switchType = 'paid';
                              isDisabled = true;
                          } else {
                              switchType = 'generate';
                              isDisabled = false;
                          }
                      } else {
                          switchType = 'due';
                          isDisabled = false;
                      }

                      let statusText = t.due > 0 ? `Rent: ৳${t.due}` : (hasBillThisMonth && !isLastDay ? `Paid ৳${curBill?.totalAmount || 0}` : 'Make Bill');
                      let arrears = t.due; if (curBill && !curBill.isPaid) arrears = Math.max(0, t.due - (curBill.totalAmount - curBill.paidAmount)); else if (!curBill) arrears = t.due;
                      const unpaidBills = (data.bills || []).filter(b => b.tenantId === t.id && !b.isPaid && b.month !== currentMonth).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
                      const oldestBill = unpaidBills[0]; const dueDateStr = oldestBill ? new Date(oldestBill.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) : '';

                      return (
                      <div key={t.id} className={`p-4 rounded-[24px] border relative overflow-hidden transition-all ${cardStyle} ${isLight ? 'shadow-sm' : ''}`}>
                          <div className="flex gap-4 items-center">
                              <div className="flex-1 min-w-0">
                                  <div className="flex gap-3 mb-2">
                                      <div className={`w-12 h-12 rounded-xl overflow-hidden bg-gray-700 shrink-0 shadow-md border border-white/10`}>{t.profileImage ? <img src={t.profileImage} className="w-full h-full object-cover"/> : <div className="w-full h-full flex items-center justify-center text-gray-500"><User size={20}/></div>}</div>
                                      <div>
                                          <h3 className={`font-black text-xl leading-tight mb-0.5 tracking-wide drop-shadow-sm ${isLight ? 'text-[#6002EE]' : 'text-[#CCF381]'}`}>{t.name}</h3>
                                          <div className="flex flex-col gap-0.5 mt-1">
                                              <div className={`text-[10px] font-bold px-2 py-0.5 rounded-md border flex items-center gap-1 shadow-[0_0_10px_currentColor] animate-pulse w-max ${isLight ? 'bg-blue-50 text-blue-600 border-blue-200' : 'bg-cyan-900/30 text-cyan-400 border-cyan-500/50'}`}><Home size={10} /> Room: {t.unitId}</div>
                                              <div className={`text-[10px] font-bold px-2 py-0.5 rounded-md border flex items-center gap-1 w-max ${isLight ? 'bg-gray-100 text-gray-500 border-gray-200' : 'bg-white/5 text-gray-400 border-white/10'}`}><Calendar size={10} /> Pay: {nextPayDateStr}</div>
                                              <div className="mt-0.5">{arrears > 0 && (<span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border flex items-center gap-1 w-max ${isLight ? 'bg-red-50 text-red-600 border-red-200' : 'bg-red-900/30 text-red-400 border-red-500/30'}`}><AlertTriangle size={10} /> Due: ৳{arrears} {dueDateStr}</span>)}</div>
                                          </div>
                                      </div>
                                  </div>
                                  {viewMode === 'active' ? (
                                      <div className="flex items-end justify-between mr-2"><div className="flex gap-2"><button onClick={() => onEditTenant(t.id)} className={`h-9 w-9 rounded-lg flex items-center justify-center transition-all active:scale-90 ${isLight ? 'bg-gray-100 text-blue-500' : 'bg-[#1f2128] text-blue-400 border border-white/5'}`}><FileText size={16}/></button><button onClick={() => shareTenantDetails(t)} className={`h-9 w-9 rounded-lg flex items-center justify-center transition-all active:scale-90 ${isLight ? 'bg-gray-100 text-green-500' : 'bg-[#1a2520] text-green-400 border border-white/5'}`}><Share2 size={16}/></button><a href={`tel:${t.phone}`} className={`h-9 w-9 rounded-lg flex items-center justify-center transition-all active:scale-90 ${isLight ? 'bg-blue-50 text-blue-600' : 'bg-blue-500/10 text-blue-400 border border-white/5'}`}><Phone size={16}/></a><button onClick={() => moveToRecycleBin(t.id)} className={`h-9 w-9 rounded-lg flex items-center justify-center transition-all active:scale-90 ${isLight ? 'bg-orange-50 text-orange-500' : 'bg-orange-500/10 text-orange-500 border border-white/5'}`}><Archive size={16}/></button></div><div className="flex flex-col items-end gap-1"><span className={`text-[9px] font-bold px-1.5 rounded w-max flex items-center gap-1 ${isLight ? 'text-blue-600' : 'text-blue-400'}`}>🏠 Rent: ৳{t.rentAmount}</span>{t.advance > 0 && <span className={`text-[9px] font-bold px-1.5 rounded w-max flex items-center gap-1 ${isLight ? 'text-orange-600' : 'text-orange-400'}`}>💰 Adv.: ৳{t.advance}</span>}</div></div>
                                  ) : (
                                      <div className="flex gap-2 w-full mt-2">{t.due > 0 && <button onClick={() => setPayTenant(t)} className="flex-1 h-10 bg-blue-500 text-white rounded-xl text-xs font-bold active:scale-95 transition flex items-center justify-center gap-1 shadow-lg shadow-blue-500/20"><DollarSign size={14}/> Pay</button>}<button onClick={() => restoreTenant(t.id)} className="flex-1 h-10 bg-green-500/10 text-green-500 border border-green-500/20 rounded-xl text-xs font-bold active:scale-95 transition flex items-center justify-center gap-2 hover:bg-green-500/20"><RotateCcw size={14} /> Restore</button><button onClick={() => setDeleteConfirmId(t.id)} className="flex-1 h-10 bg-red-500 text-white rounded-xl text-xs font-bold active:scale-95 transition flex items-center justify-center gap-2 shadow-lg shadow-red-500/20 hover:bg-red-600"><Trash2 size={14} /> Delete</button></div>
                                  )}
                              </div>
                              {viewMode === 'active' && (
                                  <div className="flex flex-col items-center gap-1">
                                      <VerticalPowerSwitch 
                                          type={switchType} 
                                          disabled={isDisabled} 
                                          onClick={() => handleSwitchClick(t)} 
                                          isUrgent={isBillingSeason && !hasBillThisMonth} 
                                      />
                                      <span className={`${statusText.length > 10 ? 'text-[7px] leading-tight tracking-tighter' : 'text-[9px]'} font-bold uppercase mt-1 whitespace-nowrap ${switchType !== 'paid' ? 'animate-pulse' : ''} ${t.due > 0 ? 'text-red-500' : (hasBillThisMonth && !isLastDay ? 'text-green-500' : 'text-yellow-500')}`}>{statusText}</span>
                                  </div>
                              )}
                          </div>
                      </div>
                  )})}
                  {filtered.length === 0 && <div className="text-center py-20 opacity-40"><User size={48} className="mx-auto mb-2"/><p>No tenants found</p></div>}
              </div>
          </div>
          {billTenant && (
              <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4 animate-fade-in pb-safe">
                  <div className="w-full max-w-[320px] bg-black rounded-[24px] border border-gray-800 shadow-2xl p-5 relative mb-safe">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-xl font-bold text-white">Generate Bill</h3>
                          <p className="text-[10px] text-gray-400 font-medium">Meter Reading Process</p>
                        </div>
                        {(() => {
                           const prevValue = (billTenant.currentMeterReading || billTenant.startMeterReading || 0).toString();
                           const scaleClass = prevValue.length > 10 ? 'text-[10px]' : prevValue.length > 7 ? 'text-sm' : 'text-lg';
                           return (
                            <div className="text-right bg-[#111] border border-gray-800 px-3 py-1.5 rounded-xl min-w-[80px] max-w-[120px]">
                              <label className="text-[9px] text-gray-500 font-bold uppercase block truncate">Prev Reading</label>
                              <div className={`text-white font-mono font-bold leading-tight break-all ${scaleClass}`}>{prevValue}</div>
                            </div>
                           );
                        })()}
                      </div>
                      <div className="space-y-4">
                          <div className="flex gap-3">
                              {meterImg && (
                                  <div className={`flex-[2] bg-[#111] border rounded-xl px-4 py-3 relative transition-all animate-slide-up ${aiSuccess ? 'border-green-500' : 'border-[#CCF381]/30'}`}>
                                      <label className="text-[10px] text-gray-400 font-bold uppercase block mb-1 flex justify-between">
                                          <span>Curr Reading</span>
                                          <span className="text-green-500 font-bold">Ready</span>
                                      </label>
                                      <input 
                                          type="number" 
                                          autoFocus
                                          value={currReading} 
                                          onChange={e => setCurrReading(e.target.value)} 
                                          className="w-full bg-transparent text-white font-bold text-xl outline-none placeholder-gray-700" 
                                          placeholder="0000" 
                                      />
                                  </div>
                              )}
                              
                              <label className={`rounded-xl flex items-center justify-center cursor-pointer active:scale-95 transition relative overflow-hidden group shadow-lg ${isAiReading ? 'bg-gray-800 cursor-wait' : (!meterImg ? (isLight ? 'bg-white border-2 border-dashed border-red-500 hover:bg-red-50' : 'bg-[#111] border-2 border-dashed border-red-500/50 hover:bg-white/5') : 'bg-red-600 hover:bg-red-700')} ${!meterImg ? 'flex-1 h-36' : 'w-14 h-14 mt-3'}`}>
                                  <input type="file" accept="image/*" capture="environment" className="hidden" onChange={handleMeterUpload} disabled={isAiReading} />
                                  
                                  {isAiReading ? (
                                      <Loader2 size={24} className="text-emerald-500 animate-spin" />
                                  ) : !meterImg ? (
                                      <div className="flex flex-col items-center animate-tada">
                                          <div className="scale-90 flex flex-col items-center relative"> 
                                              <div className={`w-16 h-20 rounded-lg p-1.5 relative flex flex-col items-center shadow-lg transition-transform group-hover:scale-105 ${isLight ? 'bg-gradient-to-br from-emerald-400 to-emerald-500' : 'bg-gradient-to-br from-emerald-600 to-emerald-700'}`}>
                                                  <div className="absolute inset-0 rounded-lg border-b-4 border-r-4 border-black/20 pointer-events-none"></div>
                                                  <div className="w-full h-8 bg-[#1a1a1a] rounded border border-emerald-300/30 mb-1 flex items-center justify-center relative overflow-hidden shadow-inner">
                                                      <Zap size={14} className="text-yellow-400 fill-yellow-400 animate-[pulse_2s_infinite]" />
                                                      <div className="absolute -top-4 -left-4 w-8 h-8 bg-white/10 rotate-45 blur-sm"></div>
                                                  </div>
                                                  <div className="flex gap-1 mb-1">
                                                      <div className="w-2 h-2 rounded-full bg-yellow-400 shadow-sm"></div>
                                                      <div className="w-2 h-2 rounded-full bg-yellow-400 shadow-sm"></div>
                                                      <div className="w-2 h-2 rounded-full bg-yellow-400 shadow-sm"></div>
                                                  </div>
                                                  <div className="w-[90%] h-3 bg-black/20 rounded mt-auto mb-0.5 border border-white/10 flex justify-around items-center px-0.5">
                                                      <div className="w-0.5 h-0.5 rounded-full bg-gray-400"></div>
                                                      <div className="w-0.5 h-0.5 rounded-full bg-gray-400"></div>
                                                      <div className="w-0.5 h-0.5 rounded-full bg-gray-400"></div>
                                                  </div>
                                              </div>
                                              <div className="flex gap-1.5 -mt-0.5 relative z-0">
                                                  <div className="w-1 h-2.5 bg-gray-400 rounded-b-full shadow-sm"></div>
                                                  <div className="w-1 h-2.5 bg-gray-400 rounded-b-full shadow-sm"></div>
                                                  <div className="w-1 h-2.5 bg-gray-400 rounded-b-full shadow-sm"></div>
                                                  <div className="w-1 h-2.5 bg-gray-400 rounded-b-full shadow-sm"></div>
                                              </div>
                                              
                                              <div className="absolute -bottom-2 -right-3 bg-white text-red-600 p-2 rounded-full shadow-lg border-2 border-red-100 z-10 animate-bounce">
                                                  <Camera size={20} strokeWidth={3} />
                                              </div>
                                          </div>
                                          <span className={`text-[10px] font-black uppercase tracking-widest mt-2 ${isLight ? 'text-red-600' : 'text-red-400'}`}>Tap to Scan</span>
                                      </div>
                                  ) : (
                                      <Camera size={24} className="text-white animate-heartbeat" />
                                  )}
                              </label>
                          </div>

                          {meterImg && (
                              <div className="h-16 w-full rounded-xl overflow-hidden border border-gray-800 relative group animate-fade-in">
                                  <img src={meterImg} className="w-full h-full object-cover opacity-50 group-hover:opacity-100 transition-opacity"/>
                                  <div className="absolute inset-0 flex items-center justify-center text-xs text-white font-bold pointer-events-none group-hover:hidden">Image Attached</div>
                                  <button onClick={() => setMeterImg(null)} className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full hidden group-hover:block"><X size={12}/></button>
                              </div>
                          )}

                          <div className="flex gap-3 mt-4">
                              <button onClick={() => setBillTenant(null)} className="flex-1 py-3 bg-[#222] text-white font-bold rounded-xl active:scale-95 transition">Cancel</button>
                              {currReading !== '' && meterImg && Number(currReading) >= (billTenant.currentMeterReading || billTenant.startMeterReading || 0) ? (
                                  <button onClick={() => setShowReadingConfirm(true)} className="flex-[2] py-3 font-bold rounded-xl bg-[#CCF381] text-black shadow-glow active:scale-95 transition animate-fade-in">Generate</button>
                              ) : <div className="flex-[2]"></div>}
                          </div>
                      </div>
                  </div>
              </div>
          )}
          {payTenant && (
              <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 pb-safe">
                  <div className={`w-full max-w-[320px] p-5 rounded-[24px] shadow-2xl animate-slide-up relative mb-safe flex flex-col ${isLight ? 'bg-white' : 'bg-[#18191F] border border-gray-700'}`} onClick={(e) => e.stopPropagation()}>
                      <div className="flex justify-between items-start mb-3"><div><h3 className={`text-lg font-black mb-0.5 ${isLight ? 'text-black' : 'text-white'}`}>Collect Rent</h3><div className="flex items-baseline gap-1.5"><span className="text-sm font-bold text-red-400">Due:</span><span className="text-2xl font-black text-red-600 tracking-tighter drop-shadow-sm">৳{displayDue}</span></div></div><button onClick={() => setPayTenant(null)} className="p-1.5 bg-gray-800 rounded-full text-white hover:bg-gray-700 transition"><X size={14}/></button></div>
                      {getDueBreakdown(payTenant).length > 0 && <div className={`mb-3 rounded-xl overflow-hidden border ${isLight ? 'bg-gray-50 border-gray-200' : 'bg-black/20 border-gray-800'}`}><div className={`px-3 py-1.5 text-[9px] font-bold uppercase tracking-wider border-b flex items-center gap-1 ${isLight ? 'bg-gray-100 text-gray-500 border-gray-200' : 'bg-white/5 text-gray-400 border-gray-800'}`}><ListFilter size={10} /> Breakdown</div><div className="max-h-[80px] overflow-y-auto">{getDueBreakdown(payTenant).map((item, idx) => (<div key={idx} className={`flex justify-between items-center px-3 py-1.5 border-b last:border-0 ${isLight ? 'border-gray-100' : 'border-gray-800'}`}><div className="flex items-center gap-2"><div className={`w-1.5 h-1.5 rounded-full ${item.isRunning ? 'bg-blue-500 animate-pulse' : 'bg-orange-500'}`}></div><span className={`text-[10px] font-bold ${isLight ? 'text-gray-700' : 'text-gray-300'}`}>{item.label}</span></div><span className={`text-[10px] font-black ${isLight ? 'text-black' : 'text-white'}`}>৳{item.amount}</span></div>))}</div></div>}
                      <div className="space-y-3">
                          <div className={`p-3 rounded-xl border flex items-center gap-2 relative ${isLight ? 'border-green-500 bg-green-50' : 'border-green-500 bg-green-500/10'}`}><span className="text-green-500 font-bold text-lg">৳</span><input type="number" autoFocus autoComplete="off" placeholder="Cash Amount" value={payAmount} onChange={e => setPayAmount(e.target.value)} className={`bg-transparent w-full outline-none font-black text-xl ${isLight ? 'text-black' : 'text-white'}`}/><button type="button" onClick={() => setShowCalendar(true)} className={`p-2 rounded-lg transition-all active:scale-95 flex items-center justify-center ${remainingDue > 0 && !nextDate ? 'bg-red-500 text-white animate-bounce' : (isLight ? 'bg-gray-200 text-blue-600' : 'bg-gray-700 text-blue-400')}`}><Calendar size={18} /></button></div>
                          {payTenant.advance > 0 && <div className={`p-2.5 rounded-xl border flex flex-col justify-between gap-2 ${isLight ? 'bg-blue-50 border-blue-100' : 'bg-blue-900/20 border-blue-500/30'}`}>
                              <div className="flex items-center gap-2"><Wallet size={16} className="text-blue-500"/><div><p className={`text-[9px] font-bold uppercase ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>Advance</p><p className={`font-bold text-xs ${isLight ? 'text-blue-600' : 'text-blue-400'}`}>৳{payTenant.advance}</p></div></div>
                              <div className="flex items-center justify-between w-full">
                                  <div className="flex items-center gap-2"><span className={`text-[9px] font-bold ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>Advance Adjustment</span><span className="text-[8px] text-red-400 font-bold ml-1">(Leaving?)</span></div>
                                  <input type="checkbox" checked={useAdvance} onChange={e => setUseAdvance(e.target.checked)} className="w-6 h-6 accent-blue-500"/>
                              </div>
                              {useAdvance && <div className="text-center text-[10px] text-blue-500 font-black animate-pulse bg-white/20 rounded py-1">Adjusting: ৳{potentialAdjustment}</div>}
                          </div>}
                          <div className={`flex justify-between items-center px-1 text-xs font-bold ${isLight ? 'text-gray-600' : 'text-gray-300'}`}><span>Status:</span>{remainingDue > 0 ? <span className="text-red-500 flex items-center gap-1">Remaining: ৳{remainingDue}</span> : <span className="text-green-500 flex items-center gap-1 animate-pulse"><CheckCircle size={12} /> Full Paid</span>}</div>
                          {nextDate && (<div className="p-2 rounded-xl bg-blue-500/10 border border-blue-500/20 text-[10px] text-center font-bold text-blue-500 flex flex-col items-center justify-center gap-0.5"><div className="flex items-center gap-2"><Clock size={14}/> <span>Reminder: <span className="text-sm font-black underline">৳{remainingDue}</span></span><button onClick={() => setNextDate('')}><X size={12} className="text-blue-400"/></button></div><div className="opacity-80 uppercase tracking-wide">On {new Date(nextDate).toDateString()}</div></div>)}
                          <button onClick={receivePayment} disabled={isPayDisabled} className={`w-full py-3 font-black rounded-xl text-base shadow-lg active:scale-95 transition ${isPayDisabled ? 'bg-gray-500 cursor-not-allowed opacity-70 text-gray-300' : 'bg-green-500 text-white shadow-green-500/20'}`}>Confirm Pay</button>
                      </div>
                  </div>
              </div>
          )}
          {restoreConflict && (
              <div className="fixed inset-0 z-[9999] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in pb-safe" onClick={() => setRestoreConflict(null)}>
                  <div className={`w-full max-w-[300px] rounded-[32px] p-6 relative border-2 shadow-2xl flex flex-col items-center mb-safe ${isLight ? 'bg-white border-orange-200' : 'bg-[#1a1005] border-orange-500'}`} onClick={e => e.stopPropagation()}>
                      <div className="w-16 h-16 rounded-full bg-orange-500 text-white flex items-center justify-center mb-4 shadow-lg shadow-orange-500/40 animate-pulse"><AlertTriangle size={32} /></div>
                      <h2 className={`text-xl font-black uppercase tracking-wider text-center mb-2 ${isLight ? 'text-black' : 'text-white'}`}>Room Occupied!</h2>
                      <p className={`text-center text-xs font-bold mb-6 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>Room <span className="text-orange-500">{restoreConflict.unitId}</span> is currently taken. <br/> Assign a new room to restore <span className="text-white bg-orange-500 px-1 rounded">{restoreConflict.name}</span>.</p>
                      <div className="w-full space-y-3">
                          <div className={`flex items-center px-4 py-3 rounded-xl border-2 transition-all duration-300 ${shakeInput ? 'border-red-500 bg-red-500/10 animate-shake' : (isLight ? 'bg-gray-50 border-gray-200' : 'bg-black/30 border-orange-500/30')}`}>
                              <Home size={18} className={`${shakeInput ? 'text-red-500' : 'text-orange-500'} mr-3`} />
                              <input 
                                  type="number"
                                  value={restoreRoom} 
                                  onChange={e => { 
                                      const val = e.target.value;
                                      const isTaken = data.tenants.some(t => t.status === 'Active' && norm(t.unitId) === norm(val));
                                      if (isTaken) {
                                          setRestoreRoom('');
                                          setShakeInput(true);
                                          if(navigator.vibrate) navigator.vibrate(50);
                                      } else {
                                          setRestoreRoom(val);
                                          setShakeInput(false);
                                      }
                                  }} 
                                  placeholder="New Room No" 
                                  className={`w-full bg-transparent outline-none font-bold ${isLight ? 'text-black' : 'text-white'}`} 
                                  autoFocus 
                              />
                          </div>
                          <div className="flex gap-2 w-full"><div className={`flex-1 flex items-center px-4 py-3 rounded-xl border-2 transition-opacity ${!restoreMeterImg ? 'opacity-50 cursor-not-allowed' : ''} ${isLight ? 'bg-gray-50 border-gray-200' : 'bg-black/30 border-orange-500/30'}`}><Zap size={18} className={`${restoreMeterImg ? 'text-yellow-500' : 'text-gray-500'} mr-3`} /><input type="number" disabled={!restoreMeterImg} value={restoreMeter} onChange={e => setRestoreMeter(e.target.value)} placeholder={restoreMeterImg ? "Start Reading" : "Take Photo First"} className={`w-full bg-transparent outline-none font-bold ${isLight ? 'text-black' : 'text-white'}`} /></div>
                          <label className={`w-12 rounded-xl flex items-center justify-center cursor-pointer active:scale-95 transition bg-orange-500 hover:bg-orange-600 animate-heartbeat shadow-lg shadow-orange-500/50`}><input type="file" accept="image/*" capture="environment" className="hidden" onChange={handleRestoreMeterUpload} /><Camera size={18} className="text-white" /></label></div>
                      </div>
                      <div className="flex gap-3 w-full mt-6"><button onClick={() => setRestoreConflict(null)} className={`flex-1 py-3 rounded-xl font-bold text-xs ${isLight ? 'bg-gray-100 text-gray-600' : 'bg-white/10 text-gray-400'}`}>Cancel</button><button onClick={() => setShowRestoreReadingConfirm(true)} disabled={!restoreMeter || !restoreRoom || !restoreMeterImg} className={`flex-1 py-3 rounded-xl font-bold text-xs shadow-lg active:scale-95 transition ${(!restoreMeter || !restoreRoom || !restoreMeterImg) ? 'bg-gray-500 opacity-50 cursor-not-allowed' : 'bg-orange-500 text-white'}`}>Confirm Restore</button></div>
                  </div>
              </div>
          )}
          {showRestoreReadingConfirm && (
              <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in pb-safe">
                  <div className={`w-full max-w-[280px] p-6 rounded-[32px] shadow-2xl animate-slide-up relative border ${isLight ? 'bg-white border-gray-200' : 'bg-[#1a1a20] border-gray-800'}`}>
                      <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center mx-auto mb-4"><Zap size={24} className="text-orange-500" /></div>
                      <h3 className={`text-lg font-black text-center mb-1 ${isLight ? 'text-black' : 'text-white'}`}>Confirm Restore</h3>
                      <p className={`text-xs text-center mb-4 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>Room: <span className="font-bold">{restoreRoom}</span></p>
                      
                      <div className={`my-3 p-3 rounded-2xl text-center border-2 border-dashed ${isLight ? 'bg-orange-50 border-orange-200' : 'bg-orange-500/5 border-orange-500/20'}`}>
                          <span className="text-[10px] uppercase font-bold text-gray-500 block mb-1">Start Reading</span>
                          <span className={`text-3xl font-black ${isLight ? 'text-orange-600' : 'text-orange-500'}`}>{restoreMeter}</span>
                      </div>
                      
                      <p className={`text-sm text-center mb-6 font-medium ${isLight ? 'text-gray-600' : 'text-gray-400'}`}>Is this correct?</p>
                      
                      <div className="grid grid-cols-2 gap-3">
                          <button onClick={() => setShowRestoreReadingConfirm(false)} className={`py-3 rounded-xl font-bold text-xs ${isLight ? 'bg-gray-100 text-gray-600' : 'bg-white/5 text-gray-400'}`}>No</button>
                          <button onClick={confirmRestoreWithNewRoom} className="py-3 rounded-xl font-bold text-xs bg-orange-500 text-white shadow-lg shadow-orange-500/20 active:scale-95 transition">Yes</button>
                      </div>
                  </div>
              </div>
          )}
          <CustomCalendarModal isOpen={showCalendar} onClose={() => setShowCalendar(false)} onSelect={(date) => setNextDate(date)} />
          {showReadingConfirm && (
              <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in pb-safe">
                  <div className={`w-full max-w-[280px] p-6 rounded-[32px] shadow-2xl animate-slide-up relative border ${isLight ? 'bg-white border-gray-200' : 'bg-[#1a1a20] border-gray-800'}`}>
                      <div className="w-12 h-12 bg-app-accent/20 rounded-full flex items-center justify-center mx-auto mb-4"><AlertTriangle size={24} className="text-app-accent" /></div>
                      <h3 className={`text-lg font-black text-center mb-2 ${isLight ? 'text-black' : 'text-white'}`}>Verify Reading</h3>
                      <div className={`my-3 p-3 rounded-2xl text-center border-2 border-dashed ${isLight ? 'bg-blue-50 border-blue-200' : 'bg-app-accent/5 border-app-accent/20'}`}><span className={`text-4xl font-black ${isLight ? 'text-blue-600' : 'text-app-accent'}`}>{currReading}</span></div>
                      <p className={`text-sm text-center mb-6 font-medium ${isLight ? 'text-gray-600' : 'text-gray-400'}`}>Are you sure the reading is correct?</p>
                      <div className="grid grid-cols-2 gap-3"><button onClick={() => setShowReadingConfirm(false)} className={`py-3 rounded-xl font-bold text-xs ${isLight ? 'bg-gray-100 text-gray-600' : 'bg-white/5 text-gray-400'}`}>No</button><button onClick={generateBill} className="py-3 rounded-xl font-bold text-xs bg-app-accent text-black shadow-lg shadow-app-accent/20 active:scale-95 transition">Yes</button></div>
                  </div>
              </div>
          )}

          {/* CUSTOM DELETE CONFIRMATION MODAL */}
          {deleteConfirmId && (
              <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in pb-safe" onClick={() => setDeleteConfirmId(null)}>
                  <div className={`w-full max-w-xs p-6 rounded-[28px] shadow-2xl animate-scale-in text-center relative ${isLight ? 'bg-white' : 'bg-[#1E1E24] border border-gray-700'}`} onClick={e => e.stopPropagation()}>
                      <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
                          <Trash2 size={32} className="text-red-500" />
                      </div>
                      <h3 className={`text-xl font-black mb-2 ${isLight ? 'text-black' : 'text-white'}`}>Delete Tenant?</h3>
                      <p className="text-sm font-bold text-gray-500 mb-6">"Do you want to delete?"</p>
                      <div className="flex gap-3">
                          <button 
                              onClick={() => setDeleteConfirmId(null)}
                              className={`flex-1 py-3 rounded-xl font-bold text-sm ${isLight ? 'bg-gray-100 text-gray-700' : 'bg-white/10 text-gray-300'}`}
                          >
                              No
                          </button>
                          <button 
                              onClick={confirmDeleteAction}
                              className="flex-1 py-3 rounded-xl font-bold text-sm bg-red-500 text-white shadow-lg shadow-red-500/30 active:scale-95 transition"
                          >
                              Yes
                          </button>
                      </div>
                  </div>
              </div>
          )}
      </div>
  );
};

export default Tenants;