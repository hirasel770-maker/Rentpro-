import React, { useState, useEffect, useRef } from 'react';
import { AppData, Page, Tenant, CustomField, Unit, ServiceContact } from '../types';
import { compressImage, cropImage } from './services/imageService';
import { extractTenantInfoFromID, detectFaceCoordinates } from './services/aiService';
import { 
  User, Phone, Home, Calendar, CreditCard, 
  Camera, Plus, Trash2, X, Archive,
  Loader2, ScanLine, Zap, Trash, FileText, ImageIcon, AlertTriangle, Layers, CheckCircle2, History, ArrowRight, RotateCcw, ChevronLeft
} from 'lucide-react';

interface Props {
  data: AppData;
  setData: (data: AppData) => void;
  setPage: (page: Page) => void;
  setNavVisible: (visible: boolean) => void;
  onOpenSettings: () => void;
  editingId: string | null;
  clearEditing: () => void;
  focusField?: string | null; 
}

const RentForm: React.FC<Props> = ({ data, setData, setPage, setNavVisible, editingId, clearEditing, focusField }) => {
  // --- CORE FIELDS ---
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [occupation, setOccupation] = useState(''); 
  const [unitId, setUnitId] = useState('');
  const [rentAmount, setRentAmount] = useState('');
  const [garbageBill, setGarbageBill] = useState('');
  const [advance, setAdvance] = useState('');
  const [entryDate, setEntryDate] = useState(new Date().toISOString().split('T')[0]);
  
  // --- UI STEPS ---
  const [isRoomConfirmed, setIsRoomConfirmed] = useState(false);
  const [initialMeterImg, setInitialMeterImg] = useState<string | null>(null); // Pre-capture image

  // --- METER INFO ---
  const [meterNumber, setMeterNumber] = useState('');
  const [startMeterReading, setStartMeterReading] = useState('');
  const [unitPrice, setUnitPrice] = useState(''); 

  // --- IMAGES ---
  const [idImage, setIdImage] = useState<string | null>(null);
  const [idBackImage, setIdBackImage] = useState<string | null>(null); 
  const [profileImage, setProfileImage] = useState<string | null>(null);
  
  // --- EXTRAS ---
  const [customFields, setCustomFields] = useState<CustomField[]>([]);
  const [extraCharge, setExtraCharge] = useState(''); 
  
  const [showFieldModal, setShowFieldModal] = useState(false);
  const [newFieldLabel, setNewFieldLabel] = useState('');
  const [newFieldAmount, setNewFieldAmount] = useState('');

  // --- POPUPS ---
  const [showUnitPopup, setShowUnitPopup] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [isProfileScanning, setIsProfileScanning] = useState(false); 
  const [isCapturingMeter, setIsCapturingMeter] = useState(false); 
  
  // CONFLICT POPUP STATE (Active Tenant Only)
  const [conflictTenantForModal, setConflictTenantForModal] = useState<Tenant | null>(null);
  
  // --- REFS ---
  const unitInputRef = useRef<HTMLDivElement>(null);
  const roomInputRef = useRef<HTMLInputElement>(null); 
  const startReadingRef = useRef<HTMLInputElement>(null); // New Ref for reading
  const advanceInputRef = useRef<HTMLInputElement>(null); 
  const footerRef = useRef<HTMLDivElement>(null); 

  // --- SCROLL TARGET REFS ---
  const phoneContainerRef = useRef<HTMLDivElement>(null); // NEW REF for Phone Scroll
  const rentContainerRef = useRef<HTMLDivElement>(null);
  const garbageContainerRef = useRef<HTMLDivElement>(null);
  const extraChargesSectionRef = useRef<HTMLDivElement>(null);
  
  const isLight = data.settings.theme === 'light';

  useEffect(() => {
    setNavVisible(false);
    return () => setNavVisible(true);
  }, [setNavVisible]);

  // Load editing data
  useEffect(() => {
    if (editingId) {
      const t = data.tenants.find(t => t.id === editingId);
      if (t) {
        setName(t.name);
        setPhone(t.phone);
        setOccupation(t.occupation || '');
        setUnitId(t.unitId);
        setRentAmount(t.rentAmount.toString());
        setGarbageBill(t.garbageBill ? t.garbageBill.toString() : '');
        
        setIsRoomConfirmed(true); 
        // Logic: When editing, we show the current latest photo as the starting point
        setInitialMeterImg(t.lastMeterImage || null); 

        if (focusField === 'advance') {
            setAdvance('');
        } else {
            setAdvance(t.advance.toString());
        }
        
        setEntryDate(t.entryDate ? t.entryDate.split('T')[0] : new Date().toISOString().split('T')[0]);
        setMeterNumber(t.meterNumber || '');
        setStartMeterReading(t.startMeterReading?.toString() || '');
        setUnitPrice(t.unitPrice ? t.unitPrice.toString() : ''); 
        setIdImage(t.idImage || null);
        setIdBackImage(t.idBackImage || null);
        setProfileImage(t.profileImage || null);
        
        if (t.customFields) {
            const fixed = t.customFields.find(f => f.id === 'fixed_extra' || f.label === 'Extra Charge');
            if (fixed) {
                setExtraCharge(fixed.amount.toString());
                setCustomFields(t.customFields.filter(f => f.id !== 'fixed_extra' && f.label !== 'Extra Charge'));
            } else {
                setCustomFields(t.customFields);
            }
        } else {
            setCustomFields([]);
        }
        
        if (focusField === 'advance') {
            setTimeout(() => {
                advanceInputRef.current?.focus();
            }, 500);
        }
      }
    } else {
        setInitialMeterImg(null);
    }
  }, [editingId, data.tenants, focusField]);

  const addCustomField = () => {
    if(newFieldLabel && newFieldAmount) {
        setCustomFields([...customFields, { id: Date.now().toString(), label: newFieldLabel, amount: Number(newFieldAmount) }]);
        setNewFieldLabel('');
        setNewFieldAmount('');
        setShowFieldModal(false);
    }
  };

  const removeCustomField = (id: string) => {
    setCustomFields(customFields.filter(f => f.id !== id));
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'nid_combo' | 'profile') => {
      if (e.target.files && e.target.files.length > 0) {
          try {
              if (type === 'nid_combo') {
                  setIsScanning(true);
                  const files = Array.from(e.target.files) as File[];
                  
                  if (files.length >= 2) {
                      // Gallery Bulk Upload
                      const frontBase64 = await compressImage(files[1], 600, 0.6); 
                      setIdImage(frontBase64);
                      const backBase64 = await compressImage(files[0], 600, 0.6); 
                      setIdBackImage(backBase64);
                  } else if (files.length === 1) {
                      // Camera / Single File Logic (Front -> Back Cycle)
                      const newImage = await compressImage(files[0], 600, 0.6);
                      
                      if (!idImage) {
                          // First capture -> Front
                          setIdImage(newImage);
                      } else if (!idBackImage) {
                          // Second capture -> Back
                          setIdBackImage(newImage);
                      } else {
                          // Third capture -> Replace Front (Start Over)
                          setIdImage(newImage);
                      }
                  }
                  setIsScanning(false);
              } else {
                  const file = e.target.files[0];
                  if (!file) return;
                  const compressedBase64 = await compressImage(file, 600, 0.7);
                  setProfileImage(compressedBase64);
              }
          } catch (err) {
              console.error(err);
              setIsScanning(false);
          }
          // Reset input to allow triggering same file selection again
          e.target.value = '';
      }
  };

  const handleInitialMeterCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          setIsCapturingMeter(true);
          try {
              const compressed = await compressImage(file, 800, 0.7);
              setInitialMeterImg(compressed);
              if (navigator.vibrate) navigator.vibrate(50);
              setTimeout(() => startReadingRef.current?.focus(), 300); // Focus Start Reading first
          } catch (err) {
              console.error("Meter capture error", err);
          } finally {
              setIsCapturingMeter(false);
          }
      }
  };

  const handleRoomChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setUnitId(val);

      const activeConflict = data.tenants.find(t => 
          t.unitId.trim().toLowerCase() === val.trim().toLowerCase() && 
          t.status === 'Active' && 
          t.id !== editingId
      );

      if (activeConflict) {
          setConflictTenantForModal(activeConflict);
          e.target.blur();
          return;
      }
  };

  const handleConfirmRoom = () => {
      // VALIDATION: Start Reading MUST be present
      if (unitId.trim() && startMeterReading.trim() && !conflictTenantForModal) {
          setIsRoomConfirmed(true);
          if (navigator.vibrate) navigator.vibrate(50);
      }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
      if (e.key === 'Enter' && !isRoomConfirmed) {
          handleConfirmRoom();
      }
  };

  const handleArchiveConflict = () => {
      if (!conflictTenantForModal) return;
      const updatedTenants = data.tenants.map(t => 
          t.id === conflictTenantForModal.id ? { ...t, status: 'Archived' as const } : t
      );
      const updatedUnits = data.units.map(u => 
          u.name.toLowerCase() === conflictTenantForModal.unitId.toLowerCase() 
            ? { ...u, status: 'vacant' as const } 
            : u
      );
      setData({ ...data, tenants: updatedTenants, units: updatedUnits });
      setConflictTenantForModal(null);
  };

  const handleCancelConflict = () => {
      setUnitId(''); 
      setConflictTenantForModal(null);
      setTimeout(() => {
          roomInputRef.current?.focus();
      }, 100);
  };

  // Original handler for general inputs
  const handleAutoScroll = (e: React.FocusEvent<HTMLInputElement>) => {
      const target = e.target.closest('div'); 
      if (target) {
          setTimeout(() => {
              target.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }, 300); 
      }
  };

  // NEW: Scroll to Top handler for general use
  const handleScrollTop = (e: React.FocusEvent<HTMLInputElement>) => {
      const target = e.target.closest('div'); 
      if (target) {
          setTimeout(() => {
              target.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }, 300); 
      }
  };

  // --- SMART SCROLL HANDLERS ---
  const scrollForName = () => {
      // FIX: Scroll to Phone container to ensure Phone input is visible above keypad
      setTimeout(() => {
          phoneContainerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 100); // Reduced delay to 100ms for "immediate" scrolling
  };

  const scrollForUnitPrice = () => {
      setTimeout(() => {
          garbageContainerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 300);
  };

  const scrollForTotalExtra = () => {
      setTimeout(() => {
          extraChargesSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 300);
  };

  const handleFooterScroll = () => {
      setTimeout(() => {
          footerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
      }, 300);
  };

  const handleSave = () => {
      if (!name || !rentAmount || !unitId) {
          alert("Name, Room and Rent Amount are required!");
          return;
      }

      const existingTenant = data.tenants.find(t => t.unitId === unitId && t.status === 'Active' && t.id !== editingId);
      if (existingTenant) {
          setConflictTenantForModal(existingTenant);
          return;
      }

      const finalCustomFields = [...customFields];
      if (Number(extraCharge) > 0) {
          finalCustomFields.push({
              id: 'fixed_extra',
              label: 'Extra Charge',
              amount: Number(extraCharge)
          });
      }

      const tenantData: Tenant = {
          id: editingId || Date.now().toString(),
          name,
          phone,
          occupation,
          unitId,
          rentAmount: Number(rentAmount),
          garbageBill: Number(garbageBill) || 0,
          advance: Number(advance),
          entryDate: new Date(entryDate).toISOString(),
          meterNumber,
          startMeterReading: Number(startMeterReading),
          currentMeterReading: Number(startMeterReading), 
          unitPrice: unitPrice ? Number(unitPrice) : undefined,
          idImage: idImage || undefined,
          idBackImage: idBackImage || undefined,
          profileImage: profileImage || undefined,
          // NEW ROLLING LOGIC: Initial photo starts in Slot 2 (Latest)
          lastMeterImage: initialMeterImg || undefined, 
          entryMeterImage: undefined, // Slot 1 remains empty initially
          customFields: finalCustomFields,
          due: 0, 
          status: 'Active'
      };

      let updatedTenants;
      if (editingId) {
          const original = data.tenants.find(t => t.id === editingId);
          if (original) {
              tenantData.due = original.due;
              tenantData.status = original.status;
              tenantData.currentMeterReading = original.currentMeterReading; 
              tenantData.entryMeterImage = original.entryMeterImage;
              tenantData.lastMeterImage = initialMeterImg || original.lastMeterImage;
          }
          updatedTenants = data.tenants.map(t => t.id === editingId ? tenantData : t);
      } else {
          updatedTenants = [...data.tenants, tenantData];
      }

      // --- AUTO ADD TO PHONEBOOK LOGIC ---
      let updatedServiceContacts = [...(data.serviceContacts || [])];
      if (phone && name) {
          const contactIndex = updatedServiceContacts.findIndex(c => c.phone === phone);
          const contactPayload: ServiceContact = {
              id: contactIndex >= 0 ? updatedServiceContacts[contactIndex].id : `contact_${Date.now()}`,
              name: name,
              phone: phone,
              category: 'Other',
              image: profileImage || undefined
          };

          if (contactIndex >= 0) {
              updatedServiceContacts[contactIndex] = { ...updatedServiceContacts[contactIndex], ...contactPayload };
          } else {
              updatedServiceContacts.push(contactPayload);
          }
      }

      const normalizedUnitId = unitId.trim().toLowerCase();
      const existingUnitIndex = data.units.findIndex(u => u.name.trim().toLowerCase() === normalizedUnitId);
      let updatedUnits = [...data.units];

      if (existingUnitIndex >= 0) {
          updatedUnits[existingUnitIndex] = {
              ...updatedUnits[existingUnitIndex],
              status: 'occupied',
              meterNumber: meterNumber || updatedUnits[existingUnitIndex].meterNumber,
              currentMeterReading: Number(startMeterReading) || updatedUnits[existingUnitIndex].currentMeterReading
          };
      } else {
          const newAutoUnit: Unit = {
              id: 'auto_' + Date.now(),
              name: unitId, 
              meterNumber: meterNumber || 'N/A',
              currentMeterReading: Number(startMeterReading) || 0,
              status: 'occupied'
          };
          updatedUnits.push(newAutoUnit);
      }

      setData({ ...data, tenants: updatedTenants, units: updatedUnits, serviceContacts: updatedServiceContacts });
      clearEditing();
      setPage('tenants');
  };

  const handleBack = () => {
      clearEditing();
      setPage('dashboard');
  };

  // Helper for dynamic font size
  const getDynamicFontSize = (val: string) => {
      const len = val.length;
      if (len > 8) return 'text-sm';
      if (len > 6) return 'text-lg';
      if (len > 4) return 'text-xl';
      return 'text-2xl';
  };

  const showBigInput = !isRoomConfirmed || !!conflictTenantForModal;
  const inputContainer = `p-4 rounded-2xl flex items-center gap-3 border transition-all scroll-mt-24 ${isLight ? 'bg-white border-gray-200' : 'bg-[#1E1E24] border-gray-800 focus-within:border-gray-600'}`;
  const inputStyle = `w-full bg-transparent outline-none font-bold text-base ${isLight ? 'text-black placeholder-gray-400' : 'text-white placeholder-gray-500'}`;

  return (
    <div className={`h-screen flex flex-col animate-fade-in ${isLight ? 'bg-app-lightBg' : 'bg-[#14161F]'}`}>
      
      {/* 1. HEADER WITH BACK BUTTON */}
      <div className={`sticky top-0 z-40 flex items-center justify-between px-5 h-[70px] border-b transition-all duration-300 ${isLight ? 'bg-white/80 backdrop-blur-md border-gray-200 shadow-sm' : 'bg-black/30 backdrop-blur-md border-white/5 shadow-lg'}`}>
          <button 
            onClick={handleBack}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all active:scale-90 ${isLight ? 'bg-gray-100 text-gray-800 hover:bg-gray-200' : 'bg-white/10 text-white hover:bg-white/20'}`}
          >
              <ChevronLeft size={24} strokeWidth={2.5} />
          </button>
          <h1 className={`text-lg font-black tracking-tight ${isLight ? 'text-gray-800' : 'text-white'}`}>
              {editingId ? 'Edit Tenant' : 'Register Tenant'}
          </h1>
          <div className="w-10"></div> {/* Spacer for symmetry */}
      </div>

      <div className="flex-1 overflow-y-auto p-5 pb-32">
         <div className="space-y-4">
            
            {showBigInput && (
                <div ref={unitInputRef} className="flex flex-col items-center justify-center h-[60vh] animate-fade-in">
                    
                    {!initialMeterImg ? (
                        <div className="flex flex-col items-center gap-6">
                            <label className={`w-40 h-40 rounded-[2.5rem] border-4 border-dashed flex flex-col items-center justify-center cursor-pointer active:scale-95 transition-all relative overflow-visible group ${isLight ? 'bg-white border-emerald-400 text-emerald-500' : 'bg-[#1E1E24] border-emerald-500 text-emerald-400 shadow-[0_0_30px_rgba(16,185,129,0.2)] animate-pulse'}`}>
                                {isCapturingMeter ? (
                                    <Loader2 className="animate-spin" size={40} />
                                ) : (
                                    <>
                                        {/* CUSTOM 3D METER ICON (CSS DRAWING) */}
                                        <div className="flex flex-col items-center animate-tada scale-90">
                                            {/* Meter Body */}
                                            <div className={`w-20 h-24 rounded-xl p-1.5 relative flex flex-col items-center shadow-lg transition-transform group-hover:scale-105 ${isLight ? 'bg-gradient-to-br from-emerald-400 to-emerald-500' : 'bg-gradient-to-br from-emerald-600 to-emerald-700'}`}>
                                                
                                                {/* 3D Depth Border */}
                                                <div className="absolute inset-0 rounded-xl border-b-4 border-r-4 border-black/20 pointer-events-none"></div>

                                                {/* Screen Area */}
                                                <div className="w-full h-10 bg-[#1a1a1a] rounded-lg border border-emerald-300/30 mb-1.5 flex items-center justify-center relative overflow-hidden shadow-inner">
                                                    <Zap size={20} className="text-yellow-400 fill-yellow-400 animate-[pulse_2s_infinite]" />
                                                    {/* Screen Glare */}
                                                    <div className="absolute -top-4 -left-4 w-12 h-12 bg-white/10 rotate-45 blur-sm"></div>
                                                </div>

                                                {/* Buttons Row */}
                                                <div className="flex gap-1.5 mb-1.5">
                                                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-400 shadow-[0_2px_0_rgba(0,0,0,0.2)]"></div>
                                                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-400 shadow-[0_2px_0_rgba(0,0,0,0.2)]"></div>
                                                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-400 shadow-[0_2px_0_rgba(0,0,0,0.2)]"></div>
                                                </div>

                                                {/* Bottom Panel */}
                                                <div className="w-[90%] h-4 bg-black/20 rounded-md mt-auto mb-0.5 border border-white/10 flex justify-around items-center px-1">
                                                     <div className="w-1 h-1 rounded-full bg-gray-400"></div>
                                                     <div className="w-1 h-1 rounded-full bg-gray-400"></div>
                                                     <div className="w-1 h-1 rounded-full bg-gray-400"></div>
                                                     <div className="w-1 h-1 rounded-full bg-gray-400"></div>
                                                </div>
                                            </div>
                                            
                                            {/* Wires hanging out */}
                                            <div className="flex gap-2 -mt-1 relative z-0">
                                                <div className="w-1.5 h-3 bg-gray-400 rounded-b-full shadow-sm"></div>
                                                <div className="w-1.5 h-3 bg-gray-400 rounded-b-full shadow-sm"></div>
                                                <div className="w-1.5 h-3 bg-gray-400 rounded-b-full shadow-sm"></div>
                                                <div className="w-1.5 h-3 bg-gray-400 rounded-b-full shadow-sm"></div>
                                            </div>
                                        </div>
                                        
                                        <div className="absolute inset-0 bg-emerald-500/5 opacity-0 group-hover:opacity-100 transition-opacity rounded-[2rem]"></div>
                                        
                                        {/* NEW: Camera Icon Overlay (ENHANCED - BIGGER) */}
                                        <div className="absolute -bottom-2 -right-2 bg-white text-emerald-600 p-3 rounded-full shadow-xl border-[3px] border-emerald-100 z-10 animate-bounce">
                                            <Camera size={28} strokeWidth={2.5} />
                                        </div>
                                    </>
                                )}
                                <input 
                                    type="file" 
                                    accept="image/*" 
                                    capture="environment" 
                                    className="hidden" 
                                    onChange={handleInitialMeterCapture} 
                                    disabled={isCapturingMeter}
                                />
                            </label>
                            <div className="text-center">
                                <h3 className={`text-xl font-black ${isLight ? 'text-black' : 'text-white'}`}>Take Meter Photo</h3>
                                <p className={`text-xs font-bold uppercase tracking-widest mt-2 ${isLight ? 'text-gray-400' : 'text-gray-500'}`}>Required to Start Registration</p>
                            </div>
                        </div>
                    ) : (
                        <div className="w-full flex flex-col items-center animate-zoom-in-down">
                            <div className="relative mb-6">
                                <div className={`w-20 h-20 rounded-2xl border-2 overflow-hidden shadow-lg ${isLight ? 'border-white' : 'border-app-accent/30'}`}>
                                    <img src={initialMeterImg} className="w-full h-full object-cover" />
                                </div>
                                <button 
                                    onClick={() => setInitialMeterImg(null)}
                                    className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 text-white rounded-full flex items-center justify-center shadow-lg active:scale-90"
                                >
                                    <RotateCcw size={16} />
                                </button>
                            </div>

                            {/* TWO INPUTS SIDE-BY-SIDE: READING & ROOM NO */}
                            <div className="flex gap-3 w-full max-w-[90%] mb-6">
                                {/* 1. START READING INPUT (UPDATED VISUALS: Smaller, Less Round, Brighter Icons) */}
                                <div className={`flex-1 p-1.5 rounded-xl border-2 transition-all duration-300 shadow-xl ${!startMeterReading ? 'border-yellow-500 shadow-yellow-500/20 animate-pulse' : (isLight ? 'border-app-accent/50 shadow-app-accent/10' : 'border-app-accent shadow-[0_0_20px_rgba(204,243,129,0.1)]')}`}>
                                    <div className={`flex flex-col items-center justify-center p-2 rounded-lg h-full ${isLight ? 'bg-white' : 'bg-[#1E1E24]'}`}>
                                        <span className={`text-[10px] font-bold uppercase tracking-widest mb-1 flex items-center gap-1 ${isLight ? 'text-gray-400' : 'text-gray-500'}`}><Zap size={12} className="text-yellow-400 drop-shadow-md" /> Reading</span>
                                        <input
                                            ref={startReadingRef}
                                            type="number"
                                            value={startMeterReading}
                                            onChange={(e) => setStartMeterReading(e.target.value)}
                                            placeholder="0000"
                                            className={`w-full bg-transparent outline-none font-black text-center transition-all duration-200 ${getDynamicFontSize(startMeterReading)} ${isLight ? 'text-black' : 'text-white'}`}
                                            autoFocus
                                        />
                                    </div>
                                </div>

                                {/* 2. ROOM NO INPUT (UPDATED VISUALS: Smaller, Less Round, Brighter Icons) */}
                                <div className={`flex-1 p-1.5 rounded-xl border-2 transition-all duration-300 shadow-xl ${conflictTenantForModal ? 'border-red-500 shadow-red-500/30' : (isLight ? 'border-app-accent/50 shadow-app-accent/10' : 'border-app-accent shadow-[0_0_20px_rgba(204,243,129,0.1)]')}`}>
                                    <div className={`flex flex-col items-center justify-center p-2 rounded-lg h-full ${isLight ? 'bg-white' : 'bg-[#1E1E24]'}`}>
                                        <span className={`text-[10px] font-bold uppercase tracking-widest mb-1 flex items-center gap-1 ${isLight ? 'text-gray-400' : 'text-gray-500'}`}><Home size={12} className="text-blue-400 drop-shadow-md" /> Room</span>
                                        <input
                                            ref={roomInputRef}
                                            value={unitId}
                                            onChange={handleRoomChange}
                                            onKeyDown={handleKeyDown}
                                            placeholder="No"
                                            list="unit-suggestions"
                                            type="text" // CHANGED: Allows text but defaults to numeric pad on mobile
                                            inputMode="numeric" // ADDED: Shows numeric keypad with optional text fallback
                                            className={`w-full bg-transparent outline-none font-black text-center transition-all duration-200 ${getDynamicFontSize(unitId)} ${isLight ? 'text-black' : 'text-white'}`}
                                        />
                                        <datalist id="unit-suggestions">
                                            {data.units.filter(u => u.status === 'vacant').map(u => <option key={u.id} value={u.name}/>)}
                                        </datalist>
                                    </div>
                                </div>
                            </div>

                            {/* CONTINUE BUTTON - DISABLED IF READING IS EMPTY */}
                            {unitId.length > 0 && startMeterReading.length > 0 && !conflictTenantForModal && (
                                <button 
                                    onClick={handleConfirmRoom}
                                    className="px-10 py-4 bg-app-accent text-black font-black rounded-2xl shadow-glow animate-bounce-in flex items-center gap-2 active:scale-95 transition"
                                >
                                    Continue <ArrowRight size={20} strokeWidth={3} />
                                </button>
                            )}
                        </div>
                    )}
                </div>
            )}

            {isRoomConfirmed && !conflictTenantForModal && (
            <div className="space-y-4 animate-slide-up">
                <div className="flex items-center justify-between px-1 mb-2">
                    <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-app-accent flex items-center justify-center text-black shadow-sm"><Home size={16}/></div>
                        <h2 className={`font-black text-lg ${isLight ? 'text-black' : 'text-white'}`}>Room {unitId}</h2>
                    </div>
                    <button onClick={() => setIsRoomConfirmed(false)} className="text-[10px] font-bold text-blue-500 underline uppercase tracking-widest">Change Room</button>
                </div>

                <div className="flex gap-3 h-[130px]">
                    <label className={`w-[120px] h-full rounded-2xl border-2 border-dashed flex flex-col items-center justify-center gap-1 cursor-pointer transition-all relative overflow-hidden group shadow-sm shrink-0 ${isLight ? 'border-gray-300 bg-gray-50' : 'border-gray-700 bg-[#1E1E24]'}`}>
                        {profileImage ? (
                            <img src={profileImage} className="w-full h-full object-cover object-center" />
                        ) : (
                            <div className="flex flex-col items-center gap-1">
                                <div className={`w-8 h-8 rounded-full border-2 border-dashed flex items-center justify-center ${isLight ? 'border-gray-400 text-gray-400' : 'border-gray-600 text-gray-500'}`}>
                                    <User size={14} />
                                </div>
                                <span className={`text-[9px] font-bold ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>Face Photo</span>
                            </div>
                        )}
                        <input type="file" className="hidden" accept="image/*" onChange={e => handleImageUpload(e, 'profile')}/>
                        {isProfileScanning && (
                            <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center backdrop-blur-[1px]">
                                <ScanLine size={24} className="text-app-accent animate-ping mb-1"/>
                                <span className="text-[8px] font-bold text-white uppercase tracking-widest">Processing...</span>
                            </div>
                        )}
                    </label>

                    <label className={`flex-1 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer relative overflow-hidden transition-all ${isLight ? 'border-gray-300 bg-gray-50' : 'border-gray-700 bg-[#1E1E24]'}`}>
                        {idImage ? (
                            <div className="w-full h-full p-2 flex gap-2 items-center justify-center bg-black/5">
                                <div className="h-full flex-1 relative rounded-lg overflow-hidden border border-gray-300 shadow-sm">
                                    <img src={idImage} className="w-full h-full object-cover" />
                                    <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-[8px] font-bold text-center py-0.5">FRONT</div>
                                </div>
                                {idBackImage ? (
                                    <div className="h-full flex-1 relative rounded-lg overflow-hidden border border-gray-300 shadow-sm">
                                        <img src={idBackImage} className="w-full h-full object-cover" />
                                        <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-[8px] font-bold text-center py-0.5">BACK</div>
                                    </div>
                                ) : (
                                    <div className="h-full flex-1 flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-lg opacity-50">
                                        <Plus size={16} className="text-gray-400" />
                                        <span className="text-[8px] text-gray-400 font-bold">Back?</span>
                                    </div>
                                )}
                            </div>
                        ) : (
                            <div className="text-center p-4">
                                <CreditCard size={28} className={`mx-auto mb-2 ${isLight ? 'text-gray-400' : 'text-gray-500'}`} />
                                <span className={`text-[12px] font-bold uppercase block ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>National ID</span>
                                <span className="text-[9px] text-gray-500 block mt-1">(Instant Upload Mode)</span>
                            </div>
                        )}
                        <input type="file" multiple className="hidden" accept="image/*" onChange={e => handleImageUpload(e, 'nid_combo')} />
                        {isScanning && <div className="absolute inset-0 bg-black/60 flex items-center justify-center"><Loader2 className="text-app-accent animate-spin"/></div>}
                    </label>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    {/* CHANGED: Full width for Name + AutoScroll to Phone */}
                    <div className={`${inputContainer} col-span-2`}>
                        <User size={18} className="text-pink-500" />
                        <input value={name} onChange={e => setName(e.target.value)} onFocus={scrollForName} placeholder="Full Name" className={inputStyle} autoComplete="off" autoFocus={!!editingId && !focusField} />
                    </div>
                    {/* SCROLL TARGET: Phone Container */}
                    <div ref={phoneContainerRef} className={`${inputContainer} col-span-1`}>
                        <Phone size={18} className="text-cyan-500" />
                        <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} onFocus={handleAutoScroll} placeholder="Phone" className={inputStyle} />
                    </div>
                    {/* CHANGED: Swapped Advance and Rent positions */}
                    <div className={`${inputContainer} col-span-1`}>
                        <span className="text-orange-500 font-black text-lg">৳</span>
                        <input ref={advanceInputRef} type="number" inputMode="numeric" value={advance} onChange={e => setAdvance(e.target.value)} onFocus={handleScrollTop} placeholder="Advance" className={inputStyle} />
                    </div>
                    {/* SCROLL TARGET: Rent Container */}
                    <div ref={rentContainerRef} className={`${inputContainer} col-span-1`}>
                        <span className="text-green-500 font-black text-lg">৳</span>
                        <input type="number" value={rentAmount} onChange={e => setRentAmount(e.target.value)} onFocus={handleAutoScroll} placeholder="Rent" className={inputStyle} />
                    </div>
                    {/* UPDATED: Unit Price scrolls to Garbage */}
                    <div className={`${inputContainer} col-span-1`}>
                        <span className="text-yellow-600 font-black text-lg">@</span>
                        <div className="flex-1 flex flex-col justify-center">
                             <span className={`text-[10px] font-bold block uppercase tracking-wide ${isLight ? 'text-gray-400' : 'text-gray-500'}`}>Unit Price</span>
                             <input type="number" value={unitPrice} onChange={e => setUnitPrice(e.target.value)} onFocus={scrollForUnitPrice} placeholder="" className={`w-full bg-transparent outline-none font-black text-lg ${isLight ? 'text-black' : 'text-white'}`} />
                        </div>
                    </div>
                    {/* SCROLL TARGET: Garbage Container */}
                    <div ref={garbageContainerRef} className={`${inputContainer} col-span-1`}>
                        <Trash size={18} className="text-red-500" />
                        <input type="number" value={garbageBill} onChange={e => setGarbageBill(e.target.value)} onFocus={handleFooterScroll} placeholder="Garbage Bill" className={inputStyle} />
                    </div>
                    {/* UPDATED: Total Extra scrolls to Extra Charges Section */}
                    <div className={`${inputContainer} col-span-1`}>
                        <FileText size={18} className="text-teal-500" />
                        <div className="flex-1 flex flex-col justify-center">
                            <span className={`text-[10px] font-bold block uppercase tracking-wide ${isLight ? 'text-gray-400' : 'text-gray-500'}`}>Total Extra</span>
                            <input type="number" value={extraCharge} onChange={e => setExtraCharge(e.target.value)} onFocus={scrollForTotalExtra} placeholder="0" className={`w-full bg-transparent outline-none font-black text-lg ${isLight ? 'text-black' : 'text-white'}`} />
                        </div>
                    </div>
                </div>

                {/* SCROLL TARGET: Extra Charges Section */}
                <div ref={extraChargesSectionRef} className={`rounded-2xl p-4 border ${isLight ? 'bg-gray-100 border-gray-200' : 'bg-[#1E1E24] border-gray-800'}`}>
                    <div className="flex justify-between items-center mb-3">
                        <span className={`text-xs font-bold uppercase tracking-widest ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>EXTRA CHARGES</span>
                        <button onClick={() => setShowFieldModal(true)} className="w-8 h-8 rounded-full bg-app-accent flex items-center justify-center text-black active:scale-90 transition shadow-sm"><Plus size={18} /></button>
                    </div>
                    {customFields.length === 0 ? (
                        <p className="text-xs text-gray-500 italic text-center py-2">No extra charges added</p>
                    ) : (
                        <div className="grid grid-cols-3 gap-2">
                            {customFields.map(f => (
                                <div key={f.id} className={`relative flex flex-col items-center justify-center p-2 rounded-xl border ${isLight ? 'bg-white border-gray-200 shadow-sm' : 'bg-black/20 border-white/5'}`}>
                                    <button onClick={() => removeCustomField(f.id)} className="absolute top-1 right-1 text-red-500 p-0.5 rounded-full active:bg-red-500/10"><X size={10}/></button>
                                    <span className={`text-[10px] font-bold uppercase truncate w-full text-center ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>{f.label}</span>
                                    <span className="text-sm font-black text-app-accent mt-0.5">৳{f.amount}</span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                <div ref={footerRef} className="mt-4 flex gap-4">
                    <button onClick={handleBack} className={`flex-1 py-4 rounded-2xl font-bold text-sm border ${isLight ? 'bg-white border-red-200 text-red-500 shadow-sm' : 'bg-[#1E1E24] border-red-900/50 text-red-500'}`}>Cancel</button>
                    <button onClick={handleSave} className="flex-[2] py-4 rounded-2xl font-bold text-sm bg-app-accent text-black shadow-[0_0_20px_rgba(204,243,129,0.3)] flex items-center justify-center gap-2 active:scale-95 transition"><FileText size={18} />{editingId ? 'Update Tenant' : 'Save Tenant'}</button>
                </div>
            </div>
            )}
         </div>
      </div>

      {conflictTenantForModal && (
          <div className="fixed inset-0 z-[6000] bg-black/90 backdrop-blur-md flex items-center justify-center p-6 animate-fade-in">
              <div className={`w-full max-w-[280px] rounded-[32px] overflow-hidden border-2 shadow-2xl relative ${isLight ? 'bg-white border-red-200' : 'bg-[#1a0505] border-red-500'}`}>
                  <div className="bg-red-500 p-5 flex flex-col items-center text-white text-center">
                      <AlertTriangle size={40} className="mb-2 animate-bounce" />
                      <h2 className="text-xl font-black uppercase tracking-widest">Warning</h2>
                      <p className="text-sm font-bold mt-1">Room {unitId}: {conflictTenantForModal.name}</p>
                  </div>
                  <div className="p-4">
                      <div className="flex flex-col gap-3">
                          <button onClick={handleArchiveConflict} className="w-full py-3 bg-red-500 text-white font-bold rounded-xl shadow-lg active:scale-95 transition flex items-center justify-center gap-2"><Archive size={18} /> Archive Old</button>
                          <button onClick={handleCancelConflict} className={`w-full py-3 font-bold rounded-xl active:scale-95 transition ${isLight ? 'bg-gray-100 text-gray-600' : 'bg-white/10 text-gray-400'}`}>Cancel</button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      {showFieldModal && (
          <div className="fixed inset-0 z-[6000] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 pb-safe" onClick={() => setShowFieldModal(false)}>
              <div className={`w-full max-w-xs p-6 rounded-[32px] shadow-2xl animate-slide-up mb-safe ${isLight ? 'bg-white' : 'bg-[#1E1E24] border border-gray-700'}`} onClick={e => e.stopPropagation()}>
                  <h3 className={`font-bold mb-4 ${isLight ? 'text-black' : 'text-white'}`}>Add Extra Charge</h3>
                  <input value={newFieldLabel} onChange={e => setNewFieldLabel(e.target.value)} placeholder="Label (e.g. WiFi)" autoFocus className={`w-full p-4 rounded-2xl mb-3 outline-none font-bold ${isLight ? 'bg-gray-100 text-black' : 'bg-black/30 text-white border border-white/10'}`} />
                  <input type="number" value={newFieldAmount} onChange={e => setNewFieldAmount(e.target.value)} placeholder="Amount" className={`w-full p-4 rounded-2xl mb-4 outline-none font-bold ${isLight ? 'bg-gray-100 text-black' : 'bg-black/30 text-white border border-white/10'}`} />
                  <button onClick={addCustomField} className="w-full py-4 bg-app-accent text-black font-bold rounded-2xl active:scale-95 transition">Add Charge</button>
              </div>
          </div>
      )}
    </div>
  );
};

export default RentForm;