import React, { useState } from 'react';
import { AppData, Todo, Page } from '../types';
import { Plus, Check, Trash2, CheckCircle, Circle, Share2, AlertTriangle, X, ChevronLeft } from 'lucide-react';

interface Props {
  data: AppData;
  setData: (data: AppData) => void;
  onOpenSettings: () => void;
  setPage: (page: Page) => void;
}

const Todos: React.FC<Props> = ({ data, setData, onOpenSettings, setPage }) => {
  const [newTodo, setNewTodo] = useState('');
  const [selectedTodoId, setSelectedTodoId] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [viewingTodo, setViewingTodo] = useState<Todo | null>(null); // State for popup
  const isLight = data.settings.theme === 'light';

  const addTodo = () => {
      if (!newTodo.trim()) return;
      const todo: Todo = {
          id: Date.now().toString(),
          text: newTodo,
          completed: false,
          color: 'bg-blue-500'
      };
      setData({ ...data, todos: [todo, ...data.todos] });
      setNewTodo('');
  };

  const toggleTodo = (id: string) => {
      const updated = data.todos.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
      setData({ ...data, todos: updated });
  };

  const handleDeleteRequest = (id: string) => {
      setDeleteConfirmId(id);
  };

  const confirmDelete = () => {
      if (deleteConfirmId) {
          const updated = data.todos.filter(t => t.id !== deleteConfirmId);
          setData({ ...data, todos: updated });
          setDeleteConfirmId(null);
          if (selectedTodoId === deleteConfirmId) setSelectedTodoId(null);
      }
  };

  const handleShare = (text: string) => {
      if (navigator.share) {
          navigator.share({
              title: 'My Task',
              text: text
          }).catch((err) => {
              if (err.name !== 'AbortError') {
                  console.error('Share failed:', err);
              }
          });
      } else {
          // Fallback copy to clipboard
          navigator.clipboard.writeText(text);
          alert('Text copied to clipboard');
      }
  };

  return (
    <div className={`h-screen flex flex-col animate-fade-in relative ${isLight ? 'bg-gray-50' : 'bg-[#0F1014]'}`}>
      {/* CUSTOM HEADER WITH BACK BUTTON */}
      <div className={`flex-none z-50 sticky top-0 left-0 w-full h-[70px] flex items-center justify-between px-5 transition-all duration-300 border-b ${isLight ? 'bg-white/80 backdrop-blur-md border-gray-200' : 'bg-black/30 backdrop-blur-md border-white/5'}`}>
          <button 
            onClick={() => setPage('tools')}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all active:scale-90 ${isLight ? 'bg-white text-gray-600 shadow-sm border border-gray-100 hover:bg-gray-50' : 'bg-white/10 text-white hover:bg-white/20'}`}
          >
              <ChevronLeft size={24} />
          </button>
          <h1 className={`text-xl font-black tracking-tight ${isLight ? 'text-black' : 'text-white'}`}>Tasks</h1>
          <div className="w-10"></div> {/* Spacer for alignment */}
      </div>
      
      <div className="flex-1 overflow-y-auto p-5 pb-40">
          {/* Input */}
          <div className={`flex gap-2 mb-6 p-2 rounded-2xl border ${isLight ? 'bg-white border-gray-200' : 'bg-[#18191F] border-gray-800'}`}>
              <input 
                  value={newTodo}
                  onChange={e => setNewTodo(e.target.value)}
                  placeholder="Add a new task..."
                  className={`flex-1 bg-transparent px-3 outline-none font-medium ${isLight ? 'text-black' : 'text-white'}`}
                  onKeyDown={e => e.key === 'Enter' && addTodo()}
              />
              <button onClick={addTodo} className="p-3 bg-app-accent rounded-xl text-black active:scale-90 transition">
                  <Plus size={20} />
              </button>
          </div>

          {/* List */}
          <div className="space-y-3">
              {data.todos.length === 0 && (
                  <p className="text-center text-gray-500 text-sm mt-10">No tasks pending. Great job!</p>
              )}
              {data.todos.map(todo => {
                  const isSelected = selectedTodoId === todo.id;
                  return (
                    <div 
                        key={todo.id} 
                        onClick={() => setSelectedTodoId(isSelected ? null : todo.id)}
                        className={`group flex items-center justify-between p-4 rounded-2xl border transition-all cursor-pointer ${
                            todo.completed 
                                ? (isLight ? 'bg-gray-100 border-gray-200 opacity-60' : 'bg-gray-900 border-gray-800 opacity-50') 
                                : (isLight ? `bg-white border-gray-200 ${isSelected ? 'shadow-md border-blue-300' : 'shadow-sm'}` : `bg-[#18191F] border-gray-800 ${isSelected ? 'border-gray-600' : ''}`)
                        }`}
                    >
                        <div className="flex items-center gap-3 overflow-hidden flex-1">
                            <button 
                                onClick={(e) => { e.stopPropagation(); toggleTodo(todo.id); }} 
                                className={`shrink-0 transition-colors ${todo.completed ? 'text-green-500' : 'text-gray-400 hover:text-app-accent'}`}
                            >
                                {todo.completed ? <CheckCircle size={22} className="fill-green-500/10"/> : <Circle size={22} />}
                            </button>
                            <span 
                                onClick={(e) => { e.stopPropagation(); setViewingTodo(todo); }}
                                className={`font-medium truncate flex-1 ${todo.completed ? 'line-through text-gray-500' : (isLight ? 'text-black' : 'text-white')}`}
                            >
                                {todo.text}
                            </span>
                        </div>
                        
                        {/* Action Buttons (Only Visible When Selected) */}
                        {isSelected && (
                            <div className="flex items-center ml-2 animate-slide-up shrink-0">
                                <button 
                                    onClick={(e) => { e.stopPropagation(); handleShare(todo.text); }}
                                    className={`p-2 rounded-xl active:scale-90 transition ${isLight ? 'bg-blue-50 text-blue-500' : 'bg-blue-500/10 text-blue-400'}`}
                                >
                                    <Share2 size={18} />
                                </button>
                                
                                {/* Gap between buttons */}
                                <div className="w-3"></div>

                                <button 
                                    onClick={(e) => { e.stopPropagation(); handleDeleteRequest(todo.id); }}
                                    className={`p-2 rounded-xl active:scale-90 transition ${isLight ? 'bg-red-50 text-red-500' : 'bg-red-500/10 text-red-400'}`}
                                >
                                    <Trash2 size={18} />
                                </button>
                            </div>
                        )}
                    </div>
                  );
              })}
          </div>
      </div>

      {/* Task Details Popup Modal */}
      {viewingTodo && (
          <div className="fixed inset-0 z-[6000] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in pb-safe" onClick={() => setViewingTodo(null)}>
              <div className={`w-full max-w-sm rounded-[24px] p-6 shadow-2xl relative animate-slide-up max-h-[60vh] mb-24 flex flex-col ${isLight ? 'bg-white' : 'bg-[#18191F] border border-gray-700'}`} onClick={e => e.stopPropagation()}>
                  <div className="flex justify-between items-start mb-4 shrink-0">
                      <h3 className={`text-lg font-bold ${isLight ? 'text-black' : 'text-white'}`}>Task Details</h3>
                      <button onClick={() => setViewingTodo(null)} className={`p-1.5 rounded-full transition ${isLight ? 'bg-gray-100 hover:bg-gray-200 text-black' : 'bg-white/10 hover:bg-white/20 text-white'}`}>
                          <X size={20} />
                      </button>
                  </div>
                  <div className={`flex-1 overflow-y-auto min-h-[60px] text-base leading-relaxed whitespace-pre-wrap break-words pr-2 ${isLight ? 'text-gray-800' : 'text-gray-200'}`}>
                      {viewingTodo.text}
                  </div>
                  <div className={`mt-6 pt-4 border-t flex justify-end gap-3 shrink-0 ${isLight ? 'border-gray-100' : 'border-gray-800'}`}>
                      <button onClick={() => { handleShare(viewingTodo.text); }} className={`px-4 py-2 rounded-xl font-bold text-sm flex items-center gap-2 ${isLight ? 'bg-blue-50 text-blue-600' : 'bg-blue-500/20 text-blue-400'}`}>
                          <Share2 size={16} /> Copy
                      </button>
                      <button onClick={() => { setViewingTodo(null); handleDeleteRequest(viewingTodo.id); }} className={`px-4 py-2 rounded-xl font-bold text-sm flex items-center gap-2 ${isLight ? 'bg-red-50 text-red-600' : 'bg-red-500/20 text-red-400'}`}>
                          <Trash2 size={16} /> Delete
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Custom YES/NO Delete Dialog */}
      {deleteConfirmId && (
          <div className="fixed inset-0 z-[6000] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in" onClick={() => setDeleteConfirmId(null)}>
              <div className={`w-full max-w-xs p-6 rounded-[28px] shadow-2xl animate-scale-in text-center ${isLight ? 'bg-white' : 'bg-[#1E1E24] border border-gray-700'}`} onClick={e => e.stopPropagation()}>
                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Trash2 size={24} className="text-red-500" />
                  </div>
                  <h3 className={`text-lg font-bold mb-2 ${isLight ? 'text-black' : 'text-white'}`}>Delete Task?</h3>
                  <p className="text-sm text-gray-500 mb-6">This cannot be undone.</p>
                  <div className="flex gap-3">
                      <button 
                          onClick={() => setDeleteConfirmId(null)}
                          className={`flex-1 py-3 rounded-xl font-bold text-sm ${isLight ? 'bg-gray-100 text-gray-700' : 'bg-white/10 text-gray-300'}`}
                      >
                          No
                      </button>
                      <button 
                          onClick={confirmDelete}
                          className="flex-1 py-3 rounded-xl font-bold text-sm bg-red-500 text-white shadow-lg shadow-red-500/30"
                      >
                          Yes
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default Todos;