import React, { useState, useMemo } from 'react';
import { AppData, Expense, Bill } from '../types';
import TopBar from '../components/TopBar';
import FixChartWrapper from '../components/FixChartWrapper';
import { triggerNavEmotion } from './services/notificationService';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { 
  Plus, X, Trash2, TrendingDown, TrendingUp, 
  Hammer, PaintBucket, Zap, User, HelpCircle, 
  DollarSign, Calendar, ChevronLeft, ChevronRight, ChevronDown,
  FileText, CheckCircle2, Download, Share2, Wallet,
  Info, ArrowDownLeft, ArrowUpRight, AlertCircle, ShieldCheck, Check,
  Receipt, Printer, Clock
} from 'lucide-react';

interface Props {
  data: AppData;
  setData: (data: AppData) => void;
  onOpenSettings: () => void;
}

const CATEGORIES = [
    { id: 'Repair', label: 'Repair', icon: Hammer, color: 'text-orange-500', bg: 'bg-orange-500/10', hex: '#F97316' },
    { id: 'Paint', label: 'Paint', icon: PaintBucket, color: 'text-purple-500', bg: 'bg-purple-500/10', hex: '#A855F7' },
    { id: 'Utility', label: 'Utility', icon: Zap, color: 'text-yellow-500', bg: 'bg-yellow-500/10', hex: '#EAB308' },
    { id: 'Salary', label: 'Salary', icon: User, color: 'text-blue-500', bg: 'bg-blue-500/10', hex: '#3B82F6' },
    { id: 'Other', label: 'Other', icon: HelpCircle, color: 'text-gray-500', bg: 'bg-gray-500/10', hex: '#6B7280' },
];

const getLocalDateString = () => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const Expenses: React.FC<Props> = ({ data, setData, onOpenSettings }) => {
  const isLight = data.settings.theme === 'light';
  
  const [activeTab, setActiveTab] = useState<'income' | 'expense'>('income');
  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<Expense['category']>('Repair');
  const [date, setDate] = useState(getLocalDateString());
  const [viewDate, setViewDate] = useState(new Date()); 
  const [selectedReceipt, setSelectedReceipt] = useState<Bill | null>(null);
  const [showYearSelector, setShowYearSelector] = useState(false);
  const [tempYear, setTempYear] = useState(viewDate.getFullYear().toString());

  const expenses = data.expenses || [];
  const bills = data.bills || [];

  const monthlyIncome = useMemo(() => {
      const targetMonth = viewDate.getMonth();
      const targetYear = viewDate.getFullYear();
      return bills.filter(b => {
          const bDate = new Date(b.date);
          return b.isPaid && bDate.getMonth() === targetMonth && bDate.getFullYear() === targetYear;
      }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [bills, viewDate]);

  const totalIncomeThisMonth = monthlyIncome.reduce((acc, curr) => acc + curr.paidAmount, 0);
  const totalExpenseAllTime = expenses.reduce((acc, curr) => acc + curr.amount, 0);

  // --- DYNAMIC FONT SCALING FOR LARGE NUMBERS ---
  const getScaleClass = (amount: number) => {
      const txt = amount.toLocaleString();
      const len = txt.length;
      if (len > 12) return 'text-xl';
      if (len > 9) return 'text-2xl';
      if (len > 7) return 'text-3xl';
      return 'text-4xl';
  };

  const chartData = useMemo(() => {
      const grouped = expenses.reduce((acc, curr) => {
          acc[curr.category] = (acc[curr.category] || 0) + curr.amount;
          return acc;
      }, {} as Record<string, number>);
      return Object.keys(grouped).map(key => {
          const catDef = CATEGORIES.find(c => c.id === key);
          return { name: key, value: grouped[key], color: catDef ? catDef.hex : '#8884d8' };
      }).filter(i => i.value > 0);
  }, [expenses]);

  const handleAddExpense = () => {
      const safeAmount = Number(amount);
      if (!title || !amount || isNaN(safeAmount)) return;
      const newExpense: Expense = { id: Date.now().toString(), title, amount: safeAmount, category, date };
      setData({ ...data, expenses: [newExpense, ...expenses] });
      triggerNavEmotion('sad');
      setTitle(''); setAmount(''); setShowExpenseModal(false);
  };

  const deleteExpense = (id: string) => {
      if(confirm("Delete this expense record?")) {
          setData({ ...data, expenses: expenses.filter(e => e.id !== id) });
      }
  };

  const changeMonth = (dir: number) => {
      const newDate = new Date(viewDate);
      newDate.setMonth(newDate.getMonth() + dir);
      setViewDate(newDate);
  };

  const handleYearConfirm = () => {
      const yr = parseInt(tempYear);
      if (!isNaN(yr) && yr > 1900 && yr < 2100) {
          const newDate = new Date(viewDate);
          newDate.setFullYear(yr);
          setViewDate(newDate);
          setShowYearSelector(false);
      } else {
          alert("Please enter a valid year (e.g. 2025)");
      }
  };

  const getActualBillData = (receipt: Bill) => {
      // Logic to find the original generated bill corresponding to a payment
      if (receipt.month !== 'Payment' && receipt.currMeter > 0) return receipt;
      // Try to find the latest unpaid or just paid bill for this tenant
      // We sort by date descending to get the latest
      const tenantBills = data.bills
          .filter(b => b.tenantId === receipt.tenantId && b.month !== 'Payment' && b.currMeter > 0)
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
          
      return tenantBills[0] || receipt;
  };

  const handleShareReceipt = () => {
      if (!selectedReceipt) return;
      const t = data.tenants.find(x => x.id === selectedReceipt.tenantId);
      const realBill = getActualBillData(selectedReceipt);
      const unitsUsed = (realBill.currMeter || 0) - (realBill.prevMeter || 0);
      
      let msg = `*PAYMENT RECEIPT*\n`;
      msg += `--------------------------\n`;
      msg += `ID: ${selectedReceipt.id.slice(-8)}\n`;
      msg += `Paid By: ${t?.name || 'Unknown'}\n`;
      msg += `Room No: ${t?.unitId || 'N/A'}\n`;
      msg += `Date: ${new Date(selectedReceipt.date).toLocaleDateString()}\n\n`;
      
      // Calculate breakdown if it's a payment receipt linked to a real bill
      if (realBill.id !== selectedReceipt.id) {
          msg += `Rent: ${realBill.rentAmount}\n`;
          if (t?.garbageBill) msg += `Garbage bill: ${t.garbageBill}\n`;
          t?.customFields?.forEach(cf => { msg += `${cf.label} bill: ${cf.amount}\n`; });
          msg += `\n*ELECTRICITY*\n`;
          msg += `Reading: ${realBill.prevMeter} -> ${realBill.currMeter}\n`;
          msg += `Usage: ${unitsUsed} Units @ ৳${realBill.unitPrice || data.settings.unitPrice}\n`;
          msg += `Bill: ৳${realBill.electricityBill}\n`;
          msg += `--------------------------\n`;
      }
      
      // Calculate Net Total if needed for clarity
      const totalBill = selectedReceipt.paidAmount + (selectedReceipt.advanceAdjustment || 0);
      
      if (selectedReceipt.advanceAdjustment) {
          msg += `Total Bill: ৳${totalBill}\n`;
          msg += `Less: Advance Adjusted: -৳${selectedReceipt.advanceAdjustment}\n`;
      }
      
      msg += `*NET CASH PAID: ৳${selectedReceipt.paidAmount}*\n`;
      
      if (t && t.due > 0) {
          msg += `\nRemaining Due: ৳${t.due}\n`;
      } else if (t) {
          msg += `\nStatus: All Dues Clear ✅\n`;
      }
      msg += `--------------------------\n`;
      
      if (navigator.share) navigator.share({ title: 'Rent Receipt', text: msg }).catch(() => {});
      else window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`);
  };

  const tabActive = isLight ? "bg-white text-black shadow-md" : "bg-[#2A2B35] text-white shadow-glow border border-white/10";
  const tabInactive = isLight ? "text-gray-500 hover:bg-gray-200" : "text-gray-500 hover:bg-white/5";
  const listCard = isLight ? "bg-white border border-gray-100 shadow-sm" : "bg-[#1E1E24] border border-white/5";

  // Helper for receipt Modal
  const renderReceiptModal = () => {
      if (!selectedReceipt) return null;
      const tenant = data.tenants.find(t => t.id === selectedReceipt.tenantId);
      const realBill = getActualBillData(selectedReceipt);
      const unitsUsed = (realBill.currMeter || 0) - (realBill.prevMeter || 0);
      
      const knownTotal = (realBill.rentAmount || 0) + (realBill.electricityBill || 0);
      const otherCharges = Math.max(0, (realBill.totalAmount || 0) - knownTotal);
      
      // Calculate Total Amount before adjustment
      const totalAmount = selectedReceipt.paidAmount + (selectedReceipt.advanceAdjustment || 0);

      return (
          <div className="fixed inset-0 z-[6000] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in pb-safe" onClick={() => setSelectedReceipt(null)}>
              <div className={`w-full max-w-sm rounded-[32px] overflow-hidden relative shadow-2xl animate-slide-up ${isLight ? 'bg-white' : 'bg-[#121214] border border-gray-800'}`} onClick={e => e.stopPropagation()}>
                  
                  {/* Header */}
                  <div className={`p-5 border-b flex justify-between items-center ${isLight ? 'bg-gray-50 border-gray-200' : 'bg-[#1a1a1f] border-gray-800'}`}>
                      <div className="flex items-center gap-2">
                          <div className="bg-blue-500/10 p-2 rounded-full text-blue-500"><Receipt size={20}/></div>
                          <div>
                              <h3 className={`font-black text-lg ${isLight ? 'text-black' : 'text-white'}`}>Payment Receipt</h3>
                              <p className="text-[10px] text-gray-500 font-bold">{new Date(selectedReceipt.date).toDateString()}</p>
                          </div>
                      </div>
                      <button onClick={() => setSelectedReceipt(null)} className="p-2 bg-gray-500/10 rounded-full hover:bg-gray-500/20"><X size={20} className="text-gray-500"/></button>
                  </div>

                  {/* Body */}
                  <div className="p-6 space-y-4">
                      {/* Tenant Info */}
                      <div className="flex items-center gap-3 mb-2">
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg text-white ${isLight ? 'bg-blue-500' : 'bg-gray-700'}`}>
                              {tenant?.name?.[0] || 'U'}
                          </div>
                          <div>
                              <h4 className={`font-bold ${isLight ? 'text-black' : 'text-white'}`}>{tenant?.name || 'Unknown'}</h4>
                              <p className="text-xs text-gray-500">Room: <span className="font-bold text-app-accent">{tenant?.unitId || 'N/A'}</span></p>
                          </div>
                      </div>

                      {/* Bill Breakdown Table */}
                      <div className={`rounded-2xl p-4 border space-y-2 ${isLight ? 'bg-gray-50 border-gray-200' : 'bg-white/5 border-white/10'}`}>
                          <div className="flex justify-between items-center text-xs">
                              <span className="text-gray-500">Rent</span>
                              <span className={`font-bold ${isLight ? 'text-gray-800' : 'text-gray-300'}`}>৳{realBill.rentAmount}</span>
                          </div>
                          <div className="flex justify-between items-center text-xs">
                              <span className="text-gray-500">Electricity <span className="text-[9px] opacity-70">({unitsUsed}u x {realBill.unitPrice})</span></span>
                              <span className={`font-bold ${isLight ? 'text-gray-800' : 'text-gray-300'}`}>৳{realBill.electricityBill}</span>
                          </div>
                          {otherCharges > 0 && (
                              <div className="flex justify-between items-center text-xs">
                                  <span className="text-gray-500">Service/Other</span>
                                  <span className={`font-bold ${isLight ? 'text-gray-800' : 'text-gray-300'}`}>৳{otherCharges}</span>
                              </div>
                          )}
                          <div className="border-t border-dashed my-2 border-gray-500/30"></div>
                          
                          {/* NEW: Explicit Total */}
                          <div className="flex justify-between items-center mb-1">
                              <span className="font-bold text-sm text-gray-500">Total Payable</span>
                              <span className={`font-black text-lg ${isLight ? 'text-black' : 'text-white'}`}>৳{totalAmount}</span>
                          </div>

                          {/* NEW: Advance Deduction Logic - Clearly Explained */}
                          {selectedReceipt.advanceAdjustment ? (
                              <div className="bg-orange-500/10 p-2 rounded-lg flex justify-between items-center border border-orange-500/20">
                                  <div className="flex items-center gap-1 text-orange-600">
                                      <span className="text-xs font-bold">(-) Less: Advance</span>
                                  </div>
                                  <span className="text-sm font-black text-orange-600">-৳{selectedReceipt.advanceAdjustment}</span>
                              </div>
                          ) : null}
                          
                          <div className="border-t border-dashed my-2 border-gray-500/30"></div>

                          {/* Net Payment */}
                          <div className="flex justify-between items-center">
                              <span className="font-black text-sm text-green-500 uppercase tracking-wider">Net Cash Received</span>
                              <span className="font-black text-xl text-green-500">৳{selectedReceipt.paidAmount}</span>
                          </div>

                      </div>

                      {/* Footer Info */}
                      <div className="text-center">
                          {tenant && tenant.due > 0 ? (
                              <p className="text-xs text-red-500 font-bold bg-red-500/10 py-1 px-3 rounded-full inline-block">Current Due: ৳{tenant.due}</p>
                          ) : (
                              <p className="text-xs text-green-500 font-bold bg-green-500/10 py-1 px-3 rounded-full inline-block flex items-center gap-1"><CheckCircle2 size={12}/> All Clear</p>
                          )}
                      </div>
                  </div>

                  {/* Actions */}
                  <div className={`p-4 border-t flex gap-3 ${isLight ? 'bg-gray-50 border-gray-200' : 'bg-[#1a1a1f] border-gray-800'}`}>
                      <button onClick={handleShareReceipt} className="flex-1 py-3 bg-blue-500 hover:bg-blue-600 text-white font-bold rounded-xl active:scale-95 transition flex items-center justify-center gap-2">
                          <Share2 size={18}/> Share
                      </button>
                      <button onClick={() => setSelectedReceipt(null)} className={`flex-1 py-3 font-bold rounded-xl active:scale-95 transition border ${isLight ? 'bg-white border-gray-300 text-gray-700' : 'bg-white/5 border-white/10 text-white'}`}>
                          Close
                      </button>
                  </div>
              </div>
          </div>
      );
  };

  return (
    <div className={`h-screen flex flex-col animate-fade-in ${isLight ? 'bg-app-lightBg' : 'bg-app-bg'}`}>
        <div className="flex-none z-50">
            <TopBar 
                title={<><span className={isLight ? 'text-black' : 'text-white'}>Finance</span><span className="text-blue-500">Manager</span></>} 
                data={data} 
                setData={setData} 
                onOpenSettings={onOpenSettings} 
            />
        </div>

        <div className="flex-1 overflow-y-auto p-5 pb-32">
            <div className={`flex p-1.5 rounded-2xl mb-6 ${isLight ? 'bg-gray-200' : 'bg-black/40 border border-white/5'}`}>
                <button onClick={() => setActiveTab('income')} className={`flex-1 py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all ${activeTab === 'income' ? tabActive : tabInactive}`}>
                    <TrendingUp size={16} className={activeTab === 'income' ? 'text-green-500' : ''} /> Income
                </button>
                <button onClick={() => setActiveTab('expense')} className={`flex-1 py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all ${activeTab === 'expense' ? tabActive : tabInactive}`}>
                    <TrendingDown size={16} className={activeTab === 'expense' ? 'text-red-500' : ''} /> Expense
                </button>
            </div>

            {activeTab === 'income' && (
                <div className="animate-slide-up space-y-5">
                    <div className="flex items-center justify-between px-2">
                        <button onClick={() => changeMonth(-1)} className={`p-2 rounded-full ${isLight ? 'bg-white shadow-sm' : 'bg-white/10'}`}><ChevronLeft size={20}/></button>
                        <div 
                            className="text-center cursor-pointer active:scale-95 transition-transform group" 
                            onClick={() => { setTempYear(viewDate.getFullYear().toString()); setShowYearSelector(true); }}
                        >
                            <h2 className={`text-lg font-black flex items-center justify-center gap-1 ${isLight ? 'text-black' : 'text-white'}`}>
                                {viewDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
                                <ChevronDown size={14} className="opacity-40 group-hover:opacity-100" />
                            </h2>
                            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest underline decoration-dotted decoration-gray-400">Collection History</p>
                        </div>
                        <button onClick={() => changeMonth(1)} className={`p-2 rounded-full ${isLight ? 'bg-white shadow-sm' : 'bg-white/10'}`}><ChevronRight size={20}/></button>
                    </div>

                    <div className={`p-5 rounded-[24px] relative overflow-hidden ${isLight ? 'bg-gradient-to-br from-emerald-400 to-teal-500 shadow-xl shadow-emerald-500/20' : 'bg-[#051a05] border border-green-500/30'}`}>
                        <div className="absolute top-0 right-0 p-4 opacity-20"><Wallet size={80} className="text-white"/></div>
                        <p className={`text-sm font-bold uppercase tracking-widest mb-1 ${isLight ? 'text-white/80' : 'text-green-400'}`}>Total Collected</p>
                        <h2 className={`${getScaleClass(totalIncomeThisMonth)} font-black text-white transition-all duration-300`}>৳{totalIncomeThisMonth.toLocaleString()}</h2>
                        <div className="mt-2 text-[10px] font-bold text-white/70 bg-black/10 w-max px-2 py-0.5 rounded-lg backdrop-blur-sm">{monthlyIncome.length} Transactions</div>
                    </div>

                    <div className="space-y-3">
                        {monthlyIncome.length === 0 ? (
                            <div className="text-center py-10 opacity-40">
                                <FileText size={40} className="mx-auto mb-2 text-gray-500"/>
                                <p className="text-sm">No collections in this month.</p>
                            </div>
                        ) : (
                            monthlyIncome.map(bill => {
                                const tenant = data.tenants.find(t => t.id === bill.tenantId);
                                const hasDue = (tenant?.due || 0) > 0;
                                return (
                                    <div key={bill.id} onClick={() => setSelectedReceipt(bill)} className={`flex items-center justify-between p-4 rounded-2xl border transition-all active:scale-95 cursor-pointer ${listCard}`}>
                                        <div className="flex items-center gap-4">
                                            <div className="w-10 h-10 rounded-full bg-green-500 text-white flex items-center justify-center text-xs font-bold shadow-md">{new Date(bill.date).getDate()}</div>
                                            <div>
                                                <h4 className={`font-bold text-sm ${isLight ? 'text-black' : 'text-white'}`}>{tenant?.name || 'Unknown'}</h4>
                                                <div className="text-[10px] text-gray-500 font-medium flex items-center gap-1 mt-0.5">
                                                    <span className={`font-black text-xs px-1.5 py-0.5 rounded ${isLight ? 'bg-blue-100 text-blue-600' : 'bg-app-accent/20 text-app-accent'}`}>
                                                        Room {tenant?.unitId}
                                                    </span>
                                                    <span className={hasDue ? "text-red-500 font-bold" : "text-green-500 font-bold"}>
                                                        • {hasDue ? `Due ৳${tenant?.due}` : 'Paid'}
                                                    </span>
                                                </div>
                                                {/* ADDED: PAYMENT DATE DISPLAY */}
                                                <div className={`text-[9px] font-bold mt-1.5 flex items-center gap-1.5 px-2 py-0.5 rounded-md w-max ${isLight ? 'bg-gray-100 text-gray-500' : 'bg-white/5 text-gray-400'}`}>
                                                    <Clock size={10} /> 
                                                    {new Date(bill.date).toLocaleDateString()}
                                                </div>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <span className="block font-black text-green-500">+৳{bill.paidAmount}</span>
                                            <span className="text-[9px] text-blue-500 font-bold underline decoration-dotted">View Details</span>
                                        </div>
                                    </div>
                                );
                            })
                        )}
                    </div>
                </div>
            )}

            {activeTab === 'expense' && (
                <div className="animate-slide-up space-y-5">
                    <div className={`p-5 rounded-[24px] border relative overflow-hidden ${isLight ? 'bg-white border-gray-100 shadow-xl' : 'bg-[#18191F] border-white/5'}`}>
                        <div className="flex justify-between items-start mb-4">
                            <div>
                                <p className={`text-[10px] font-bold uppercase tracking-widest ${isLight ? 'text-gray-400' : 'text-gray-500'}`}>Total Expenses</p>
                                <h2 className={`${getScaleClass(totalExpenseAllTime)} font-black text-red-500 transition-all duration-300`}>৳{totalExpenseAllTime.toLocaleString()}</h2>
                            </div>
                            <button onClick={() => setShowExpenseModal(true)} className="p-2.5 bg-red-500 text-white rounded-xl shadow-lg active:scale-95 transition"><Plus size={20} /></button>
                        </div>
                        {chartData.length > 0 ? (
                            <div className="flex items-center justify-between">
                                <div className="w-[120px] h-[120px] relative">
                                    <FixChartWrapper height={120}>
                                        <ResponsiveContainer width="100%" height="100%">
                                            <PieChart>
                                                <Pie data={chartData} innerRadius={40} outerRadius={55} paddingAngle={5} dataKey="value" stroke="none">
                                                    {chartData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                                                </Pie>
                                                <Tooltip contentStyle={{ borderRadius: '12px', background: isLight ? '#fff' : '#333', border: 'none' }} />
                                            </PieChart>
                                        </ResponsiveContainer>
                                    </FixChartWrapper>
                                </div>
                                <div className="flex-1 pl-4 grid grid-cols-2 gap-2">
                                    {chartData.map(d => (
                                        <div key={d.name} className="flex items-center gap-1.5">
                                            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: d.color }}></div>
                                            <div className="flex flex-col"><span className={`text-[9px] font-bold ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>{d.name}</span><span className={`text-[10px] font-black ${isLight ? 'text-black' : 'text-white'}`}>৳{d.value}</span></div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ) : <div className="text-center py-6 text-xs text-gray-400 font-bold border-t border-dashed border-gray-700 mt-2 pt-4">No expenses recorded.</div>}
                    </div>
                    <div className="space-y-3">
                        {expenses.map(exp => {
                            const cat = CATEGORIES.find(c => c.id === exp.category) || CATEGORIES[4];
                            const Icon = cat.icon;
                            return (
                                <div key={exp.id} className={`flex items-center justify-between p-3 rounded-2xl border ${listCard}`}>
                                    <div className="flex items-center gap-3">
                                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${cat.bg} ${cat.color}`}><Icon size={20} /></div>
                                        <div><h4 className={`font-bold text-sm ${isLight ? 'text-black' : 'text-white'}`}>{exp.title}</h4><p className="text-[10px] text-gray-500">{new Date(exp.date).toLocaleDateString()} • {exp.category}</p></div>
                                    </div>
                                    <div className="flex items-center gap-3"><span className="font-black text-red-500">-৳{exp.amount}</span><button onClick={() => deleteExpense(exp.id)} className="p-2 text-gray-400 hover:text-red-500"><Trash2 size={16} /></button></div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}
        </div>

        {/* RECEIPTS MODAL */}
        {renderReceiptModal()}

        {showYearSelector && (
            <div className="fixed inset-0 z-[10001] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowYearSelector(false)}>
                <div className={`w-full max-w-[280px] p-6 rounded-[32px] shadow-2xl animate-zoom-in-down ${isLight ? 'bg-white' : 'bg-[#1a1a20] border border-gray-700'}`} onClick={e => e.stopPropagation()}>
                    <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500">
                            <Calendar size={20} />
                        </div>
                        <h3 className={`font-black text-lg ${isLight ? 'text-black' : 'text-white'}`}>Select Year</h3>
                    </div>
                    
                    <input 
                        type="number"
                        inputMode="numeric"
                        autoFocus
                        value={tempYear}
                        onChange={e => setTempYear(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && handleYearConfirm()}
                        placeholder="Type year (e.g. 2025)"
                        className={`w-full p-4 rounded-2xl mb-5 outline-none font-black text-2xl text-center tracking-widest ${isLight ? 'bg-gray-100 text-black border border-gray-200' : 'bg-black/30 text-white border border-white/10 focus:border-blue-500'}`}
                    />
                    
                    <div className="grid grid-cols-2 gap-3">
                        <button 
                            onClick={() => setShowYearSelector(false)} 
                            className={`py-3 rounded-xl font-bold text-xs transition active:scale-95 ${isLight ? 'bg-gray-100 text-gray-500' : 'bg-white/5 text-gray-400'}`}
                        >
                            Cancel
                        </button>
                        <button 
                            onClick={handleYearConfirm} 
                            className="py-3 rounded-xl font-bold text-xs bg-blue-500 text-white shadow-lg shadow-blue-500/30 active:scale-95 transition"
                        >
                            Confirm
                        </button>
                    </div>
                </div>
            </div>
        )}

        {showExpenseModal && (
            <div className="fixed inset-0 z-[5000] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 pb-safe" onClick={() => setShowExpenseModal(false)}>
                <div className={`w-full max-w-sm rounded-[32px] p-6 shadow-2xl animate-slide-up relative ${isLight ? 'bg-white' : 'bg-[#1E1E24] border border-gray-700'}`} onClick={e => e.stopPropagation()}>
                    <button onClick={() => setShowExpenseModal(false)} className="absolute top-4 right-4 text-gray-500 hover:text-white"><X size={20} /></button>
                    <h3 className={`text-xl font-black mb-6 ${isLight ? 'text-black' : 'text-white'}`}>Add Expense</h3>
                    <div className="space-y-4">
                        <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Title (e.g. Broken Tap)" className={`w-full p-4 rounded-2xl font-bold outline-none ${isLight ? 'bg-gray-100 text-black' : 'bg-black/30 text-white border border-white/10'}`} autoFocus />
                        <div className={`flex items-center px-4 py-3 rounded-2xl border ${isLight ? 'bg-gray-100 border-gray-200' : 'bg-black/30 border-white/10'}`}>
                            <span className="text-red-500 font-bold mr-2 text-lg">৳</span>
                            <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="Amount" className={`w-full bg-transparent outline-none font-bold text-lg ${isLight ? 'text-black' : 'text-white'}`} />
                        </div>
                        <input type="date" value={date} onChange={e => setDate(e.target.value)} className={`w-full p-4 rounded-2xl font-bold outline-none ${isLight ? 'bg-gray-100 text-black' : 'bg-black/30 text-white border border-white/10'}`} />
                        <div className="grid grid-cols-3 gap-2">
                            {CATEGORIES.map(cat => (
                                <button key={cat.id} onClick={() => setCategory(cat.id as any)} className={`p-2 rounded-xl flex flex-col items-center justify-center gap-1 border-2 transition-all ${category === cat.id ? `${cat.bg} ${cat.color} border-current` : (isLight ? 'border-gray-200 text-gray-400' : 'border-white/5 text-gray-500')}`}>
                                    <cat.icon size={18} />
                                    <span className="text-[9px] font-bold">{cat.label}</span>
                                </button>
                            ))}
                        </div>
                        <button onClick={handleAddExpense} className="w-full py-4 bg-red-500 text-white font-bold rounded-2xl shadow-lg active:scale-95 transition mt-2">Save Expense</button>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default Expenses;