import React, { useState, useRef, useEffect } from 'react';
import { AppData, Page } from '../types';
import { searchWebWithAI } from './services/aiService';
import TopBar from '../components/TopBar';
import { Search, User, Home, Phone, Zap, ArrowRight, Globe, Database, Newspaper, TrendingUp, CloudSun, Loader2, ExternalLink, PlusCircle, Settings, FileText } from 'lucide-react';

interface Props {
  data: AppData;
  setData: (data: AppData) => void;
  onOpenSettings: () => void;
  setNavVisible: (visible: boolean) => void;
  onResultClick: (id: string, type: 'tenant' | 'unit') => void;
  setPage: (page: Page) => void;
}

type SearchMode = 'app' | 'web';

const SearchPage: React.FC<Props> = ({ data, setData, onOpenSettings, setNavVisible, onResultClick, setPage }) => {
  const [mode, setMode] = useState<SearchMode>('app');
  const [query, setQuery] = useState('');
  
  // AI Web Search State
  const [aiResult, setAiResult] = useState<{ text: string, sources: any[] } | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  
  const isLight = data.settings.theme === 'light';
  const resultRef = useRef<HTMLDivElement>(null);
  
  // Track mounting to prevent memory leak on fast switch
  const isMounted = useRef(true);
  useEffect(() => {
      return () => { isMounted.current = false; };
  }, []);

  // --- LOCAL APP SEARCH LOGIC ---
  const filteredTenants = data.tenants.filter(t => 
    t.name.toLowerCase().includes(query.toLowerCase()) ||
    t.phone.includes(query) ||
    t.unitId.toLowerCase().includes(query.toLowerCase())
  );

  const filteredUnits = data.units.filter(u =>
    u.name.toLowerCase().includes(query.toLowerCase()) ||
    u.meterNumber.toLowerCase().includes(query.toLowerCase())
  );

  // --- APP ACTIONS SEARCH ---
  const appActions = [
      { id: 'add_tenant', label: 'Add New Tenant', keywords: ['add', 'tenant', 'new', 'create'], icon: PlusCircle, action: () => setPage('form') },
      { id: 'settings', label: 'Open Settings', keywords: ['setting', 'config', 'theme', 'dark'], icon: Settings, action: onOpenSettings },
      { id: 'bill', label: 'Check Bills', keywords: ['bill', 'payment', 'history'], icon: FileText, action: () => setPage('tenants') }
  ];

  const filteredActions = appActions.filter(a => 
      a.keywords.some(k => query.toLowerCase().includes(k)) || 
      a.label.toLowerCase().includes(query.toLowerCase())
  );

  // --- WEB SEARCH LOGIC ---
  const handleWebSearch = async (overrideQuery?: string) => {
      const q = overrideQuery || query;
      if (!q.trim()) return;

      setIsAiLoading(true);
      setAiResult(null);
      // Keyboard dismiss
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }

      const result = await searchWebWithAI(q);
      
      // Safety Check before updating state
      if (isMounted.current) {
          setAiResult(result);
          setIsAiLoading(false);
      }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
      if (e.key === 'Enter') {
          if (mode === 'web') {
              handleWebSearch();
          }
      }
  };

  return (
    <div className={`h-screen flex flex-col animate-fade-in ${isLight ? 'bg-app-lightBg' : 'bg-app-bg'}`}>
        <div className="flex-none z-50">
            <TopBar data={data} setData={setData} onOpenSettings={onOpenSettings} />
        </div>

        <div className="flex-1 flex flex-col overflow-hidden">
            {/* SEARCH TABS */}
            <div className={`flex items-center justify-center gap-4 py-4 shrink-0 border-b ${isLight ? 'bg-white/50 backdrop-blur-sm border-gray-200' : 'bg-black/20 backdrop-blur-sm border-white/5'}`}>
                <button 
                    onClick={() => setMode('app')}
                    className={`px-6 py-2 rounded-full text-xs font-bold transition-all active:scale-95 ${mode === 'app' ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/30' : (isLight ? 'bg-gray-200 text-gray-600' : 'bg-white/10 text-gray-400')}`}
                >
                    App Search
                </button>
                <button 
                    onClick={() => setMode('web')}
                    className={`px-6 py-2 rounded-full text-xs font-bold transition-all active:scale-95 flex items-center gap-2 ${mode === 'web' ? 'bg-purple-500 text-white shadow-lg shadow-purple-500/30' : (isLight ? 'bg-gray-200 text-gray-600' : 'bg-white/10 text-gray-400')}`}
                >
                    <Globe size={12} /> Web AI
                </button>
            </div>

            {/* SEARCH INPUT AREA */}
            <div className="p-5 shrink-0">
                <div className={`flex items-center px-4 py-3 rounded-2xl border-2 transition-all ${isLight ? 'bg-white border-gray-200 focus-within:border-blue-400 shadow-sm' : 'bg-[#18191F] border-gray-800 focus-within:border-blue-500 shadow-lg'}`}>
                    <Search size={20} className="text-gray-400 mr-3 shrink-0" />
                    <input 
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        onKeyDown={handleKeyPress}
                        placeholder={mode === 'app' ? "Search tenants, rooms..." : "Ask AI anything..."}
                        autoFocus
                        className={`w-full bg-transparent outline-none font-bold text-base ${isLight ? 'text-black placeholder-gray-400' : 'text-white placeholder-gray-500'}`}
                    />
                    {mode === 'web' && (
                        <button 
                            onClick={() => handleWebSearch()}
                            disabled={isAiLoading || !query}
                            className={`p-2 rounded-xl transition-all active:scale-90 ${isAiLoading || !query ? 'bg-gray-700 text-gray-500' : 'bg-purple-500 text-white shadow-lg'}`}
                        >
                            {isAiLoading ? <Loader2 size={18} className="animate-spin"/> : <ArrowRight size={18}/>}
                        </button>
                    )}
                </div>
            </div>

            {/* RESULTS AREA */}
            <div className="flex-1 overflow-y-auto p-5 pt-0 pb-32" ref={resultRef}>
                {mode === 'app' ? (
                    <div className="space-y-6">
                        {/* 1. Actions */}
                        {filteredActions.length > 0 && (
                            <div className="animate-slide-up">
                                <h3 className={`text-xs font-bold uppercase tracking-wider mb-3 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>Quick Actions</h3>
                                <div className="grid grid-cols-2 gap-3">
                                    {filteredActions.map(action => (
                                        <button key={action.id} onClick={action.action} className={`p-4 rounded-2xl border flex items-center gap-3 transition-all active:scale-95 text-left ${isLight ? 'bg-white border-gray-200 hover:border-blue-300' : 'bg-[#1E1E24] border-gray-800 hover:border-gray-600'}`}>
                                            <div className={`p-2 rounded-full ${isLight ? 'bg-blue-50 text-blue-600' : 'bg-blue-500/10 text-blue-400'}`}><action.icon size={18} /></div>
                                            <span className={`font-bold text-sm ${isLight ? 'text-black' : 'text-white'}`}>{action.label}</span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* 2. Tenants */}
                        {filteredTenants.length > 0 && (
                            <div className="animate-slide-up">
                                <h3 className={`text-xs font-bold uppercase tracking-wider mb-3 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>Tenants ({filteredTenants.length})</h3>
                                <div className="space-y-2">
                                    {filteredTenants.map(t => (
                                        <div key={t.id} onClick={() => onResultClick(t.id, 'tenant')} className={`flex items-center p-3 rounded-2xl border transition-all active:scale-95 cursor-pointer ${isLight ? 'bg-white border-gray-100 hover:shadow-md' : 'bg-[#1E1E24] border-gray-800 hover:bg-[#25252b]'}`}>
                                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold shrink-0">{t.name[0]}</div>
                                            <div className="ml-3">
                                                <h4 className={`font-bold text-sm ${isLight ? 'text-black' : 'text-white'}`}>{t.name}</h4>
                                                <div className="flex items-center gap-2 text-[10px] text-gray-500">
                                                    <span className="flex items-center gap-1"><Home size={10}/> {t.unitId}</span>
                                                    <span>•</span>
                                                    <span className="flex items-center gap-1"><Phone size={10}/> {t.phone}</span>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* 3. Units */}
                        {filteredUnits.length > 0 && (
                            <div className="animate-slide-up">
                                <h3 className={`text-xs font-bold uppercase tracking-wider mb-3 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>Rooms ({filteredUnits.length})</h3>
                                <div className="grid grid-cols-3 gap-2">
                                    {filteredUnits.map(u => (
                                        <div key={u.id} className={`p-3 rounded-xl border text-center transition-all ${isLight ? 'bg-white border-gray-200' : 'bg-[#1E1E24] border-gray-800'}`}>
                                            <Home size={18} className="mx-auto mb-1 text-gray-400" />
                                            <h4 className={`font-bold text-sm ${isLight ? 'text-black' : 'text-white'}`}>{u.name}</h4>
                                            <span className={`text-[9px] font-bold uppercase ${u.status === 'occupied' ? 'text-red-500' : 'text-green-500'}`}>{u.status}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {!query && (
                            <div className="text-center py-20 opacity-30">
                                <Database size={48} className="mx-auto mb-4" />
                                <p className="font-bold">Start typing to search...</p>
                            </div>
                        )}
                    </div>
                ) : (
                    /* --- WEB SEARCH RESULTS --- */
                    <div className="space-y-6">
                        {aiResult ? (
                            <div className="animate-fade-in">
                                <div className={`p-5 rounded-[24px] border relative overflow-hidden mb-6 ${isLight ? 'bg-gradient-to-br from-purple-50 to-white border-purple-100' : 'bg-[#1E1E24] border-purple-500/20'}`}>
                                    <div className="flex items-center gap-2 mb-3">
                                        <SparklesIcon />
                                        <h3 className={`font-black text-lg ${isLight ? 'text-purple-900' : 'text-purple-400'}`}>AI Answer</h3>
                                    </div>
                                    <div className={`prose prose-sm max-w-none leading-relaxed ${isLight ? 'text-gray-700' : 'text-gray-300'}`}>
                                        <p>{aiResult.text}</p>
                                    </div>
                                </div>

                                {aiResult.sources && aiResult.sources.length > 0 && (
                                    <div>
                                        <h3 className={`text-xs font-bold uppercase tracking-wider mb-3 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>Sources</h3>
                                        <div className="space-y-2">
                                            {aiResult.sources.map((src, i) => (
                                                <a href={src.uri} target="_blank" rel="noopener noreferrer" key={i} className={`flex items-center p-3 rounded-xl border transition-all active:scale-95 ${isLight ? 'bg-white border-gray-200 hover:border-blue-300' : 'bg-black/20 border-gray-800 hover:border-gray-600'}`}>
                                                    <div className="p-2 bg-blue-500/10 rounded-lg text-blue-500 mr-3"><ExternalLink size={16}/></div>
                                                    <div className="flex-1 min-w-0">
                                                        <h4 className={`font-bold text-xs truncate ${isLight ? 'text-blue-600' : 'text-blue-400'}`}>{src.title}</h4>
                                                        <p className="text-[10px] text-gray-500 truncate">{src.uri}</p>
                                                    </div>
                                                </a>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        ) : (
                            isAiLoading ? (
                                <div className="text-center py-20">
                                    <Loader2 size={40} className="animate-spin mx-auto text-purple-500 mb-4" />
                                    <p className={`font-bold animate-pulse ${isLight ? 'text-gray-600' : 'text-gray-400'}`}>Thinking...</p>
                                </div>
                            ) : (
                                <div className="text-center py-20 opacity-30">
                                    <CloudSun size={60} className="mx-auto mb-4" />
                                    <p className="font-bold">Ask AI anything from the web.</p>
                                    <p className="text-xs mt-2">Try "Rental laws in BD" or "Draft agreement format"</p>
                                </div>
                            )
                        )}
                    </div>
                )}
            </div>
        </div>
    </div>
  );
};

const SparklesIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-purple-500 animate-pulse">
        <path d="M12 2L14.4 9.6L22 12L14.4 14.4L12 22L9.6 14.4L2 12L9.6 9.6L12 2Z" fill="currentColor"/>
    </svg>
);

export default SearchPage;