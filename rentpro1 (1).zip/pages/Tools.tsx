import React, { useState, useEffect } from 'react';
import { AppData, Medicine, Page } from '../types';
import TopBar from '../components/TopBar';
import { scheduleRepeatingNotification, cancelNotification, requestNotificationPermission } from './services/notificationService';
import { 
  Pill, X, Trash2, Hourglass, 
  DollarSign, ArrowRightLeft, Calculator, ListTodo, RefreshCw, Wifi, WifiOff, Stethoscope,
  ChevronUp, ChevronDown, Clock, Calendar, CheckCircle2, Search, Circle, CheckCircle, Delete, History,
  Plug, Lightbulb, Tv, Snowflake, Monitor, Zap, Fan, Power, AlertCircle, Settings, Box
} from 'lucide-react';
import { Capacitor } from '@capacitor/core';

interface Props {
  data: AppData;
  setData: (data: AppData) => void;
  onOpenSettings: () => void;
  setPage: (page: Page) => void;
}

// --- EXTENDED GLOBAL CURRENCY DATABASE (100+ Currencies) ---
const CURRENCY_DB = [
    // --- MAJOR WORLD CURRENCIES ---
    { code: 'USD', name: 'United States Dollar', country: 'us' },
    { code: 'EUR', name: 'Euro (European Union)', country: 'eu' },
    { code: 'GBP', name: 'British Pound Sterling', country: 'gb' },
    { code: 'JPY', name: 'Japanese Yen', country: 'jp' },
    { code: 'CNY', name: 'Chinese Yuan', country: 'cn' },
    { code: 'CHF', name: 'Swiss Franc', country: 'ch' },
    { code: 'CAD', name: 'Canadian Dollar', country: 'ca' },
    { code: 'AUD', name: 'Australian Dollar', country: 'au' },
    { code: 'NZD', name: 'New Zealand Dollar', country: 'nz' },
    
    // --- SOUTH ASIA ---
    { code: 'BDT', name: 'Bangladeshi Taka', country: 'bd' },
    { code: 'INR', name: 'Indian Rupee', country: 'in' },
    { code: 'PKR', name: 'Pakistani Rupee', country: 'pk' },
    { code: 'LKR', name: 'Sri Lankan Rupee', country: 'lk' },
    { code: 'NPR', name: 'Nepalese Rupee', country: 'np' },
    { code: 'AFN', name: 'Afghan Afghani', country: 'af' },
    { code: 'MVR', name: 'Maldivian Rufiyaa', country: 'mv' },
    { code: 'BTN', name: 'Bhutanese Ngultrum', country: 'bt' },

    // --- MIDDLE EAST ---
    { code: 'SAR', name: 'Saudi Riyal', country: 'sa' },
    { code: 'AED', name: 'UAE Dirham', country: 'ae' },
    { code: 'KWD', name: 'Kuwaiti Dinar', country: 'kw' },
    { code: 'QAR', name: 'Qatari Riyal', country: 'qa' },
    { code: 'OMR', name: 'Omani Rial', country: 'om' },
    { code: 'BHD', name: 'Bahraini Dinar', country: 'bh' },
    { code: 'JOD', name: 'Jordanian Dinar', country: 'jo' },
    { code: 'ILS', name: 'Israeli New Shekel', country: 'il' },
    { code: 'TRY', name: 'Turkish Lira', country: 'tr' },
    { code: 'EGP', name: 'Egyptian Pound', country: 'eg' },
    { code: 'IQD', name: 'Iraqi Dinar', country: 'iq' },
    { code: 'IRR', name: 'Iranian Rial', country: 'ir' },
    { code: 'LBP', name: 'Lebanese Pound', country: 'lb' },
    { code: 'YER', name: 'Yemeni Rial', country: 'ye' },

    // --- SOUTHEAST & EAST ASIA ---
    { code: 'MYR', name: 'Malaysian Ringgit', country: 'my' },
    { code: 'SGD', name: 'Singapore Dollar', country: 'sg' },
    { code: 'THB', name: 'Thai Baht', country: 'th' },
    { code: 'IDR', name: 'Indonesian Rupiah', country: 'id' },
    { code: 'VND', name: 'Vietnamese Dong', country: 'vn' },
    { code: 'PHP', name: 'Philippine Peso', country: 'ph' },
    { code: 'KRW', name: 'South Korean Won', country: 'kr' },
    { code: 'HKD', name: 'Hong Kong Dollar', country: 'hk' },
    { code: 'TWD', name: 'New Taiwan Dollar', country: 'tw' },
    { code: 'MMK', name: 'Myanmar Kyat', country: 'mm' },
    { code: 'KHR', name: 'Cambodian Riel', country: 'kh' },
    { code: 'LAK', name: 'Lao Kip', country: 'la' },
    { code: 'BND', name: 'Brunei Dollar', country: 'bn' },

    // --- EUROPE (NON-EURO) ---
    { code: 'RUB', name: 'Russian Ruble', country: 'ru' },
    { code: 'SEK', name: 'Swedish Krona', country: 'se' },
    { code: 'NOK', name: 'Norwegian Krone', country: 'no' },
    { code: 'DKK', name: 'Danish Krone', country: 'dk' },
    { code: 'PLN', name: 'Polish Zloty', country: 'pl' },
    { code: 'CZK', name: 'Czech Koruna', country: 'cz' },
    { code: 'HUF', name: 'Hungarian Forint', country: 'hu' },
    { code: 'RON', name: 'Romanian Leu', country: 'ro' },
    { code: 'BGN', name: 'Bulgarian Lev', country: 'bg' },
    { code: 'ISK', name: 'Icelandic Krona', country: 'is' },
    { code: 'UAH', name: 'Ukrainian Hryvnia', country: 'ua' },
    { code: 'RSD', name: 'Serbian Dinar', country: 'rs' },
    { code: 'ALL', name: 'Albanian Lek', country: 'al' },
    { code: 'BAM', name: 'Bosnia-Herz Mark', country: 'ba' },
    { code: 'MKD', name: 'Macedonian Denar', country: 'mk' },

    // --- AMERICAS (NORTH & SOUTH) ---
    { code: 'MXN', name: 'Mexican Peso', country: 'mx' },
    { code: 'BRL', name: 'Brazilian Real', country: 'br' },
    { code: 'ARS', name: 'Argentine Peso', country: 'ar' },
    { code: 'CLP', name: 'Chilean Peso', country: 'cl' },
    { code: 'COP', name: 'Colombian Peso', country: 'co' },
    { code: 'PEN', name: 'Peruvian Sol', country: 'pe' },
    { code: 'UYU', name: 'Uruguayan Peso', country: 'uy' },
    { code: 'VEF', name: 'Venezuelan Bolívar', country: 've' },
    { code: 'BOB', name: 'Bolivian Boliviano', country: 'bo' },
    { code: 'PYG', name: 'Paraguayan Guarani', country: 'py' },
    { code: 'CRC', name: 'Costa Rican Colón', country: 'cr' },
    { code: 'DOP', name: 'Dominican Peso', country: 'do' },
    { code: 'GTQ', name: 'Guatemalan Quetzal', country: 'gt' },
    { code: 'HNL', name: 'Honduran Lempira', country: 'hn' },
    { code: 'JMD', name: 'Jamaican Dollar', country: 'jm' },
    { code: 'TTD', name: 'Trinidad/Tobago Dollar', country: 'tt' },

    // --- AFRICA ---
    { code: 'ZAR', name: 'South African Rand', country: 'za' },
    { code: 'NGN', name: 'Nigerian Naira', country: 'ng' },
    { code: 'KES', name: 'Kenyan Shilling', country: 'ke' },
    { code: 'EGP', name: 'Egyptian Pound', country: 'eg' },
    { code: 'GHS', name: 'Ghanaian Cedi', country: 'gh' },
    { code: 'MAD', name: 'Moroccan Dirham', country: 'ma' },
    { code: 'DZD', name: 'Algerian Dinar', country: 'dz' },
    { code: 'TND', name: 'Tunisian Dinar', country: 'tn' },
    { code: 'UGX', name: 'Ugandan Shilling', country: 'ug' },
    { code: 'TZS', name: 'Tanzanian Shilling', country: 'tz' },
    { code: 'MUR', name: 'Mauritian Rupee', country: 'mu' },
    { code: 'ETB', name: 'Ethiopian Birr', country: 'et' },
    { code: 'XOF', name: 'West African CFA', country: 'sn' }, // Senegal flag for CFA
    { code: 'XAF', name: 'Central African CFA', country: 'cm' }, // Cameroon flag for CFA

    // --- OCEANIA ---
    { code: 'FJD', name: 'Fijian Dollar', country: 'fj' },
    { code: 'PGK', name: 'Papua New Guinea Kina', country: 'pg' },
    { code: 'SBD', name: 'Solomon Islands Dollar', country: 'sb' },
    { code: 'TOP', name: 'Tongan Paʻanga', country: 'to' },
    { code: 'VUV', name: 'Vanuatu Vatu', country: 'vu' },
    { code: 'WST', name: 'Samoan Tala', country: 'ws' },
];

interface ToolItem {
  id: string;
  label: string;
  icon: any;
  color: string;
  bg: string;
  action?: () => any;
  comingSoon?: boolean;
}

interface CalcHistoryItem {
  expression: string;
  result: string;
  timestamp: number;
}

const Tools: React.FC<Props> = ({ data, setData, onOpenSettings, setPage }) => {
  const isLight = data.settings.theme === 'light';
  const [activeTool, setActiveTool] = useState<string | null>(null);

  // Medicine State
  const [medName, setMedName] = useState('');
  
  // Custom Digital Clock State
  const [clockHour, setClockHour] = useState(8);
  const [clockMinute, setClockMinute] = useState(0);
  const [ampm, setAmpm] = useState<'AM' | 'PM'>('AM');

  const [medDuration, setMedDuration] = useState('');
  const [medInstruction, setMedInstruction] = useState('After Food');

  // Currency State
  const [currAmount, setCurrAmount] = useState('1');
  const [currFrom, setCurrFrom] = useState('USD');
  const [currTo, setCurrTo] = useState('BDT');
  const [currResult, setCurrResult] = useState<string | null>(null);
  
  // Currency Selector Modal State
  const [showCurrencySelector, setShowCurrencySelector] = useState(false);
  const [selectorType, setSelectorType] = useState<'from' | 'to'>('from');
  const [currencySearch, setCurrencySearch] = useState('');
  
  // Real-time Currency State
  const [liveRates, setLiveRates] = useState<Record<string, number> | null>(null);
  const [isFetchingRates, setIsFetchingRates] = useState(false);
  const [rateStatus, setRateStatus] = useState<'live' | 'offline'>('offline');
  const [lastUpdated, setLastUpdated] = useState<string>('');

  // Calculator State
  const [calcInput, setCalcInput] = useState('');
  const [calcResult, setCalcResult] = useState('');
  const [calcHistory, setCalcHistory] = useState<CalcHistoryItem[]>([]);
  const [showCalcHistory, setShowCalcHistory] = useState(false);

  // --- ELECTRICAL CALCULATOR STATE ---
  const [elecManualWatts, setElecManualWatts] = useState('');
  const [elecResult, setElecResult] = useState<{load: number, amps: number, mcb: string, wire: string} | null>(null);

  // Helper: Days Left
  const getRemainingDays = (med: Medicine) => {
      if (!med.startDate || !med.duration) return null;
      const start = new Date(med.startDate);
      const end = new Date(start);
      end.setDate(start.getDate() + parseInt(med.duration));
      const diff = end.getTime() - new Date().getTime();
      return Math.ceil(diff / (1000 * 3600 * 24));
  };

  // Load History from storage
  useEffect(() => {
      if (activeTool === 'calc') {
          const stored = localStorage.getItem('tool_calc_history');
          if (stored) {
              try {
                  const parsed = JSON.parse(stored);
                  setCalcHistory(parsed);
              } catch (e) {}
          }
      }
  }, [activeTool]);

  const addMedicine = async () => {
      if (!medName) {
          alert("Please enter medicine name");
          return;
      }
      
      // EXPLICIT PERMISSION CHECK ON ADD
      if (Capacitor.isNativePlatform()) {
          const granted = await requestNotificationPermission();
          if (!granted) {
              alert("⚠️ Permission Denied. You must allow notifications for reminders to work.");
              return;
          }
      }

      const id = Date.now().toString();
      
      // Convert 12h to 24h for Storage/Logic
      let hour24 = clockHour;
      if (ampm === 'PM' && clockHour !== 12) hour24 += 12;
      if (ampm === 'AM' && clockHour === 12) hour24 = 0;
      
      const timeString = `${hour24.toString().padStart(2, '0')}:${clockMinute.toString().padStart(2, '0')}`;

      const newMed: Medicine = {
          id,
          name: medName,
          time: timeString, 
          instruction: medInstruction as any,
          duration: medDuration,
          startDate: new Date().toISOString()
      };
      
      const updatedMeds = [...(data.medicines || []), newMed];
      setData({ ...data, medicines: updatedMeds });

      // Use last 8 digits of ID for notification ID (must be int)
      const notifId = parseInt(id.slice(-8));
      
      // Use the new Repeating Function
      await scheduleRepeatingNotification(
          notifId, 
          medName, 
          `Time to take ${medName} (${clockHour}:${clockMinute.toString().padStart(2, '0')} ${ampm}) - ${medInstruction}`,
          hour24, 
          clockMinute
      );

      setMedName(''); setMedDuration('');
      setClockHour(8); setClockMinute(0); setAmpm('AM');
      
      // Keep tool open to see the list, but maybe give feedback
      if(navigator.vibrate) navigator.vibrate(50);
  };

  const deleteMedicine = (id: string) => {
      if(!confirm("Remove this alarm?")) return;
      const updated = (data.medicines || []).filter(m => m.id !== id);
      setData({ ...data, medicines: updated });
      // Cancel native notification
      cancelNotification(parseInt(id.slice(-8)));
  };

  // --- LIVE CURRENCY FETCH (WITH OFFLINE CACHE) ---
  const fetchLiveRates = async () => {
      // 1. Load Cache First
      const cached = localStorage.getItem('currency_rates');
      if (cached) {
          try {
              const { rates, timestamp } = JSON.parse(cached);
              setLiveRates(rates);
              setRateStatus('offline');
              setLastUpdated(new Date(timestamp).toLocaleTimeString());
          } catch(e) {}
      }

      if (!navigator.onLine) {
          return;
      }

      setIsFetchingRates(true);
      try {
          const res = await fetch('https://open.er-api.com/v6/latest/USD');
          const data = await res.json();
          
          if (data && data.rates) {
              setLiveRates(data.rates);
              setRateStatus('live');
              setLastUpdated(new Date().toLocaleTimeString());
              
              // 2. Save to Cache
              localStorage.setItem('currency_rates', JSON.stringify({
                  rates: data.rates,
                  timestamp: Date.now()
              }));
          }
      } catch (error) {
          console.error("Currency fetch failed", error);
      } finally {
          setIsFetchingRates(false);
      }
  };

  // Fetch rates when tool opens
  useEffect(() => {
      if (activeTool === 'currency') {
          fetchLiveRates();
          // Initial Convert call to show default result if rates exist
          if (liveRates) handleConvert();
      }
  }, [activeTool]);

  const handleConvert = () => {
     const val = parseFloat(currAmount);
     if(isNaN(val)) return;

     let rates: Record<string, number> = { 
         'USD': 1, 
         'BDT': 122.50, 
         'EUR': 0.92, 
         'INR': 83.50, 
         'GBP': 0.79,
         'SAR': 3.75,
         'MYR': 4.72,
         'CAD': 1.35,
         'AUD': 1.52
     };

     if (liveRates) {
         rates = liveRates;
     }

     const rateFrom = rates[currFrom];
     const rateTo = rates[currTo];

     if (!rateFrom || !rateTo) {
         // Fallback if not in basic list, though liveRates usually has all
         return;
     }

     const baseAmountUSD = val / rateFrom;
     const result = baseAmountUSD * rateTo;

     setCurrResult(result.toFixed(2));
  };

  const openCurrencySelector = (type: 'from' | 'to') => {
      setSelectorType(type);
      setCurrencySearch('');
      setShowCurrencySelector(true);
  };

  const selectCurrency = (code: string) => {
      if (selectorType === 'from') setCurrFrom(code);
      else setCurrTo(code);
      setCurrResult(null); // Reset result to force re-convert
      setShowCurrencySelector(false);
  };

  // --- CALCULATOR LOGIC ---
  const handleCalcInput = (val: string) => {
      if (val === 'history') {
          setShowCalcHistory(!showCalcHistory);
          return;
      }

      if (val === 'AC') {
          setCalcInput('');
          setCalcResult('');
          return;
      }
      
      if (val === 'DEL') {
          setCalcInput(prev => prev.slice(0, -1));
          return;
      }

      if (val === '=') {
          try {
              // Safety Replace: × -> *, ÷ -> /
              const expression = calcInput.replace(/×/g, '*').replace(/÷/g, '/');
              // Safe evaluation using Function
              // eslint-disable-next-line no-new-func
              const res = new Function(`return ${expression}`)();
              // Format result: add commas
              const formattedRes = new Intl.NumberFormat().format(res);
              setCalcResult('= ' + formattedRes);

              // SAVE TO HISTORY (30 Days Retention)
              const newItem: CalcHistoryItem = {
                  expression: calcInput,
                  result: formattedRes,
                  timestamp: Date.now()
              };
              const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;
              const updatedHistory = [newItem, ...calcHistory].filter(item => Date.now() - item.timestamp < THIRTY_DAYS_MS);
              setCalcHistory(updatedHistory);
              localStorage.setItem('tool_calc_history', JSON.stringify(updatedHistory));

          } catch (e) {
              setCalcResult('Error');
          }
          return;
      }

      // Append value
      setCalcInput(prev => {
          // Prevent multiple operators
          const lastChar = prev.slice(-1);
          if (['+', '-', '×', '÷', '%'].includes(lastChar) && ['+', '-', '×', '÷', '%'].includes(val)) {
              return prev.slice(0, -1) + val;
          }
          return prev + val;
      });
  };

  // --- ELECTRICAL CALC LOGIC ---
  const calculateElectricalLoad = () => {
      const totalWatts = Number(elecManualWatts) || 0;

      if (totalWatts === 0) return;

      // 3. Calc Amps (Single Phase 220V)
      // I = P / V.  Assuming pf=1 for rough estimation suitable for MCB sizing
      const amps = totalWatts / 220;

      // 4. Determine Wire Size (Copper)
      let wire = "1.5 mm²"; // Default min
      if (amps <= 10) wire = "1.0 - 1.5 mm²";
      else if (amps <= 16) wire = "2.5 mm²";
      else if (amps <= 25) wire = "4.0 mm²";
      else if (amps <= 40) wire = "6.0 mm²";
      else if (amps <= 60) wire = "10.0 mm²";
      else wire = "Consult Engineer";

      // 5. Determine MCB Rating (Standard Sizes: 6, 10, 16, 20, 32, 40, 63)
      const standards = [6, 10, 16, 20, 32, 40, 63];
      let mcb = standards.find(s => s > amps);
      let mcbStr = mcb ? `${mcb}A` : "63A+ (Check)";

      setElecResult({
          load: totalWatts,
          amps: parseFloat(amps.toFixed(2)),
          mcb: mcbStr,
          wire: wire
      });
  };

  const filteredCurrencies = CURRENCY_DB.filter(c => 
      c.name.toLowerCase().includes(currencySearch.toLowerCase()) || 
      c.code.toLowerCase().includes(currencySearch.toLowerCase())
  );

  // Group History by Date
  const groupedHistory = React.useMemo(() => {
      const groups: Record<string, CalcHistoryItem[]> = {};
      calcHistory.forEach(item => {
          const d = new Date(item.timestamp);
          const today = new Date();
          const yesterday = new Date(today);
          yesterday.setDate(yesterday.getDate() - 1);
          
          let key = d.toLocaleDateString();
          if (d.toDateString() === today.toDateString()) key = "Today";
          else if (d.toDateString() === yesterday.toDateString()) key = "Yesterday";
          
          if (!groups[key]) groups[key] = [];
          groups[key].push(item);
      });
      return groups;
  }, [calcHistory]);

  const tools: ToolItem[] = [
      { id: 'medicine', label: 'Pill Reminder', icon: Pill, color: 'text-rose-500', bg: 'bg-rose-500/10' },
      { id: 'medex', label: 'Medex BD', icon: Stethoscope, color: 'text-cyan-500', bg: 'bg-cyan-500/10', action: () => window.open('https://medex.com.bd', '_blank') },
      { id: 'currency', label: 'Currency', icon: DollarSign, color: 'text-green-500', bg: 'bg-green-500/10' },
      { id: 'electrical', label: 'Load Calc', icon: Plug, color: 'text-yellow-500', bg: 'bg-yellow-500/10' },
      { id: 'todo', label: 'Todo List', icon: ListTodo, color: 'text-orange-500', bg: 'bg-orange-500/10', action: () => setPage('todos') },
      // ENABLED CALCULATOR
      { id: 'calc', label: 'Calculator', icon: Calculator, color: 'text-blue-500', bg: 'bg-blue-500/10' },
  ];

  return (
    <div className={`h-screen flex flex-col animate-fade-in ${isLight ? 'bg-app-lightBg' : 'bg-app-bg'}`}>
        <div className="flex-none z-50">
            <TopBar 
                title={<><span className={isLight ? 'text-black' : 'text-white'}>Utility</span><span className="text-blue-500">Box</span></>} 
                data={data} 
                setData={setData}
                onOpenSettings={onOpenSettings} 
            />
        </div>

        <div className="flex-1 overflow-y-auto p-5 pb-32">
            <h3 className={`text-xs font-bold uppercase tracking-wider mb-4 ml-1 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>All Tools</h3>
            <div className="grid grid-cols-2 gap-3">
                {tools.map(tool => (
                    <button 
                        key={tool.id}
                        onClick={() => {
                            if (tool.action) tool.action();
                            else if (!tool.comingSoon) setActiveTool(tool.id);
                        }}
                        className={`p-4 rounded-2xl border flex flex-col items-center justify-center gap-3 transition-all active:scale-95 ${isLight ? 'bg-white border-gray-200 shadow-sm' : 'bg-[#18191F] border-gray-800'} ${tool.comingSoon ? 'opacity-50 grayscale' : ''}`}
                    >
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center ${tool.bg} ${tool.color}`}>
                            <tool.icon size={24} />
                        </div>
                        <span className={`font-bold text-sm ${isLight ? 'text-black' : 'text-white'}`}>{tool.label}</span>
                        {tool.comingSoon && <span className="text-[9px] bg-gray-700 text-white px-2 py-0.5 rounded-full">Soon</span>}
                    </button>
                ))}
            </div>
        </div>

        {/* 1. MEDICINE REMINDER MODAL */}
        {activeTool === 'medicine' && (
            <div className="fixed inset-0 z-[9999] bg-black/90 backdrop-blur-md flex flex-col items-center justify-start pt-10 pb-safe px-4" onClick={() => setActiveTool(null)}>
                <div className={`w-full max-w-sm rounded-[32px] flex flex-col overflow-hidden shadow-2xl relative ${isLight ? 'bg-gray-50' : 'bg-[#121214] border border-gray-800'}`} style={{ maxHeight: '85vh' }} onClick={e => e.stopPropagation()}>
                    <div className={`flex justify-between items-center p-5 shrink-0 border-b ${isLight ? 'bg-white border-gray-200' : 'bg-[#1a1a1f] border-white/5'}`}>
                        <h3 className={`text-xl font-black flex items-center gap-2 ${isLight ? 'text-black' : 'text-white'}`}>
                            <div className="bg-rose-500/10 p-2 rounded-full"><Pill className="text-rose-500" size={20}/></div>
                            Pill Reminder
                        </h3>
                        <button onClick={() => setActiveTool(null)} className="p-2 bg-gray-500/10 rounded-full hover:bg-gray-500/20"><X size={20} className="text-gray-500"/></button>
                    </div>

                    <div className="flex-1 overflow-y-auto scrollbar-hide">
                        <div className={`p-5 space-y-4 ${isLight ? 'bg-white' : 'bg-[#1a1a1f] shadow-inner'}`}>
                            {/* Medicine form content here */}
                            <div className={`flex items-center px-4 py-3 rounded-2xl border ${isLight ? 'bg-gray-50 border-gray-200' : 'bg-black/30 border-white/10'}`}>
                                <input 
                                    value={medName} 
                                    onChange={e => setMedName(e.target.value)} 
                                    placeholder="Medicine Name (e.g. Napa)" 
                                    className={`w-full bg-transparent outline-none font-bold text-lg ${isLight ? 'text-black placeholder-gray-400' : 'text-white placeholder-gray-600'}`} 
                                />
                            </div>
                            <div className={`flex items-center justify-center gap-3 py-4 rounded-2xl border ${isLight ? 'bg-gray-50 border-gray-200' : 'bg-black/30 border-white/10'}`}>
                                <div className="flex flex-col items-center gap-1">
                                    <button onClick={() => setClockHour(h => h === 12 ? 1 : h + 1)} className={`p-1 rounded hover:bg-white/10 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}><ChevronUp size={24}/></button>
                                    <span className={`text-4xl font-black font-mono ${isLight ? 'text-black' : 'text-white'}`}>{clockHour.toString().padStart(2, '0')}</span>
                                    <button onClick={() => setClockHour(h => h === 1 ? 12 : h - 1)} className={`p-1 rounded hover:bg-white/10 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}><ChevronDown size={24}/></button>
                                </div>
                                <span className={`text-2xl font-black pb-2 ${isLight ? 'text-gray-300' : 'text-gray-600'}`}>:</span>
                                <div className="flex flex-col items-center gap-1">
                                    <button onClick={() => setClockMinute(m => m >= 55 ? 0 : m + 5)} className={`p-1 rounded hover:bg-white/10 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}><ChevronUp size={24}/></button>
                                    <span className={`text-4xl font-black font-mono ${isLight ? 'text-black' : 'text-white'}`}>{clockMinute.toString().padStart(2, '0')}</span>
                                    <button onClick={() => setClockMinute(m => m < 5 ? 55 : m - 5)} className={`p-1 rounded hover:bg-white/10 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}><ChevronDown size={24}/></button>
                                </div>
                                <div className="flex flex-col items-center justify-center ml-2">
                                    <button 
                                        onClick={() => setAmpm(p => p === 'AM' ? 'PM' : 'AM')} 
                                        className={`w-16 py-3 rounded-xl font-black text-xl shadow-lg active:scale-95 transition ${isLight ? 'bg-white border border-gray-200 text-black' : 'bg-white/10 border border-white/10 text-white'}`}
                                    >
                                        {ampm}
                                    </button>
                                </div>
                            </div>
                            <div className="flex gap-2">
                                <div className={`flex-1 flex items-center rounded-xl px-3 border ${isLight ? 'bg-gray-50 border-gray-200' : 'bg-black/30 border-white/10'}`}>
                                    <Calendar size={14} className="text-gray-400 mr-2"/>
                                    <input 
                                        type="number"
                                        value={medDuration}
                                        onChange={e => setMedDuration(e.target.value)}
                                        placeholder="Days" 
                                        className={`w-full bg-transparent outline-none font-bold text-xs py-3 ${isLight ? 'text-black placeholder-gray-400' : 'text-white placeholder-gray-500'}`} 
                                    />
                                </div>
                                <div className={`flex-[2] flex items-center rounded-xl px-3 border relative ${isLight ? 'bg-gray-50 border-gray-200' : 'bg-black/30 border-white/10'}`}>
                                    <Clock size={14} className="text-gray-400 mr-2"/>
                                    <select 
                                        value={medInstruction} 
                                        onChange={e => setMedInstruction(e.target.value as any)}
                                        className={`w-full bg-transparent outline-none font-bold text-xs py-3 appearance-none ${isLight ? 'text-black' : 'text-white'}`} 
                                    >
                                        <option className="text-black">After Food</option>
                                        <option className="text-black">Before Food</option>
                                        <option className="text-black">Empty Stomach</option>
                                    </select>
                                    <ChevronDown size={14} className="absolute right-3 text-gray-400 pointer-events-none"/>
                                </div>
                            </div>
                            <button onClick={addMedicine} className="w-full py-3.5 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-2xl active:scale-95 transition shadow-lg shadow-rose-500/30 flex items-center justify-center gap-2">
                                <CheckCircle2 size={20} /> Set Reminder
                            </button>
                        </div>

                        <div className={`min-h-0 p-4 space-y-2 ${isLight ? 'bg-gray-50' : 'bg-[#121214]'}`}>
                            <h4 className={`text-[10px] font-bold uppercase tracking-wider mb-2 ml-1 ${isLight ? 'text-gray-400' : 'text-gray-500'}`}>Saved Alarms</h4>
                            {(!data.medicines || data.medicines.length === 0) && (
                                <div className="text-center py-8 opacity-40">
                                    <Pill size={32} className="mx-auto mb-2 text-gray-400" />
                                    <p className="text-xs font-bold text-gray-500">No medicines added yet.</p>
                                </div>
                            )}
                            {(data.medicines || []).map(med => {
                                const daysLeft = getRemainingDays(med);
                                const isFinished = daysLeft !== null && daysLeft <= 0;
                                const [h, m] = med.time.split(':');
                                const hNum = parseInt(h);
                                const ampm = hNum >= 12 ? 'PM' : 'AM';
                                const h12 = hNum % 12 || 12;
                                return (
                                    <div key={med.id} className={`flex items-center justify-between p-3 rounded-2xl border transition-all ${isLight ? 'bg-white border-gray-200 shadow-sm' : 'bg-[#1E1E24] border-gray-800'} ${isFinished ? 'opacity-60 grayscale' : ''}`}>
                                        <div className="flex items-center gap-3">
                                            <div className={`w-12 h-12 rounded-xl flex flex-col items-center justify-center border font-bold leading-none shadow-sm ${isFinished ? 'bg-gray-100 text-gray-400 border-gray-200' : 'bg-rose-50 text-rose-600 border-rose-100'}`}>
                                                <span className="text-sm">{h12}:{m}</span>
                                                <span className="text-[9px] uppercase">{ampm}</span>
                                            </div>
                                            <div>
                                                <h4 className={`font-bold text-sm ${isLight ? 'text-black' : 'text-white'}`}>{med.name}</h4>
                                                <div className="flex items-center gap-2 text-[10px] mt-0.5">
                                                    <span className="text-gray-500 bg-gray-100 dark:bg-white/10 px-1.5 py-0.5 rounded">{med.instruction}</span>
                                                    {daysLeft !== null && !isFinished && (
                                                        <span className="text-blue-500 font-bold flex items-center gap-1"><Hourglass size={8} className="animate-pulse"/> {daysLeft}d left</span>
                                                    )}
                                                    {isFinished && <span className="text-red-400 font-bold">Ended</span>}
                                                </div>
                                            </div>
                                        </div>
                                        <button onClick={() => deleteMedicine(med.id)} className="p-2.5 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-all"><Trash2 size={18} /></button>
                                    </div>
                                );
                            })}
                            <div className="h-6"></div>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* 2. LIVE CURRENCY CONVERTER MODAL */}
        {activeTool === 'currency' && (
            <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 pb-safe" onClick={() => setActiveTool(null)}>
                <div className={`w-full max-w-sm rounded-[32px] overflow-hidden shadow-2xl animate-scale-in relative ${isLight ? 'bg-white' : 'bg-[#0f1523] border border-gray-800'}`} onClick={e => e.stopPropagation()}>
                    <div className="bg-blue-600 pt-4 pb-8 px-4 text-white text-center relative z-0">
                        <h2 className="text-lg font-black tracking-tight">XE Converter</h2>
                        <p className="text-blue-200 text-[10px] font-bold uppercase tracking-widest opacity-80">Live Market Rates</p>
                        <button onClick={() => setActiveTool(null)} className="absolute top-3 right-3 p-1.5 bg-white/10 rounded-full hover:bg-white/20 transition"><X size={14}/></button>
                    </div>
                    <div className="px-4 -mt-6 pb-4 relative z-10">
                        <div className={`rounded-2xl p-4 shadow-lg border ${isLight ? 'bg-white border-gray-100' : 'bg-[#1a1f2e] border-gray-700'}`}>
                            <div className="mb-4">
                                <label className={`text-[10px] font-bold uppercase tracking-wider mb-1 block ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>Amount</label>
                                <div className={`flex items-center px-4 py-3 rounded-xl border-2 transition-all focus-within:border-blue-500 ${isLight ? 'bg-gray-50 border-gray-200' : 'bg-black/20 border-gray-700'}`}>
                                    <span className="font-bold text-lg mr-2 text-gray-400">$</span>
                                    <input 
                                        type="number" 
                                        value={currAmount}
                                        onChange={e => { setCurrAmount(e.target.value); setCurrResult(null); }} 
                                        className={`w-full bg-transparent outline-none font-bold text-xl ${isLight ? 'text-black' : 'text-white'}`}
                                        placeholder="1.00"
                                    />
                                </div>
                            </div>
                            
                            <div className="flex items-center gap-2 mb-6">
                                <button onClick={() => openCurrencySelector('from')} className={`flex-1 p-3 rounded-xl border flex items-center justify-between gap-2 active:scale-95 transition ${isLight ? 'border-gray-200 bg-gray-50' : 'border-gray-700 bg-white/5'}`}>
                                    <div className="flex items-center gap-2 overflow-hidden">
                                        <img src={`https://flagcdn.com/w40/${CURRENCY_DB.find(c => c.code === currFrom)?.country || 'us'}.png`} className="w-6 h-4 rounded shadow-sm object-cover" alt="flag"/>
                                        <span className={`font-black text-lg ${isLight ? 'text-black' : 'text-white'}`}>{currFrom}</span>
                                    </div>
                                    <ChevronDown size={14} className="text-gray-400"/>
                                </button>
                                <button onClick={() => { setCurrFrom(currTo); setCurrTo(currFrom); setCurrResult(null); }} className="p-3 rounded-full bg-blue-50 text-blue-600 border border-blue-100 shadow-sm active:rotate-180 transition-transform">
                                    <ArrowRightLeft size={16} />
                                </button>
                                <button onClick={() => openCurrencySelector('to')} className={`flex-1 p-3 rounded-xl border flex items-center justify-between gap-2 active:scale-95 transition ${isLight ? 'border-gray-200 bg-gray-50' : 'border-gray-700 bg-white/5'}`}>
                                    <div className="flex items-center gap-2 overflow-hidden">
                                        <img src={`https://flagcdn.com/w40/${CURRENCY_DB.find(c => c.code === currTo)?.country || 'bd'}.png`} className="w-6 h-4 rounded shadow-sm object-cover" alt="flag"/>
                                        <span className={`font-black text-lg ${isLight ? 'text-black' : 'text-white'}`}>{currTo}</span>
                                    </div>
                                    <ChevronDown size={14} className="text-gray-400"/>
                                </button>
                            </div>

                            {currResult ? (
                                <div className="text-center mb-4 animate-fade-in">
                                    <p className={`text-sm font-bold ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>
                                        {parseFloat(currAmount || '0').toFixed(2)} {currFrom} =
                                    </p>
                                    <h3 className={`text-3xl font-black tracking-tight my-1 ${isLight ? 'text-blue-900' : 'text-blue-400'}`}>
                                        {currResult} <span className="text-lg">{currTo}</span>
                                    </h3>
                                    <div className="flex items-center justify-center gap-2 mt-2">
                                        <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                                        <p className="text-[10px] text-gray-400 font-medium">Mid-market rate • {lastUpdated || 'Live'}</p>
                                    </div>
                                </div>
                            ) : (
                                <div className="text-center py-4 mb-2">
                                    <p className="text-xs text-gray-400">Enter amount to convert</p>
                                </div>
                            )}

                            <button onClick={handleConvert} disabled={isFetchingRates} className="w-full py-4 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-600/30 active:scale-95 transition flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed">
                                {isFetchingRates ? <><RefreshCw className="animate-spin" size={18}/> Checking Rates...</> : 'Convert Now'}
                            </button>
                        </div>
                        <div className="mt-4 flex items-center justify-center gap-4 text-[10px] text-gray-500">
                            <span className="flex items-center gap-1"><Wifi size={10}/> {rateStatus === 'live' ? 'Connected' : 'Offline Mode'}</span>
                            <span>•</span>
                            <span>Updated: {lastUpdated || 'Just now'}</span>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* 3. CALCULATOR MODAL (UPDATED WITH HISTORY & BOTTOM PADDING) */}
        {activeTool === 'calc' && (
            <div className="fixed inset-0 z-[9999] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 pb-32" onClick={() => setActiveTool(null)}>
                <div className={`w-full max-w-[340px] rounded-[32px] overflow-hidden shadow-2xl relative flex flex-col animate-slide-up ${isLight ? 'bg-white' : 'bg-[#18191F] border border-gray-800'}`} onClick={e => e.stopPropagation()}>
                    {/* Header */}
                    <div className="flex justify-between items-center p-4 shrink-0">
                        <h3 className={`text-lg font-black ml-2 ${isLight ? 'text-black' : 'text-white'}`}>Calculator</h3>
                        <button onClick={() => setActiveTool(null)} className="p-2 rounded-full hover:bg-gray-500/20 transition"><X size={20} className={isLight ? 'text-gray-600' : 'text-gray-400'}/></button>
                    </div>

                    {/* Display */}
                    <div className="px-6 pb-2 text-right shrink-0">
                        <div className={`text-xl font-medium mb-1 h-8 ${isLight ? 'text-gray-400' : 'text-gray-500'}`}>{calcInput || '0'}</div>
                        <div className={`text-4xl font-black h-12 truncate ${isLight ? 'text-green-600' : 'text-green-400'}`}>{calcResult || '0'}</div>
                    </div>

                    {/* Content: History List OR Keypad */}
                    {showCalcHistory ? (
                        <div className={`flex-1 overflow-y-auto p-4 animate-fade-in ${isLight ? 'bg-gray-50' : 'bg-[#1a1a20]'}`}>
                            <div className="flex justify-between items-center mb-4">
                                <h4 className={`text-xs font-bold uppercase tracking-widest ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>History</h4>
                                <button onClick={() => { setCalcHistory([]); localStorage.removeItem('tool_calc_history'); }} className="text-red-500 text-[10px] font-bold bg-red-500/10 px-2 py-1 rounded">Clear</button>
                            </div>
                            
                            {Object.keys(groupedHistory).length === 0 ? (
                                <div className="text-center py-10 opacity-40">
                                    <History size={32} className="mx-auto mb-2 text-gray-500"/>
                                    <p className="text-xs">No history yet</p>
                                </div>
                            ) : (
                                Object.entries(groupedHistory).map(([date, items]) => (
                                    <div key={date} className="mb-4">
                                        <h5 className={`text-[10px] font-bold mb-2 opacity-50 sticky top-0 py-1 ${isLight ? 'bg-gray-50 text-black' : 'bg-[#1a1a20] text-white'}`}>{date}</h5>
                                        <div className="space-y-2">
                                            {(items as CalcHistoryItem[]).map((item, idx) => (
                                                <div key={idx} className={`p-2 rounded-xl text-right border ${isLight ? 'bg-white border-gray-200' : 'bg-black/20 border-white/5'}`}>
                                                    <div className={`text-xs mb-0.5 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>{item.expression} =</div>
                                                    <div className={`text-lg font-bold ${isLight ? 'text-black' : 'text-white'}`}>{item.result.replace('= ', '')}</div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                ))
                            )}
                            <button onClick={() => setShowCalcHistory(false)} className="w-full py-3 mt-4 bg-app-accent text-black font-bold rounded-xl active:scale-95 transition sticky bottom-0 shadow-lg">Back to Calculator</button>
                        </div>
                    ) : (
                        /* Keypad */
                        <div className={`p-4 grid grid-cols-4 gap-3 ${isLight ? 'bg-gray-100' : 'bg-[#121216]'}`}>
                            {['AC', 'DEL', '%', '÷', '7', '8', '9', '×', '4', '5', '6', '-', '1', '2', '3', '+', 'history', '0', '.', '='].map((btn) => {
                                const isAction = ['AC', 'DEL', '%', 'history'].includes(btn);
                                const isOperator = ['÷', '×', '-', '+', '='].includes(btn);
                                
                                return (
                                    <button 
                                        key={btn}
                                        onClick={() => handleCalcInput(btn)}
                                        className={`
                                            h-16 rounded-[20px] font-bold text-xl flex items-center justify-center shadow-sm active:scale-90 transition-all
                                            ${isAction ? (isLight ? 'bg-white text-red-500' : 'bg-[#2A2B35] text-red-400') : ''}
                                            ${isOperator ? 'bg-green-500 text-white shadow-green-500/30' : ''}
                                            ${!isAction && !isOperator ? (isLight ? 'bg-white text-black' : 'bg-[#1E1E24] text-white') : ''}
                                            ${btn === 'history' ? (isLight ? 'text-blue-500' : 'text-blue-400') : ''}
                                        `}
                                    >
                                        {btn === 'DEL' ? <Delete size={22}/> : btn === 'history' ? <History size={22}/> : btn}
                                    </button>
                                );
                            })}
                        </div>
                    )}
                </div>
            </div>
        )}

        {/* 4. ELECTRICAL LOAD CALCULATOR MODAL (COMPACT NO SCROLL) */}
        {activeTool === 'electrical' && (
            <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 pb-safe animate-fade-in" onClick={() => setActiveTool(null)}>
                <div className="w-full max-w-sm bg-[#F5F5F5] rounded-2xl overflow-hidden shadow-2xl relative flex flex-col" onClick={e => e.stopPropagation()}>
                    
                    {/* Header - Blue Bar */}
                    <div className="bg-[#1976D2] px-4 py-3 flex items-center justify-between shrink-0 shadow-md relative z-10">
                        <div className="flex items-center gap-2">
                            <div className="relative">
                                <Lightbulb size={20} className="text-yellow-400 fill-yellow-400 drop-shadow-sm" strokeWidth={2} />
                                <div className="absolute inset-0 bg-yellow-400 blur-md opacity-30"></div>
                            </div>
                            <h3 className="text-lg font-black text-white tracking-wide text-shadow-sm">Electrical Calc</h3>
                        </div>
                        
                        <button onClick={() => setActiveTool(null)} className="p-1.5 bg-white/10 rounded-full text-white hover:bg-white/20 transition"><X size={16}/></button>
                    </div>

                    {/* Content - Removed overflow-y-auto, used tight spacing */}
                    <div className="p-4 space-y-3">
                        
                        {/* Simplified Input Section - Compact */}
                        <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-200">
                            <label className="text-[#37474F] font-bold text-[10px] uppercase tracking-wider mb-2 block text-center">Total Load (Watts)</label>
                            
                            <div className="flex items-center gap-3">
                                <div className="bg-[#FF9800] rounded-lg p-2 text-white shadow-md">
                                    <Power size={20} strokeWidth={2.5} />
                                </div>
                                <div className="flex-1 relative">
                                    <input 
                                        type="number"
                                        value={elecManualWatts}
                                        onChange={(e) => { setElecManualWatts(e.target.value); setElecResult(null); }}
                                        placeholder="0"
                                        className="w-full h-10 border-2 border-gray-200 rounded-lg px-2 text-center font-black text-2xl text-[#37474F] outline-none focus:border-[#1976D2] focus:bg-blue-50 transition-all placeholder-gray-300"
                                        autoFocus
                                    />
                                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-bold text-gray-400 pointer-events-none">W</span>
                                </div>
                            </div>
                        </div>

                        {/* Calculate Button - Compact */}
                        <button 
                            onClick={calculateElectricalLoad}
                            className="w-full bg-gradient-to-b from-[#4CAF50] to-[#2E7D32] text-white font-black text-sm py-3 rounded-xl shadow-[0_3px_0_#1B5E20] active:shadow-[0_1px_0_#1B5E20] active:translate-y-[2px] transition-all tracking-wider flex items-center justify-center gap-2"
                        >
                            CALCULATE <ArrowRightLeft size={16} />
                        </button>

                        {/* Results Section - Grid Compact */}
                        {elecResult ? (
                            <div className="animate-slide-up space-y-2 pt-1">
                                <div className="flex items-center gap-2">
                                    <div className="h-[1px] flex-1 bg-gray-300"></div>
                                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Results</span>
                                    <div className="h-[1px] flex-1 bg-gray-300"></div>
                                </div>
                                
                                <div className="grid grid-cols-2 gap-2">
                                    {/* Total Load */}
                                    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-2 flex flex-col items-center gap-0.5">
                                        <span className="text-[9px] font-bold text-gray-500 uppercase">Load</span>
                                        <span className="text-base font-black text-[#E64A19]">{elecResult.load} W</span>
                                    </div>

                                    {/* Current */}
                                    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-2 flex flex-col items-center gap-0.5">
                                        <span className="text-[9px] font-bold text-gray-500 uppercase">Current</span>
                                        <span className="text-base font-black text-[#1565C0]">{elecResult.amps} A</span>
                                    </div>

                                    {/* Wire Size */}
                                    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-2 flex flex-col items-center gap-0.5 col-span-2 sm:col-span-1">
                                        <span className="text-[9px] font-bold text-gray-500 uppercase">Wire</span>
                                        <span className="text-sm font-black text-[#D32F2F]">{elecResult.wire}</span>
                                    </div>

                                    {/* MCB Rating */}
                                    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-2 flex flex-col items-center gap-0.5 col-span-2 sm:col-span-1">
                                        <span className="text-[9px] font-bold text-gray-500 uppercase">Breaker</span>
                                        <span className="text-base font-black text-[#455A64]">{elecResult.mcb}</span>
                                    </div>
                                </div>

                                {/* Status Bar */}
                                <div className={`w-full py-2 rounded-lg shadow-md flex items-center justify-center gap-2 text-white font-bold text-xs ${elecResult.amps > 63 ? 'bg-red-600' : 'bg-green-600'}`}>
                                    {elecResult.amps > 63 ? <AlertCircle size={14} /> : <CheckCircle size={14} />}
                                    {elecResult.amps > 63 ? "Overload!" : "System Safe"}
                                </div>
                            </div>
                        ) : (
                            // Placeholder space to prevent layout jumpiness or keep it clean
                            <div className="h-32 flex items-center justify-center opacity-30">
                                <Zap size={48} className="text-gray-400" />
                            </div>
                        )}
                    </div>
                </div>
            </div>
        )}

        {/* 5. CURRENCY SELECTION MODAL */}
        {showCurrencySelector && (
            <div className="fixed inset-0 z-[9999] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in" onClick={() => setShowCurrencySelector(false)}>
                <div className="w-full max-sm h-[80vh] bg-[#121214] rounded-[32px] flex flex-col overflow-hidden border border-gray-800 shadow-2xl" onClick={e => e.stopPropagation()}>
                    <div className="p-4 border-b border-gray-800 bg-[#1a1a1f]">
                        <div className="flex items-center gap-2 bg-black/30 p-3 rounded-xl border border-gray-700">
                            <Search size={18} className="text-gray-400"/>
                            <input 
                                autoFocus
                                placeholder="Search Currency..."
                                value={currencySearch}
                                onChange={e => setCurrencySearch(e.target.value)}
                                className="flex-1 bg-transparent outline-none text-white font-bold text-sm placeholder-gray-500"
                            />
                        </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-2 scrollbar-hide">
                        {filteredCurrencies.map((c) => {
                            const isSelected = (selectorType === 'from' ? currFrom : currTo) === c.code;
                            return (
                                <button 
                                    key={c.code}
                                    onClick={() => selectCurrency(c.code)}
                                    className={`w-full flex items-center justify-between p-4 rounded-xl mb-1 transition-all ${isSelected ? 'bg-blue-500/20 border border-blue-500/50' : 'hover:bg-white/5 border border-transparent'}`}
                                >
                                    <div className="flex items-center gap-4">
                                        <img src={`https://flagcdn.com/w40/${c.country}.png`} className="w-8 h-5 rounded object-cover shadow-sm" alt={c.code}/>
                                        <div className="text-left">
                                            <h4 className="text-white font-bold text-sm">{c.name}</h4>
                                            <p className="text-gray-500 text-[10px] font-bold">{c.code}</p>
                                        </div>
                                    </div>
                                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${isSelected ? 'border-blue-500' : 'border-gray-600'}`}>
                                        {isSelected && <div className="w-2.5 h-2.5 bg-blue-500 rounded-full"></div>}
                                    </div>
                                </button>
                            );
                        })}
                    </div>
                    <button onClick={() => setShowCurrencySelector(false)} className="py-4 bg-[#1a1a1f] text-gray-400 font-bold text-sm border-t border-gray-800 hover:text-white transition">Cancel</button>
                </div>
            </div>
        )}

    </div>
  );
};

export default Tools;