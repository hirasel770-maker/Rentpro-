import React, { useState, useMemo, useEffect, useRef } from 'react';
import { AppData, Page, Bill, Tenant } from '../types';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import TopBar from '../components/TopBar';
import { 
  Plus, X, 
  ArrowUpRight, ArrowDownLeft, 
  CheckCircle, AlertCircle, Phone, Zap, Printer,
  Share2, TrendingDown, Building2, Wrench, User,
  PlusCircle, LayoutGrid, Banknote, Wallet, Activity, Siren, AlertTriangle, MoreHorizontal, TrendingUp,
  ShieldAlert, ScanLine, Radar, Shield, Save, Database, HardDrive, Loader2, CloudDownload, Users, Bell, Calendar, CreditCard
} from 'lucide-react';

interface Props {
  data: AppData;
  setData: (data: AppData) => void;
  onOpenSettings: () => void;
  setPage: (page: Page) => void;
  onEditTenant: (id: string, focusField?: string) => void; // Updated signature
}

interface ActivityItem {
  id: string;
  type: 'payment' | 'bill';
  title: string;
  subtitle: string;
  date: Date;
  amount: number;
  isPaid: boolean;
  originalBill: Bill;
}

// Updated Calculator for Perfect Centering
const Calculator = ({ onClose, isLight }: { onClose: () => void, isLight: boolean }) => {
  const [display, setDisplay] = useState('0');
  const calculate = (expression: string) => {
    try {
      const safeExpr = expression.replace(/x/g, '*').replace(/÷/g, '/');
      if (/[^0-9+\-*/.]/.test(safeExpr)) return 'Error';
      // eslint-disable-next-line no-new-func
      const result = new Function(`return ${safeExpr}`)();
      return String(Math.round(result * 1000) / 1000);
    } catch { return 'Error'; }
  };
  const handlePress = (val: string) => {
    if (val === 'AC') setDisplay('0');
    else if (val === '=') setDisplay(calculate(display));
    else setDisplay(prev => prev === '0' || prev === 'Error' ? val : prev + val);
  };
  const btns = ['AC', '/', '*', '-', '7', '8', '9', '+', '4', '5', '6', '.', '1', '2', '3', '=', '0'];
  return (
    <div className="fixed inset-0 z-[5000] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 pb-safe" onClick={onClose}>
        <div className={`w-full max-w-[320px] rounded-[32px] p-5 shadow-2xl animate-slide-up border relative mb-safe ${isLight ? 'bg-white/80 backdrop-blur-2xl border-white/50 text-black' : 'bg-black/40 backdrop-blur-xl border-white/10 text-white'}`} onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute -top-12 right-0 bg-red-500 text-white p-3 rounded-full shadow-lg active:scale-95 transition"><X size={24} strokeWidth={3} /></button>
        <div className={`w-full h-16 mb-4 rounded-2xl flex items-end justify-end p-3 text-4xl font-black overflow-hidden tracking-tighter ${isLight ? 'bg-white/50' : 'bg-black/20'}`}>{display}</div>
        <div className="grid grid-cols-4 gap-3">
            {btns.map(b => (
            <button key={b} onClick={() => handlePress(b)} className={`h-14 rounded-2xl font-bold active:scale-90 transition shadow-sm text-lg ${b === '=' ? 'col-span-2 bg-app-accent text-black w-full' : (isLight ? 'bg-white/60 hover:bg-white/80' : 'bg-white/5 hover:bg-white/10')}`}>{b}</button>
            ))}
        </div>
        </div>
    </div>
  );
};

const Dashboard: React.FC<Props> = ({ data, setData, onOpenSettings, setPage, onEditTenant }) => {
  const [showCalculator, setShowCalculator] = useState(false);
  const [showDueList, setShowDueList] = useState(false);
  const [showEnergyList, setShowEnergyList] = useState(false);
  const [showCollectedList, setShowCollectedList] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false); 
  const [showRiskModal, setShowRiskModal] = useState(false); 
  const [showNoAdvanceModal, setShowNoAdvanceModal] = useState(false); // New modal state
  const [isBackingUp, setIsBackingUp] = useState(false);
  
  // Long Press State
  const [isPressing, setIsPressing] = useState(false);
  // Replaced NodeJS.Timeout with any to fix namespace error
  const pressTimer = useRef<any>(null);
  
  const isLight = data?.settings?.theme === 'light';
  const isWeb = Capacitor.getPlatform() === 'web';

  // --- FLOATING STYLE HELPERS ---
  const glassCard = isLight 
    ? "bg-white border border-gray-100 shadow-[0_20px_40px_-15px_rgba(0,0,0,0.1)] hover:shadow-[0_25px_50px_-12px_rgba(0,0,0,0.15)] transition-shadow duration-300" 
    : "bg-[#1E1E24] border border-white/5 shadow-[0_20px_40px_-15px_rgba(0,0,0,0.5)]";

  const glassList = isLight
    ? "bg-white border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_8px_30px_rgb(0,0,0,0.08)] transition-all"
    : "bg-[#1E1E24] border border-white/5 hover:bg-[#25252b] transition-colors shadow-lg";
    
  // --- SAFE COMPACT NUMBER FORMATTER ---
  const formatCompact = (num: number | undefined | null) => {
    if (num === undefined || num === null || isNaN(num)) return '0';
    try {
        return new Intl.NumberFormat('en-US', {
          notation: "compact",
          compactDisplay: "short",
          maximumFractionDigits: 1
        }).format(num);
    } catch (e) { return num.toString(); }
  };

  // --- DYNAMIC FONT SCALER ---
  const getScaleClass = (txt: string) => {
      const len = txt.length;
      if(len > 10) return 'text-[10px]'; // Very long numbers
      if(len > 7) return 'text-xs';      // Long numbers
      if(len > 5) return 'text-sm';      // Medium numbers
      return 'text-lg';                  // Standard (Short)
  };

  // --- SMART BACKUP & OPTIMIZE ---
  const handleSmartBackupAndClear = async () => {
      if (isBackingUp) return;
      // Haptic feedback confirmation
      if (navigator.vibrate) navigator.vibrate([100, 50, 100]);

      setIsBackingUp(true);
      const fileName = `NeonRent_FullBackup_${new Date().toISOString().split('T')[0]}.json`;
      const jsonString = JSON.stringify(data);

      try {
          // 1. PERFORM BACKUP
          if (isWeb) {
              const blob = new Blob([jsonString], {type: "application/json"});
              const url = URL.createObjectURL(blob);
              const link = document.createElement('a');
              link.href = url;
              link.download = fileName;
              link.click();
              // FIX: Revoke URL to prevent memory leak
              setTimeout(() => URL.revokeObjectURL(url), 5000);
          } else {
              try {
                  await Filesystem.mkdir({
                      path: 'NeonRent_Backups',
                      directory: Directory.Documents,
                      recursive: true
                  });
              } catch (e) {}

              await Filesystem.writeFile({
                  path: `NeonRent_Backups/${fileName}`,
                  data: jsonString,
                  directory: Directory.Documents,
                  encoding: Encoding.UTF8
              });
          }

          // 2. OPTIMIZE STORAGE (Remove Base64 Images from State)
          setTimeout(() => {
              const optimizedData: AppData = {
                  ...data,
                  tenants: data.tenants.map(t => ({
                      ...t,
                      idImage: undefined, // Clear heavy ID image
                      profileImage: undefined // Clear heavy Profile image
                  })),
                  bills: data.bills.map(b => ({
                      ...b,
                      meterImage: undefined // Clear heavy meter images
                  }))
              };
              
              setData(optimizedData);
              setIsBackingUp(false);
              alert("✅ Backup Saved & System Optimized!\n\nHeavy images have been cleared to boost speed.");
          }, 1500); 

      } catch (e) {
          setIsBackingUp(false);
          alert("Backup Failed. Storage not cleared.");
      }
  };

  // --- LONG PRESS HANDLERS ---
  const handlePressStart = () => {
      if (isBackingUp) return;
      setIsPressing(true);
      pressTimer.current = setTimeout(() => {
          setIsPressing(false);
          handleSmartBackupAndClear(); // Trigger Action after 3s
      }, 3000); 
  };

  const handlePressEnd = () => {
      if (pressTimer.current) {
          clearTimeout(pressTimer.current);
          pressTimer.current = null;
      }
      setIsPressing(false);
  };

  const handlePrintReceipt = (bill: Bill | null) => {
      if (!bill) return;
      const tenant = (data.tenants || []).find(t => t.id === bill.tenantId);
      if (!tenant) return;
      const printWindow = window.open('', '_blank');
      if (printWindow) {
          const content = `<html><head><title>Receipt</title><style>body{font-family:'Courier New',Courier,monospace;padding:20px}.header{text-align:center;border-bottom:2px solid #000;padding-bottom:10px}.row{display:flex;justify-content:space-between;margin:5px 0}.total{font-weight:bold;border-top:1px dashed #000;margin-top:10px;padding-top:5px}</style></head><body><div class="header"><h1>RECEIPT</h1><p>${new Date(bill.date).toLocaleDateString()}</p></div><div class="row"><span>Tenant</span><span>${tenant.name}</span></div><div class="row"><span>Amount</span><span>${bill.isPaid ? bill.paidAmount : bill.totalAmount} Tk</span></div><div class="row total"><span>TOTAL</span><span>${bill.isPaid ? bill.paidAmount : bill.totalAmount}</span></div><script>window.onload=function(){window.print();window.close();}</script></body></html>`;
          printWindow.document.write(content);
          printWindow.document.close();
      }
  };

  const handleActivityClick = (act: any) => {
      if (act.type === 'payment') {
          const bill = (data.bills || []).find(b => b.id === act.id);
          if (bill && confirm("Print receipt?")) handlePrintReceipt(bill);
      }
  };

  // --- SAFE STATS CALCULATION ---
  const stats = useMemo(() => {
    const bills = data.bills || [];
    const tenants = data.tenants || [];
    const expenses = data.expenses || [];
    
    // Calculate Data Size for System Health
    const jsonString = JSON.stringify(data);
    const bytes = new Blob([jsonString]).size;
    const dataSizeKB = Math.round(bytes / 1024);
    const storagePercentage = Math.min(100, (dataSizeKB / 1000) * 100);
    
    const currentMonth = new Date().toLocaleString('default', { month: 'long', year: 'numeric' });
    const totalPaid = bills.reduce((acc, b) => acc + (b.paidAmount || 0), 0);
    const tenantsWithDue = tenants.filter(t => t.due > 0);
    const totalDue = tenantsWithDue.reduce((acc, t) => acc + (t.due || 0), 0);
    const dueCount = tenantsWithDue.length;
    
    // Financial Health Logic
    const totalPotentialRent = tenants.reduce((acc, t) => t.status === 'Active' ? acc + t.rentAmount : acc, 0);
    const date = new Date();
    const daysInMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
    const timeProgress = (date.getDate() / daysInMonth) * 100;
    
    const totalCollectedThisMonth = bills
        .filter(b => (b.month === currentMonth || b.month === 'Payment') && new Date(b.date).getMonth() === date.getMonth())
        .reduce((acc, b) => acc + b.paidAmount, 0);
        
    const collectionProgress = totalPotentialRent > 0 ? (totalCollectedThisMonth / totalPotentialRent) * 100 : 0;
    const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);
    const netProfit = totalPaid - totalExpenses;

    const thisMonthBills = bills.filter(b => b.month === currentMonth);
    const totalEnergyCost = thisMonthBills.reduce((acc, b) => acc + (b.electricityBill || 0), 0);
    const totalUnitsConsumed = thisMonthBills.reduce((acc, b) => acc + ((b.currMeter || 0) - (b.prevMeter || 0)), 0);

    const energyBreakdown = thisMonthBills.map(bill => {
        const t = tenants.find(t => t.id === bill.tenantId);
        return {
            id: bill.id,
            name: t?.name || 'Unknown',
            unit: t?.unitId || '?',
            profileImage: t?.profileImage,
            units: (bill.currMeter || 0) - (bill.prevMeter || 0),
            cost: bill.electricityBill || 0,
        }
    }).sort((a,b) => b.units - a.units); 

    const collectedBills = bills.filter(b => b.month === 'Payment' || (b.isPaid && b.month === currentMonth)).map(bill => {
        const t = tenants.find(t => t.id === bill.tenantId);
        return {
            ...bill,
            tenantName: t?.name || 'Unknown',
            tenantUnit: t?.unitId,
            tenantPhoto: t?.profileImage
        };
    }).sort((a,b) => {
        const dateA = new Date(a.date).getTime() || 0;
        const dateB = new Date(b.date).getTime() || 0;
        return dateB - dateA;
    });

    const sortedBills = [...bills].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    // INCREASED TO 100 FOR SCROLLING FEATURE
    const recentActivities: ActivityItem[] = sortedBills.slice(0, 100).map(bill => {
        const tenant = tenants.find(t => t.id === bill.tenantId);
        return {
          id: bill.id,
          type: bill.isPaid ? 'payment' : 'bill',
          title: bill.isPaid ? `Payment Received` : `Bill Generated`,
          subtitle: tenant?.name || 'Unknown Tenant',
          date: new Date(bill.date),
          amount: bill.isPaid ? bill.paidAmount : bill.totalAmount,
          isPaid: bill.isPaid,
          originalBill: bill
        };
    });

    // --- RISK RADAR LOGIC ---
    const riskyTenants = tenants
        .filter(t => t.due > 0 && t.status === 'Active')
        .map(t => {
            const riskRatio = t.due / (t.rentAmount || 1); 
            let riskLevel = 'Low';
            if (riskRatio > 2) riskLevel = 'Critical';
            else if (riskRatio > 1) riskLevel = 'High';
            else if (riskRatio > 0.5) riskLevel = 'Medium';
            return { ...t, riskRatio, riskLevel };
        })
        .sort((a, b) => b.riskRatio - a.riskRatio); 

    // --- ADVANCOLESS TENANTS LOGIC ---
    const advancelessTenants = tenants.filter(t => t.status === 'Active' && (t.advance === 0 || !t.advance));

    return { totalPaid, totalDue, dueCount, tenantsWithDue, recentActivities, riskyTenants, advancelessTenants, totalEnergyCost, totalUnitsConsumed, sortedBills, energyBreakdown, collectedBills, totalExpenses, netProfit, timeProgress, collectionProgress, dataSizeKB, storagePercentage };
  }, [data.bills, data.tenants, data.expenses]);

  const groupedActivities = useMemo(() => {
      const groups: Record<string, ActivityItem[]> = {};
      stats.recentActivities.forEach(act => {
          const d = act.date;
          if (isNaN(d.getTime())) return;
          const today = new Date();
          const yesterday = new Date(today);
          yesterday.setDate(yesterday.getDate() - 1);
          let label = d.toDateString();
          if (d.toDateString() === today.toDateString()) label = "Today";
          else if (d.toDateString() === yesterday.toDateString()) label = "Yesterday";
          if (!groups[label]) groups[label] = [];
          groups[label].push(act);
      });
      return groups;
  }, [stats.recentActivities]);

  const quickActions = [
      { label: 'Add Tenant', icon: PlusCircle, gradient: 'bg-gradient-to-br from-cyan-400 to-teal-500', shadow: 'shadow-[0_15px_30px_-5px_rgba(45,212,191,0.4)]', bg: 'bg-cyan-500/10', color: 'text-cyan-500', action: () => setPage('form') },
      { label: 'T. History', icon: Users, gradient: 'bg-gradient-to-br from-orange-400 to-red-500', shadow: 'shadow-[0_15px_30px_-5px_rgba(249,115,22,0.4)]', bg: 'bg-red-500/10', color: 'text-red-500', action: () => setPage('expenses') },
      { label: 'Properties', icon: Building2, gradient: 'bg-gradient-to-br from-purple-400 to-indigo-500', shadow: 'shadow-[0_15px_30px_-5px_rgba(139,92,246,0.4)]', bg: 'bg-emerald-500/10', color: 'text-emerald-500', action: () => setPage('units') },
      { label: 'Tools', icon: Wrench, gradient: 'bg-gradient-to-br from-blue-400 to-cyan-500', shadow: 'shadow-[0_15px_30px_-5px_rgba(59,139,246,0.4)]', bg: 'bg-purple-500/10', color: 'text-purple-500', action: () => setPage('tools') },
  ];

  const shouldShakeEnergy = stats.totalUnitsConsumed > (data.settings.energyLimit || 200);
  const healthStatus = stats.collectionProgress >= stats.timeProgress ? 'Excellent' : 'Lagging';
  const isHealthy = stats.collectionProgress >= stats.timeProgress;
  const healthGradient = isHealthy ? 'from-emerald-400 to-cyan-500 shadow-emerald-500/30' : 'from-red-500 to-orange-500 shadow-red-500/30';
  
  // Progress Circle Calc
  const radius = 16;
  const circumference = 2 * Math.PI * radius;
  // Use storage percentage for system health visualization
  const strokeDashoffset = circumference - (Math.min(100, stats.storagePercentage) / 100) * circumference;
  
  const currentDay = new Date().getDate();
  const isRiskWindow = currentDay >= 10 && currentDay <= 15;
  const isRiskSignalActive = stats.riskyTenants.length > 0; // Removed date restriction for visibility

  // -- PREPARE TEXTS FOR DYNAMIC SCALING --
  const dueText = `৳${formatCompact(stats.totalDue)}`;
  const energyText = `${formatCompact(stats.totalUnitsConsumed)} u`;
  const collectedText = `৳${formatCompact(stats.totalPaid)}`;

  return (
    <div className={`h-screen flex flex-col animate-fade-in`}>
      {/* 1. FIXED HEADER */}
      <div className="flex-none z-50">
          <TopBar data={data} setData={setData} onOpenSettings={onOpenSettings} onSearchClick={() => setPage('search')} />
      </div>
      
      {/* 2. SCROLLABLE CONTENT */}
      <div className="flex-1 overflow-y-auto pb-40 touch-pan-y scrollbar-hide">
          {/* SYSTEM HEALTH / BACKUP HEADER (Sticky inside scroll area) */}
          <div className={`sticky top-0 z-40 pt-safe px-4 pb-2 transition-all duration-300 ${isLight ? 'bg-white/90 backdrop-blur-xl border-b border-gray-100' : 'bg-[#0F1014]/90 backdrop-blur-xl border-b border-white/5'}`}>
              <div className="mt-1 relative rounded-[24px] overflow-hidden p-0.5">
                  <div className={`absolute inset-0 bg-gradient-to-r ${healthGradient} animate-spin-slow opacity-30 blur-sm`}></div>
                  <div className={`relative rounded-[22px] px-3 py-2.5 flex items-center justify-between overflow-hidden ${isLight ? 'bg-white/80 backdrop-blur-3xl' : 'bg-black/80 backdrop-blur-3xl'}`}>
                      
                      {/* Left: Backup Button & Label */}
                      <div className="flex items-center gap-3 z-10">
                          <button 
                            onMouseDown={handlePressStart}
                            onMouseUp={handlePressEnd}
                            onMouseLeave={handlePressEnd}
                            onTouchStart={handlePressStart}
                            onTouchEnd={handlePressEnd}
                            disabled={isBackingUp}
                            className={`relative w-[42px] h-[42px] rounded-full flex items-center justify-center shadow-lg transition-all overflow-hidden ${isLight ? 'bg-white border border-gray-100' : 'bg-white/10 border border-white/10'} ${isBackingUp ? 'cursor-wait' : 'active:scale-90'}`}
                          >
                              {/* Progress Fill Background */}
                              <div 
                                className={`absolute bottom-0 left-0 right-0 bg-blue-500/20 transition-all ease-linear duration-[3000ms] ${isPressing ? 'h-full' : 'h-0'}`}
                              ></div>

                              {isBackingUp ? (
                                  <Loader2 size={20} className="text-blue-500 animate-spin z-10" />
                              ) : (
                                  <CloudDownload size={20} className={`${isHealthy ? 'text-emerald-500' : 'text-orange-500'} z-10`} />
                              )}
                              {!isBackingUp && <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center border border-white shadow-sm z-10"><Database size={8} className="text-white"/></div>}
                          </button>
                          <div>
                              <h4 className={`text-[9px] font-black uppercase tracking-[1px] mb-0.5 ${isLight ? 'text-gray-400' : 'text-gray-500'}`}>System Health</h4>
                              <div className="flex items-center gap-1.5">
                                  <h2 className={`text-xl font-black tracking-tight leading-none ${isLight ? 'text-gray-800' : 'text-white'}`}>
                                      {stats.dataSizeKB} <span className="text-xs text-gray-400">KB</span>
                                  </h2>
                                  {stats.dataSizeKB > 900 && <AlertTriangle size={14} className="text-red-500 animate-pulse"/>}
                              </div>
                          </div>
                      </div>

                      {/* Right: Metrics */}
                      <div className="flex flex-col items-end gap-1 z-10">
                          <div className={`px-2 py-0.5 rounded flex items-center gap-1.5 border ${isLight ? 'bg-white border-gray-100' : 'bg-white/5 border-white/10'}`}><div className="w-1 h-1 rounded-full bg-blue-500 animate-pulse"></div><span className={`text-[8px] font-bold ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>TIME {Math.round(stats.timeProgress)}%</span></div>
                          <div className={`px-2 py-0.5 rounded flex items-center gap-1.5 border ${isLight ? 'bg-white border-gray-100' : 'bg-white/5 border-white/10'}`}><div className={`w-1 h-1 rounded-full ${isHealthy ? 'bg-emerald-500' : 'bg-orange-500'}`}></div><span className={`text-[8px] font-bold ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>CASH {Math.round(stats.collectionProgress)}%</span></div>
                      </div>
                  </div>
              </div>
          </div>

          {/* STATS */}
          <div className="px-4 mt-4 grid grid-cols-3 gap-2">
              <button onClick={() => setShowDueList(true)} className={`relative p-3 rounded-2xl flex flex-col items-center justify-center text-center overflow-hidden active:scale-95 transition-all group ${isLight ? 'bg-gradient-to-br from-[#FF416C] to-[#FF4B2B] text-white shadow-[0_20px_40px_-10px_rgba(255,65,108,0.5)]' : 'bg-[#1a0505] border border-red-500/30 shadow-[0_0_25px_-5px_rgba(239,68,68,0.4)]'}`}>
                  <div className={`mb-2 relative transition-transform duration-300 group-active:scale-110`}><AlertCircle size={26} className={`relative z-10 ${isLight ? 'text-white drop-shadow-md animate-[pulse_2s_infinite]' : 'text-red-500 animate-pulse'}`} /></div>
                  <span className={`text-[10px] font-bold uppercase mb-0.5 ${isLight ? 'text-white/90 drop-shadow-sm' : 'text-gray-400'}`}>Due</span>
                  <h3 className={`${getScaleClass(dueText)} font-black leading-none ${isLight ? 'text-white drop-shadow-sm' : 'text-red-500'}`}>{dueText}</h3>
              </button>
              <div onClick={() => setShowEnergyList(true)} className={`p-2 rounded-2xl flex flex-col items-center justify-center overflow-hidden relative cursor-pointer active:scale-95 transition-all group ${isLight ? 'bg-gradient-to-br from-[#FDC830] to-[#F37335] text-white shadow-[0_20px_40px_-10px_rgba(253,200,48,0.5)]' : 'bg-[#1a1505] border border-yellow-500/30 shadow-[0_0_25px_-5px_rgba(234,179,8,0.4)]'}`}>
                  <div className={`${shouldShakeEnergy ? 'animate-shake' : 'group-hover:rotate-12'} mb-1 transition-transform duration-300`}><Zap size={24} className={`${isLight ? 'text-white drop-shadow-md' : 'text-yellow-500'}`} /></div>
                  <span className={`text-[9px] font-bold uppercase mb-0.5 ${isLight ? 'text-white/90 drop-shadow-sm' : 'text-gray-400'}`}>Energy</span>
                  <h3 className={`${getScaleClass(energyText)} font-black leading-none mb-1 ${isLight ? 'text-white drop-shadow-sm' : 'text-yellow-500'}`}>{energyText}</h3>
                  <div className={`text-[10px] font-bold px-2 rounded-full ${isLight ? 'bg-white/20 text-white backdrop-blur-sm shadow-inner' : 'bg-white/10 text-gray-400'}`}>৳{formatCompact(stats.totalEnergyCost)}</div>
              </div>
              <button onClick={() => setShowCollectedList(true)} className={`p-3 rounded-2xl flex flex-col items-center justify-center text-center active:scale-95 transition-all cursor-pointer group ${isLight ? 'bg-gradient-to-br from-[#11998e] to-[#38ef7d] text-white shadow-[0_20px_40px_-10px_rgba(17,153,142,0.5)]' : 'bg-[#051a05] border border-green-500/30 shadow-[0_0_25px_-5px_rgba(34,197,94,0.4)]'}`}>
                  <div className={`p-1.5 rounded-full mb-2 transition-transform duration-300 group-active:scale-110 ${isLight ? 'bg-white/20 text-white backdrop-blur-sm shadow-inner' : 'bg-green-500/10 text-green-500'}`}><CheckCircle size={20} className={isLight ? 'drop-shadow-sm' : ''}/></div>
                  <span className={`text-[10px] font-bold uppercase mb-0.5 ${isLight ? 'text-white/90 drop-shadow-sm' : 'text-gray-400'}`}>Collected</span>
                  <h3 className={`${getScaleClass(collectedText)} font-black leading-none ${isLight ? 'text-white drop-shadow-sm' : 'text-green-500'}`}>{collectedText}</h3>
                  {/* Removed Net Profit as requested */}
              </button>
          </div>

          {/* QUICK ACTIONS */}
          <div className="px-4 mt-6">
              <div className="grid grid-cols-4 gap-3">
                  {quickActions.map((btn, i) => (
                      <button key={i} onClick={btn.action} className={`flex flex-col items-center justify-center gap-2 py-4 rounded-2xl active:scale-90 transition-all ${isLight ? `${btn.gradient} text-white shadow-xl ${btn.shadow} border-0` : glassCard}`}>
                          <div className={`p-2.5 rounded-full ${isLight ? 'bg-white/20' : btn.bg} ${isLight ? 'text-white' : btn.color}`}><btn.icon size={20} strokeWidth={2.5} /></div>
                          <span className={`text-[10px] font-bold ${isLight ? 'text-white' : 'text-gray-300'}`}>{btn.label}</span>
                      </button>
                  ))}
              </div>
          </div>

          {/* RISK & ACTIVITY - SWAPPED PLACEMENT */}
          <div className="px-5 mt-8 pb-4">
              <div className="flex gap-4">
                  {/* RISK RADAR COLUMN - NOW ON THE LEFT */}
                  <div className="w-[40%] flex flex-col justify-start">
                      <button onClick={() => setShowRiskModal(true)} className="mb-4 flex items-center gap-2 group">
                          <ShieldAlert size={14} className={`transition-all duration-500 ${isRiskSignalActive ? 'text-red-500 animate-[ping_1.5s_ease-in-out_infinite]' : 'text-gray-400'}`} />
                          <h3 className={`text-xs font-bold uppercase tracking-wider underline decoration-dotted decoration-red-500/50 hover:text-red-500 transition ${isLight ? 'text-gray-600' : 'text-gray-400'}`}>Risk Radar</h3>
                      </button>
                      
                      {/* Compact Card - Height set to h-40 to prevent stretching */}
                      <div onClick={() => setShowRiskModal(true)} className={`w-full h-40 rounded-[24px] p-3 flex flex-col items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 ${isRiskSignalActive ? (isLight ? 'bg-red-50 border border-red-100 shadow-md shadow-red-200' : 'bg-red-900/10 border border-red-500/20 shadow-glow shadow-red-500/10') : (isLight ? 'bg-gray-50 border border-gray-100 opacity-60' : 'bg-white/5 border-white/5 opacity-40')}`}>
                          {isRiskSignalActive ? (
                              <>
                                  <div className="relative">
                                      <Siren size={32} className="text-red-500 animate-pulse" />
                                      <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-ping"></div>
                                  </div>
                                  <div className="text-center">
                                      <h4 className="text-2xl font-black text-red-500 leading-none">{stats.riskyTenants.length}</h4>
                                      <span className="text-[10px] font-bold text-red-400 uppercase">Suspects</span>
                                  </div>
                                  <span className="text-[8px] bg-red-500 text-white px-2 py-0.5 rounded-full animate-bounce mt-1 font-bold">Tap to View</span>
                              </>
                          ) : (
                              <>
                                  <Shield size={32} className="text-green-500/50" />
                                  <div className="text-center">
                                      <h4 className="text-lg font-bold text-gray-400 leading-none">Safe</h4>
                                      <span className="text-[9px] font-bold text-gray-500">No Risks</span>
                                  </div>
                              </>
                          )}
                      </div>
                  </div>

                  {/* LATEST ACTIVITY COLUMN - NOW ON THE RIGHT */}
                  <div className="flex-1 min-w-0">
                      <div className="mb-4 flex items-center justify-between">
                          <h3 className={`text-xs font-bold uppercase tracking-wider ml-1 ${isLight ? 'text-gray-600' : 'text-gray-500'}`}>Latest Activity</h3>
                          {/* NEW: ADVANCE ALERT BELL BUTTON */}
                          <button 
                            onClick={() => setShowNoAdvanceModal(true)}
                            className={`p-1.5 rounded-lg transition-all active:scale-90 ${stats.advancelessTenants.length > 0 ? 'bg-red-500/20 text-red-500 animate-shake shadow-[0_0_10px_rgba(239,68,68,0.2)]' : 'text-gray-500'}`}
                          >
                            <Bell size={18} />
                          </button>
                      </div>
                      {/* Independent Scroll Container inside the dashboard flow */}
                      <div className="space-y-4 max-h-[400px] overflow-y-auto pr-1 scrollbar-hide overscroll-contain touch-pan-y border-t border-white/5 pt-2">
                          {Object.keys(groupedActivities).length === 0 ? <p className="text-center text-gray-500 text-xs py-4">No recent activity.</p> : (
                              Object.entries(groupedActivities).map(([label, activities]) => (
                                  <div key={label}>
                                      <h4 className={`text-[9px] font-black uppercase mb-2 opacity-50 ${isLight ? 'text-gray-600' : 'text-gray-400'}`}>{label}</h4>
                                      <div className="space-y-3">
                                          {(activities as ActivityItem[]).map((act) => (
                                              <div key={act.id} onClick={() => handleActivityClick(act)} className={`p-3 rounded-2xl transition-all active:scale-95 ${glassList}`}>
                                                  <div className="flex items-center justify-between mb-1">
                                                      <div className={`w-8 h-8 rounded-full flex items-center justify-center border ${act.type === 'payment' ? 'bg-green-500/10 text-green-500 border-green-500/20' : 'bg-orange-500/10 text-orange-500 border-orange-500/20'}`}>
                                                          {act.type === 'payment' ? <ArrowDownLeft size={14} /> : <ArrowUpRight size={14} />}
                                                      </div>
                                                      <div className="text-right">
                                                          <span className={`block text-xs font-black ${act.isPaid ? 'text-green-500' : 'text-orange-500'}`}>{act.type === 'payment' ? '+' : ''}{formatCompact(act.amount)}</span>
                                                      </div>
                                                  </div>
                                                  <div>
                                                      <h4 className={`text-xs font-bold truncate ${isLight ? 'text-gray-800' : 'text-white'}`}>{act.subtitle}</h4>
                                                      <p className="text-[9px] text-gray-500 truncate">{act.title}</p>
                                                  </div>
                                              </div>
                                          ))}
                                      </div>
                                  </div>
                              ))
                          )}
                      </div>
                  </div>
              </div>
          </div>
      </div>

      {/* --- PENDING ADVANCE MODAL (NEW) --- */}
      {showNoAdvanceModal && (
          <div className="fixed inset-0 z-[6000] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in pb-safe" onClick={() => setShowNoAdvanceModal(false)}>
              <div className={`w-full max-w-sm rounded-[36px] overflow-hidden relative border shadow-2xl flex flex-col max-h-[85vh] mb-safe ${isLight ? 'bg-white border-gray-100' : 'bg-[#121212] border-gray-800'}`} onClick={e => e.stopPropagation()}>
                  <div className={`p-5 flex justify-between items-center border-b ${isLight ? 'bg-gray-50' : 'bg-white/5'}`}>
                      <div className="flex items-center gap-2">
                          <Bell size={20} className="text-red-500 animate-shake" />
                          <h2 className={`text-lg font-black uppercase tracking-wider ${isLight ? 'text-black' : 'text-white'}`}>Advance Alert</h2>
                      </div>
                      <button onClick={() => setShowNoAdvanceModal(false)} className="p-2 rounded-full bg-gray-500/10 hover:bg-gray-500/20"><X size={20} className="text-gray-500"/></button>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">
                      {stats.advancelessTenants.length === 0 ? (
                          <div className="text-center py-10 opacity-50">
                              <CheckCircle size={40} className="text-green-500 mx-auto mb-2"/>
                              <p className="text-sm font-bold text-green-500">Everyone has paid advance!</p>
                          </div>
                      ) : (
                          stats.advancelessTenants.map(t => (
                              <div key={t.id} className={`p-4 rounded-[28px] border flex flex-col gap-3 transition-all ${isLight ? 'bg-white border-gray-100 shadow-sm' : 'bg-white/5 border-red-500/10'}`}>
                                  <div className="flex items-center gap-4">
                                      <div className={`w-14 h-14 rounded-2xl overflow-hidden border-2 shrink-0 ${isLight ? 'border-gray-200 shadow-sm' : 'border-white/10 shadow-lg'}`}>
                                          {t.profileImage ? <img src={t.profileImage} className="w-full h-full object-cover"/> : <div className="w-full h-full flex items-center justify-center bg-gray-700 text-white"><User size={24}/></div>}
                                      </div>
                                      <div className="min-w-0">
                                          <h4 className={`font-black text-base truncate ${isLight ? 'text-black' : 'text-white'}`}>{t.name}</h4>
                                          <p className="text-xs text-red-500 font-bold mb-1">Has not paid the advance yet.</p>
                                          <div className="flex flex-col gap-1">
                                              <span className="text-[10px] font-bold text-gray-500 flex items-center gap-1"><Calendar size={10}/> Joined: {new Date(t.entryDate).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}</span>
                                              <a href={`tel:${t.phone}`} className="text-[10px] font-bold text-blue-500 flex items-center gap-1"><Phone size={10}/> {t.phone}</a>
                                          </div>
                                      </div>
                                  </div>
                                  <button 
                                      onClick={() => { setShowNoAdvanceModal(false); onEditTenant(t.id, 'advance'); }} // Signaling focus on advance
                                      className="w-full py-3 bg-red-500 text-white font-black rounded-2xl active:scale-95 transition flex items-center justify-center gap-2 shadow-lg shadow-red-500/20"
                                  >
                                      <CreditCard size={18} /> Update Advance
                                  </button>
                              </div>
                          ))
                      )}
                  </div>
              </div>
          </div>
      )}

      {showRiskModal && (
          <div className="fixed inset-0 z-[6000] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in pb-safe" onClick={() => setShowRiskModal(false)}>
              <div className={`w-full max-w-sm rounded-[36px] overflow-hidden relative border-2 shadow-2xl flex flex-col max-h-[85vh] mb-safe ${isLight ? 'bg-white border-red-100' : 'bg-[#121212] border-red-500/30'}`} onClick={e => e.stopPropagation()}>
                  <div className="bg-red-500 p-6 text-white text-center relative overflow-hidden shrink-0">
                      <div className="absolute top-0 right-0 p-4 opacity-10"><Siren size={80}/></div>
                      <AlertTriangle size={32} className="mx-auto mb-2 animate-bounce" />
                      <h2 className="text-xl font-black uppercase tracking-widest">Risk Analysis</h2>
                      <p className="text-[10px] font-bold opacity-80 mt-1">AI Suspicion Detection</p>
                      <button onClick={() => setShowRiskModal(false)} className="absolute top-4 right-4 bg-black/20 p-1.5 rounded-full hover:bg-black/30"><X size={16}/></button>
                  </div>
                  <div className={`p-5 text-center border-b ${isLight ? 'bg-red-50 border-red-100' : 'bg-red-900/10 border-red-500/20'}`}><p className={`text-sm font-bold leading-relaxed ${isLight ? 'text-red-700' : 'text-red-400'}`}>"এই ভাড়াটিয়ারা সম্ভবত পলাতক হতে পারে অথবা ভাড়া প্রদানে অনিয়ম করতে পারে। নিচের তালিকাটি পর্যালোচনা করুন।"</p></div>
                  <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">
                      {stats.riskyTenants.length === 0 ? <div className="text-center py-10 opacity-50"><CheckCircle size={40} className="text-green-500 mx-auto mb-2"/><p className="text-sm font-bold text-green-500">No suspicious activity detected.</p></div> : (
                          stats.riskyTenants.map(t => (
                              <div key={t.id} className={`p-3 rounded-2xl border flex items-center justify-between ${isLight ? 'bg-white border-red-100 shadow-sm' : 'bg-white/5 border-red-500/20'}`}>
                                  <div className="flex items-center gap-3"><div className={`w-10 h-10 rounded-full overflow-hidden flex items-center justify-center border ${isLight ? 'border-gray-200' : 'border-gray-700'}`}>{t.profileImage ? <img src={t.profileImage} className="w-full h-full object-cover"/> : <User size={20} className="text-gray-500"/>}</div><div><h4 className={`font-bold text-sm ${isLight ? 'text-black' : 'text-white'}`}>{t.name}</h4><p className="text-[10px] text-gray-500">{t.unitId} • Due: ৳{t.due}</p></div></div><div className={`text-[9px] font-black uppercase px-2 py-1 rounded border ${t.riskLevel === 'Critical' ? 'bg-red-500 text-white border-red-600' : 'bg-orange-500/10 text-orange-500 border-orange-500/30'}`}>{t.riskLevel} Risk</div>
                              </div>
                          ))
                      )}
                  </div>
              </div>
          </div>
      )}

      {showDueList && (
          <div className="fixed inset-0 z-[5000] bg-black/60 backdrop-blur-md flex items-center justify-center p-4 pb-safe" onClick={() => setShowDueList(false)}>
              <div className={`w-full max-w-sm max-h-[85vh] rounded-[32px] flex flex-col animate-slide-up relative overflow-hidden mb-safe ${isLight ? 'bg-white border border-gray-100 shadow-2xl' : 'bg-black/60 backdrop-blur-xl border border-white/10'}`} onClick={e => e.stopPropagation()}>
                  <div className={`flex justify-between items-center p-6 shrink-0 border-b ${isLight ? 'border-gray-200' : 'border-gray-800'}`}><div><h2 className={`text-xl font-black ${isLight ? 'text-black' : 'text-white'}`}>Due List</h2><p className="text-xs text-red-500 font-bold">{stats.dueCount} Pending</p></div><button onClick={() => setShowDueList(false)} className={`p-2 rounded-full ${isLight ? 'bg-gray-100 hover:bg-gray-200' : 'bg-white/10 text-white'}`}><X size={20}/></button></div>
                  <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">{(stats.tenantsWithDue as Tenant[]).map(t => (<div key={t.id} className={`flex items-center justify-between p-3 rounded-2xl border ${isLight ? 'bg-white border-gray-100' : 'bg-black/20 border-gray-700'}`}><div className="flex items-center gap-3"><div className={`w-12 h-12 rounded-xl overflow-hidden shrink-0 border relative ${t.status === 'Archived' ? 'border-dashed border-gray-500 grayscale' : 'border-transparent bg-gray-300'}`}>{t.profileImage ? <img src={t.profileImage} className="w-full h-full object-cover"/> : <div className="w-full h-full flex items-center justify-center bg-gray-700 text-white">{t.name[0]}</div>}{t.status === 'Archived' && <div className="absolute inset-0 bg-black/20 flex items-center justify-center text-[8px] font-bold text-white uppercase tracking-widest rotate-[-15deg] backdrop-blur-[1px]">Left</div>}</div><div><h4 className={`font-bold text-sm ${isLight ? 'text-black' : 'text-white'}`}>{t.name}</h4><p className="text-[10px] text-gray-500">{t.status === 'Archived' ? 'Vacant (Due)' : `Room ${t.unitId}`}</p></div></div><div className="flex items-center gap-3"><span className="text-red-500 font-black text-sm">৳{formatCompact(t.due)}</span><a href={`tel:${t.phone}`} className="p-2 bg-green-500 text-white rounded-full shadow-lg active:scale-90 transition"><Phone size={14} /></a></div></div>))}</div>
              </div>
          </div>
      )}

      {showEnergyList && (
          <div className="fixed inset-0 z-[5000] bg-black/60 backdrop-blur-md flex items-center justify-center p-4 pb-safe" onClick={() => setShowEnergyList(false)}>
              <div className={`w-full max-w-sm max-h-[85vh] rounded-[32px] flex flex-col animate-slide-up relative overflow-hidden mb-safe ${isLight ? 'bg-white border border-gray-100 shadow-2xl' : 'bg-black/60 backdrop-blur-xl border border-white/10'}`} onClick={e => e.stopPropagation()}>
                  <div className={`flex justify-between items-center p-6 shrink-0 border-b ${isLight ? 'border-gray-200' : 'border-gray-800'}`}><div><h2 className={`text-xl font-black flex items-center gap-2 ${isLight ? 'text-black' : 'text-white'}`}><Zap size={24} className="text-yellow-500"/> Energy Report</h2></div><button onClick={() => setShowEnergyList(false)} className={`p-2 rounded-full ${isLight ? 'bg-gray-100 hover:bg-gray-200' : 'bg-white/10 text-white'}`}><X size={20}/></button></div>
                  <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">{stats.energyBreakdown.length === 0 ? <div className="text-center py-10 opacity-50"><p className="text-sm">No usage yet.</p></div> : (stats.energyBreakdown.map((item, index) => (<div key={index} className={`flex items-center justify-between p-3 rounded-2xl border ${isLight ? 'bg-white border-gray-100' : 'bg-black/20 border-gray-700'}`}><div className="flex items-center gap-3"><div className="w-10 h-10 rounded-xl bg-gray-300 overflow-hidden shrink-0 border border-white/10">{item.profileImage ? <img src={item.profileImage} className="w-full h-full object-cover"/> : <div className="w-full h-full flex items-center justify-center bg-gray-700 text-white font-bold">{item.name[0]}</div>}</div><div><h4 className={`font-bold text-sm ${isLight ? 'text-black' : 'text-white'}`}>{item.name}</h4><p className="text-[10px] text-gray-500">Unit: {item.unit}</p></div></div><div className="text-right"><div className="font-black text-sm text-yellow-500">{item.units} u</div><div className={`text-[10px] font-bold ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>৳{item.cost}</div></div></div>)))}</div>
                  <div className={`p-4 border-t shrink-0 ${isLight ? 'border-gray-200' : 'border-gray-700'}`}><div className="flex justify-between items-center"><span className={`text-sm font-bold ${isLight ? 'text-gray-600' : 'text-gray-400'}`}>Total</span><span className="text-xl font-black text-yellow-500">{stats.totalUnitsConsumed} units</span></div></div>
              </div>
          </div>
      )}

      {showCollectedList && (
          <div className="fixed inset-0 z-[5000] bg-black/60 backdrop-blur-md flex items-center justify-center p-4 pb-safe" onClick={() => setShowCollectedList(false)}>
              <div className={`w-full max-w-sm max-h-[85vh] rounded-[32px] flex flex-col animate-slide-up relative overflow-hidden mb-safe ${isLight ? 'bg-white border border-gray-100 shadow-2xl' : 'bg-black/60 backdrop-blur-xl border border-white/10'}`} onClick={e => e.stopPropagation()}>
                  <div className={`flex justify-between items-center p-6 shrink-0 border-b ${isLight ? 'border-gray-200' : 'border-gray-800'}`}><div><h2 className={`text-xl font-black flex items-center gap-2 ${isLight ? 'text-black' : 'text-white'}`}><CheckCircle size={24} className="text-green-500"/> Payments</h2></div><button onClick={() => setShowCollectedList(false)} className={`p-2 rounded-full ${isLight ? 'bg-gray-100 hover:bg-gray-200' : 'bg-white/10 text-white'}`}><X size={20}/></button></div>
                  <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">{stats.collectedBills.length === 0 ? <div className="text-center py-10 opacity-50"><p className="text-sm">No collections yet.</p></div> : (stats.collectedBills.map((bill, index) => (<div key={index} className={`flex items-center justify-between p-3 rounded-2xl border ${isLight ? 'bg-white border-gray-100' : 'bg-black/20 border-gray-700'}`}><div className="flex items-center gap-3"><div className="w-10 h-10 rounded-xl bg-gray-300 overflow-hidden shrink-0 border border-white/10">{bill.tenantPhoto ? <img src={bill.tenantPhoto} className="w-full h-full object-cover"/> : <div className="w-full h-full flex items-center justify-center bg-gray-700 text-white font-bold">{bill.tenantName?.[0]}</div>}</div><div><h4 className={`font-bold text-sm ${isLight ? 'text-black' : 'text-white'}`}>{bill.tenantName}</h4><p className="text-[10px] text-gray-500">{new Date(bill.date).toLocaleDateString()} • {bill.tenantUnit}</p></div></div><div className="text-right"><div className="font-black text-sm text-green-500">৳{bill.paidAmount}</div><button onClick={() => handlePrintReceipt(bill)} className="text-[10px] font-bold text-blue-500 hover:underline flex items-center justify-end gap-1 mt-0.5"><Printer size={10} /> Receipt</button></div></div>)))}</div>
                  <div className={`p-4 border-t shrink-0 ${isLight ? 'border-gray-200' : 'border-gray-700'}`}><div className="flex justify-between items-center"><span className={`text-sm font-bold ${isLight ? 'text-gray-600' : 'text-gray-400'}`}>Total Collected</span><span className="text-xl font-black text-green-500">৳{formatCompact(stats.totalPaid)}</span></div></div>
              </div>
          </div>
      )}

      {showHistoryModal && (
          <div className="fixed inset-0 z-[5000] bg-black/60 backdrop-blur-md flex items-center justify-center p-4 pb-safe" onClick={() => setShowHistoryModal(false)}>
              <div className={`w-full max-w-sm max-h-[85vh] rounded-[32px] flex flex-col animate-slide-up relative overflow-hidden mb-safe ${isLight ? 'bg-white border border-gray-100 shadow-2xl' : 'bg-[#121212]'}`} onClick={e => e.stopPropagation()}>
                  <div className={`p-6 border-b flex justify-between items-center shrink-0 ${isLight ? 'border-gray-200' : 'border-gray-800'}`}><div><h2 className={`text-2xl font-black ${isLight ? 'text-black' : 'text-white'}`}>History</h2><p className="text-xs text-gray-500 font-medium">All recorded transactions</p></div><button onClick={() => setShowHistoryModal(false)} className={`p-2 rounded-full ${isLight ? 'bg-gray-100 hover:bg-gray-200' : 'bg-gray-800 text-white'}`}><X size={20}/></button></div>
                  <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">{(stats.sortedBills as Bill[]).map((bill) => { const tenant = (data.tenants || []).find(t => t.id === bill.tenantId); return (<div key={bill.id} className={`flex items-center justify-between p-4 rounded-2xl border ${isLight ? 'bg-white border-gray-100' : 'bg-[#1E1E24] border-gray-800'}`}><div className="flex items-center gap-3"><div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs ${bill.isPaid ? 'bg-green-500 text-white' : 'bg-orange-500 text-white'}`}>{new Date(bill.date).getDate()}</div><div><h4 className={`font-bold text-sm ${isLight ? 'text-black' : 'text-white'}`}>{tenant?.name || 'Unknown'}</h4><p className="text-[10px] text-gray-500">{new Date(bill.date).toLocaleDateString()} • {bill.month}</p></div></div><div className="text-right"><span className={`block font-black ${bill.isPaid ? 'text-green-500' : 'text-orange-500'}`}>{bill.isPaid ? '+' : ''}{bill.isPaid ? bill.paidAmount : bill.totalAmount}</span><button onClick={() => handlePrintReceipt(bill)} className="text-[10px] font-bold text-blue-500 hover:underline">Print Receipt</button></div></div>); })}{stats.sortedBills.length === 0 && <div className="text-center py-10 text-gray-500">No history found.</div>}</div>
              </div>
          </div>
      )}

      {showCalculator && <Calculator onClose={() => setShowCalculator(false)} isLight={isLight} />}
    </div>
  );
};

export default Dashboard;