import React, { useState, useEffect } from 'react';
import { AppData, ServiceContact, ServiceCategory } from '../types';
import TopBar from '../components/TopBar';
import { Plus, Trash2, Phone, Shield, Flame, Hammer, Zap, PaintBucket, Wrench, Siren, User, Search, Pencil, X, UsersRound } from 'lucide-react';

interface Props {
  data: AppData;
  setData: (data: AppData) => void;
  onOpenSettings: () => void;
}

const ServiceBook: React.FC<Props> = ({ data, setData, onOpenSettings }) => {
  const isLight = data.settings.theme === 'light';
  const contacts = data.serviceContacts || [];

  const [showAddModal, setShowAddModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Edit State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newProfession, setNewProfession] = useState(''); // NEW: Profession State
  const [newCategory, setNewCategory] = useState<ServiceCategory>('Other');

  // Delete Confirmation State
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Dynamic Emergency Number Handling
  const getDynamicEmergencyNumbers = () => {
      try {
          const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
          if (tz.includes('Dhaka')) {
              return [
                  { id: 'e1', name: 'National Emergency', phone: '999', category: 'Emergency' },
                  { id: 'e2', name: 'Fire Service', phone: '16163', category: 'Emergency' },
                  { id: 'e3', name: 'RAB Info', phone: '101', category: 'Emergency' },
                  { id: 'e4', name: 'Govt Info Service', phone: '333', category: 'Emergency' },
              ];
          } 
          if (tz.includes('Kolkata') || tz.includes('Calcutta') || tz.includes('India')) {
              return [
                  { id: 'e1', name: 'Police', phone: '100', category: 'Emergency' },
                  { id: 'e2', name: 'Fire', phone: '101', category: 'Emergency' },
                  { id: 'e3', name: 'Ambulance', phone: '102', category: 'Emergency' },
                  { id: 'e4', name: 'Women Helpline', phone: '1091', category: 'Emergency' },
              ];
          }
          if (tz.includes('America') || tz.includes('New_York') || tz.includes('Los_Angeles')) {
              return [
                  { id: 'e1', name: 'Emergency', phone: '911', category: 'Emergency' },
                  { id: 'e2', name: 'Non-Emergency', phone: '311', category: 'Emergency' },
                  { id: 'e3', name: 'Poison Control', phone: '1-800-222-1222', category: 'Emergency' },
              ];
          }
          // Default International / Generic if unknown
          return [
              { id: 'e1', name: 'Emergency (Univ)', phone: '112', category: 'Emergency' },
              { id: 'e2', name: 'Police', phone: '911', category: 'Emergency' },
          ];
      } catch (e) {
          // Fallback to BD defaults if detection fails
          return [
              { id: 'e1', name: 'National Emergency', phone: '999', category: 'Emergency' },
              { id: 'e2', name: 'Fire Service', phone: '16163', category: 'Emergency' },
          ];
      }
  };

  const emergencyContacts = getDynamicEmergencyNumbers();

  // Categories with Icons & Colors
  const categories: { id: ServiceCategory; label: string; icon: any; color: string; bg: string }[] = [
      { id: 'Emergency', label: 'Emergency', icon: Siren, color: 'text-red-500', bg: 'bg-red-500/10' },
      { id: 'Mason', label: 'Rajmistri', icon: Hammer, color: 'text-orange-500', bg: 'bg-orange-500/10' },
      { id: 'Electrician', label: 'Biddut Mistri', icon: Zap, color: 'text-yellow-500', bg: 'bg-yellow-500/10' },
      { id: 'Plumber', label: 'Kol Mistri', icon: Wrench, color: 'text-blue-500', bg: 'bg-blue-500/10' },
      { id: 'Painter', label: 'Rongmistri', icon: PaintBucket, color: 'text-purple-500', bg: 'bg-purple-500/10' },
      { id: 'Gas', label: 'Gas Mistri', icon: Flame, color: 'text-pink-500', bg: 'bg-pink-500/10' },
      { id: 'Other', label: 'Other', icon: User, color: 'text-gray-500', bg: 'bg-gray-500/10' },
  ];

  // Helper for Auto-Shrinking Text
  const getDynamicInputSize = (val: string) => {
      if (val.length > 18) return 'text-[10px]'; // Very small if very long
      if (val.length > 12) return 'text-xs';      // Small if long
      return 'text-sm';                           // Standard
  };

  const handleSaveContact = () => {
      if (!newName || !newPhone) return;
      
      if (editingId) {
          // Edit Mode
          const updatedContacts = contacts.map(c => 
              c.id === editingId ? { ...c, name: newName, phone: newPhone, category: newCategory, profession: newProfession } : c
          );
          setData({ ...data, serviceContacts: updatedContacts });
      } else {
          // Add Mode
          const newContact: ServiceContact = {
              id: Date.now().toString(),
              name: newName,
              phone: newPhone,
              category: newCategory,
              profession: newProfession
          };
          setData({ ...data, serviceContacts: [...contacts, newContact] });
      }
      
      resetForm();
  };

  const handleEdit = (contact: ServiceContact) => {
      setEditingId(contact.id);
      setNewName(contact.name);
      setNewPhone(contact.phone);
      setNewProfession(contact.profession || '');
      setNewCategory(contact.category);
      setShowAddModal(true);
  };

  const handleDeleteRequest = (id: string) => {
      setDeleteConfirmId(id);
  };

  const confirmDelete = () => {
      if (deleteConfirmId) {
          setData({ ...data, serviceContacts: contacts.filter(c => c.id !== deleteConfirmId) });
          setDeleteConfirmId(null);
      }
  };

  const resetForm = () => {
      setNewName('');
      setNewPhone('');
      setNewProfession('');
      setNewCategory('Other');
      setEditingId(null);
      setShowAddModal(false);
  };

  const handleCall = (phone: string) => {
      window.open(`tel:${phone}`, '_self');
  };

  // Grouping, Filtering & Alphabetical Sorting (NEON-SURGICAL)
  const otherContacts = contacts
    .filter(c => !c.isEmergency && c.category !== 'Emergency')
    .filter(c => 
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      c.phone.includes(searchTerm) ||
      c.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.profession && c.profession.toLowerCase().includes(searchTerm.toLowerCase()))
    )
    .sort((a, b) => a.name.localeCompare(b.name));

  return (
    <div className={`h-screen flex flex-col animate-fade-in ${isLight ? 'bg-app-lightBg' : 'bg-app-bg'}`}>
      <div className="flex-none z-50">
          <TopBar 
            title={<><span className={isLight ? 'text-black' : 'text-white'}>Phone</span><span className="text-app-accent">book</span></>}
            data={data} 
            setData={setData}
            onOpenSettings={onOpenSettings} 
          />
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-32">
          
          {/* 1. DYNAMIC EMERGENCY SECTION */}
          <div className="grid grid-cols-2 gap-2">
               {emergencyContacts.map((c, i) => (
                   <div key={i} onClick={() => handleCall(c.phone)} className={`p-2 rounded-xl border flex items-center gap-2 active:scale-95 transition cursor-pointer relative overflow-hidden ${isLight ? 'bg-red-50 border-red-100 shadow-sm' : 'bg-red-500/10 border-red-500/30'}`}>
                       <div className="w-8 h-8 rounded-full bg-red-500 text-white flex items-center justify-center shrink-0 shadow-md">
                           {c.name.toLowerCase().includes('fire') ? <Flame size={14}/> : <Shield size={14}/>}
                       </div>
                       <div className="min-w-0">
                           <h3 className={`font-black text-[10px] truncate leading-tight ${isLight ? 'text-red-600' : 'text-red-400'}`}>{c.name}</h3>
                           <p className={`font-mono text-sm font-bold leading-none ${isLight ? 'text-black' : 'text-white'}`}>{c.phone}</p>
                       </div>
                   </div>
               ))}
          </div>

          <div className="h-[1px] bg-gray-200 dark:bg-gray-800 w-full opacity-50"></div>

          {/* 2. HEADER & SEARCH */}
          <div className="space-y-3">
              <div className="flex justify-between items-center">
                  <h3 className={`text-xs font-bold uppercase tracking-wider ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>Directory</h3>
                  {/* RENAMED BUTTON: Add New -> Contact (English) */}
                  <button onClick={() => { resetForm(); setShowAddModal(true); }} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-black active:scale-95 transition shadow-lg shadow-blue-500/20">
                      <UsersRound size={16} /> Contact
                  </button>
              </div>

              {/* Search Bar - UPDATED PLACEHOLDER */}
              <div className={`flex items-center px-4 py-3 rounded-2xl border transition-all ${isLight ? 'bg-white border-gray-200 focus-within:border-blue-400 shadow-sm' : 'bg-[#18191F] border-gray-800 focus-within:border-app-accent'}`}>
                  <Search size={18} className="text-gray-400 mr-3"/>
                  <input 
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                      placeholder="সার্চ কন্টাক্ট (নাম বা নাম্বার)..."
                      className={`w-full bg-transparent outline-none text-sm font-bold ${isLight ? 'text-black placeholder-gray-400' : 'text-white placeholder-gray-600'}`}
                  />
                  {searchTerm && <button onClick={() => setSearchTerm('')} className="p-1 rounded-full hover:bg-gray-500/10"><X size={16} className="text-gray-400"/></button>}
              </div>
          </div>

          {/* 3. LIST */}
          <div className="space-y-2">
              {otherContacts.length === 0 && (
                  <div className="text-center py-10 opacity-50">
                      <User size={48} className="mx-auto mb-2 text-gray-500"/>
                      <p className="text-sm text-gray-500 font-bold">
                          {searchTerm ? 'কোন কন্টাক্ট পাওয়া যায়নি!' : 'ফোনবুকে কোন কন্টাক্ট নেই।'}
                      </p>
                  </div>
              )}

              {otherContacts.map(c => {
                  const cat = categories.find(cat => cat.id === c.category) || categories[6];
                  const Icon = cat.icon;
                  
                  return (
                      <div key={c.id} className={`flex items-center justify-between p-3.5 rounded-2xl border transition-all ${isLight ? 'bg-white border-gray-100 shadow-sm' : 'bg-[#1E1E24] border-white/5 hover:bg-[#25252b]'}`}>
                          <div className="flex items-center gap-4">
                              <div className={`w-11 h-11 rounded-full flex items-center justify-center border-2 overflow-hidden ${cat.bg} ${cat.color} ${isLight ? 'border-white' : 'border-white/5'}`}>
                                  {c.image ? <img src={c.image} className="w-full h-full object-cover" /> : <Icon size={22} />}
                              </div>
                              <div className="min-w-0">
                                  <h4 className={`font-black text-base truncate leading-tight ${isLight ? 'text-black' : 'text-white'}`}>{c.name}</h4>
                                  <p className={`font-mono text-xs font-bold mt-0.5 ${isLight ? 'text-gray-500' : 'text-gray-400'}`}>{c.phone}</p>
                                  {/* Profession or Category Subtitle */}
                                  <span className="text-[9px] font-black uppercase opacity-40 tracking-widest block truncate">
                                      {c.profession ? c.profession : (cat.id === 'Other' ? 'Tenant' : cat.label)}
                                  </span>
                              </div>
                          </div>
                          
                          {/* MODIFIED: Increased gap to gap-4 for better touch targets */}
                          <div className="flex gap-4">
                              <button onClick={() => handleCall(c.phone)} className="w-10 h-10 bg-green-500 text-white rounded-xl flex items-center justify-center active:scale-95 transition shadow-lg shadow-green-500/30">
                                  <Phone size={18} />
                              </button>
                              <button onClick={() => handleEdit(c)} className={`w-10 h-10 rounded-xl flex items-center justify-center active:scale-95 transition ${isLight ? 'bg-blue-50 text-blue-500 border border-blue-100' : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'}`}>
                                  <Pencil size={18} />
                              </button>
                              {/* MODIFIED: Calls handleDeleteRequest for confirmation */}
                              <button onClick={() => handleDeleteRequest(c.id)} className={`w-10 h-10 rounded-xl flex items-center justify-center active:scale-95 transition ${isLight ? 'bg-gray-100 text-gray-400' : 'bg-white/5 text-gray-500'}`}>
                                  <Trash2 size={18} />
                              </button>
                          </div>
                      </div>
                  );
              })}
          </div>
      </div>

      {/* ADD / EDIT MODAL - OPTIMIZED */}
      {showAddModal && (
          <div className="fixed inset-0 z-[2000] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 pb-safe" onClick={resetForm}>
              <div className={`w-full max-w-sm max-h-[85vh] rounded-[32px] p-6 animate-slide-up mb-safe flex flex-col relative overflow-hidden ${isLight ? 'bg-white' : 'bg-[#1E1E24] border border-gray-700'}`} onClick={e => e.stopPropagation()}>
                  <h3 className={`text-xl font-bold mb-6 shrink-0 ${isLight ? 'text-black' : 'text-white'}`}>
                      {editingId ? 'এডিট কন্টাক্ট' : 'নতুন কন্টাক্ট সেভ করুন'}
                  </h3>
                  
                  <div className="space-y-4 flex-1 overflow-y-auto min-h-0">
                      <input 
                          value={newName}
                          onChange={e => setNewName(e.target.value)}
                          placeholder="নাম (যেমন: রহিম রাজমিস্ত্রি)"
                          className={`w-full p-4 rounded-2xl outline-none font-bold ${isLight ? 'bg-gray-100 text-black' : 'bg-black/30 text-white border border-gray-700'}`}
                      />
                      
                      {/* MODIFIED: Side-by-Side Inputs for Phone and Profession with Auto-Shrink */}
                      <div className="flex gap-3">
                          <input 
                              type="tel"
                              value={newPhone}
                              onChange={e => setNewPhone(e.target.value)}
                              placeholder="ফোন নাম্বার"
                              className={`flex-1 p-4 rounded-2xl outline-none font-bold min-w-0 transition-all ${getDynamicInputSize(newPhone)} ${isLight ? 'bg-gray-100 text-black' : 'bg-black/30 text-white border border-gray-700'}`}
                          />
                          <input 
                              value={newProfession}
                              onChange={e => setNewProfession(e.target.value)}
                              placeholder="পেশা"
                              className={`flex-1 p-4 rounded-2xl outline-none font-bold min-w-0 transition-all ${getDynamicInputSize(newProfession)} ${isLight ? 'bg-gray-100 text-black' : 'bg-black/30 text-white border border-gray-700'}`}
                          />
                      </div>
                      
                      <div className="grid grid-cols-3 gap-2">
                          {categories.filter(c => c.id !== 'Emergency').map(cat => (
                              <button 
                                key={cat.id} 
                                onClick={() => setNewCategory(cat.id)}
                                className={`p-2 rounded-xl text-[10px] font-bold border transition-all ${newCategory === cat.id ? 'bg-blue-500 text-white border-blue-500' : (isLight ? 'bg-gray-50 border-gray-200 text-gray-600' : 'bg-black/20 border-gray-700 text-gray-400')}`}
                              >
                                  {cat.label}
                              </button>
                          ))}
                      </div>

                      <button onClick={handleSaveContact} className="w-full py-4 bg-app-accent text-black font-black rounded-2xl mt-4 active:scale-95 transition shrink-0">
                          {editingId ? 'আপডেট করুন' : 'সেভ করুন'}
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* NEW: Custom Delete Confirmation Modal */}
      {deleteConfirmId && (
          <div className="fixed inset-0 z-[6000] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in" onClick={() => setDeleteConfirmId(null)}>
              <div className={`w-full max-w-xs p-6 rounded-[28px] shadow-2xl animate-scale-in text-center ${isLight ? 'bg-white' : 'bg-[#1E1E24] border border-gray-700'}`} onClick={e => e.stopPropagation()}>
                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Trash2 size={24} className="text-red-500" />
                  </div>
                  <h3 className={`text-lg font-bold mb-2 ${isLight ? 'text-black' : 'text-white'}`}>Delete Contact?</h3>
                  <p className="text-sm text-gray-500 mb-6">"Do you want to delete?"</p>
                  <div className="flex gap-3">
                      <button 
                          onClick={() => setDeleteConfirmId(null)}
                          className={`flex-1 py-3 rounded-xl font-bold text-sm ${isLight ? 'bg-gray-100 text-gray-700' : 'bg-white/10 text-gray-300'}`}
                      >
                          No
                      </button>
                      <button 
                          onClick={confirmDelete}
                          className="flex-1 py-3 rounded-xl font-bold text-sm bg-red-500 text-white shadow-lg shadow-red-500/30"
                      >
                          Yes
                      </button>
                  </div>
              </div>
          </div>
      )}

    </div>
  );
};

export default ServiceBook;